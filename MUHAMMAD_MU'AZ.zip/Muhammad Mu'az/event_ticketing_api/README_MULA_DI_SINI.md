# Mula di sini - backend Event Ticketing

Pakej ini disusun daripada versi kod terakhir dalam dua shared chat yang diberikan.
Ia ialah salinan untuk setup lokal, bukan eksport folder sebenar daripada laptop kawan.
Frontend individu akan menggunakan API ini. Frontend dan template report belum termasuk.

## 1. Letakkan folder dalam XAMPP

Extract ZIP. Salin folder `event_ticketing_api` ke:

```text
C:\xampp\htdocs\event_ticketing_api
```

Pastikan fail `test_connection.php` berada terus dalam folder itu. Jangan letakkan
dua folder `event_ticketing_api` bertingkat.

Buka XAMPP Control Panel. Start Apache dan MySQL.

## 2. Import database

Buka `http://localhost/phpmyadmin/`, pilih tab Import, dan import:

```text
event_ticketing_api/database/event_ticketing_db.sql
```

Fail SQL membina `event_ticketing_db`, lima table, dan sample data. Import sekali
untuk setup baharu. Jika table dengan nama sama sudah wujud, berhenti dan gunakan
SQL rasmi kumpulan; fail ini tidak memadam database yang sedia ada.

Tetapan connection dalam `config/database.php` menggunakan MySQL localhost,
database `event_ticketing_db`, username `root`, dan password kosong seperti kod asal.
Ubah tetapan itu jika konfigurasi XAMPP kau berbeza.

## 3. Test connection

Buka:

```text
http://localhost/event_ticketing_api/test_connection.php
```

Response yang dijangka mempunyai `status: true` dan mesej database connected.

## 4. Test login dalam Postman

Import fail tambahan:

```text
event_ticketing_api/postman/Event_Ticketing_Local.postman_collection.json
```

Collection bernama `Event Ticketing - Local Setup`. Pilih `1 - Login Admin`
dan tekan Send. URL dan body sudah diisi. Token disimpan secara automatik untuk
request selepas login dalam collection tambahan ini.

Demo admin:

```text
Email: admin@gmail.com
Password: admin123
```

Demo staff: `staff1@gmail.com` / `staff123`.
Demo customer: `customer1@gmail.com` / `cust123`.
Ini akaun contoh untuk ujian lokal.

Selepas login, hantar `2 - GET Events`, `3 - GET Venues`, dan `4 - GET Bookings`.
GET Events memulangkan `status`, `message`, `data`, dan `pagination`.
Weather memerlukan internet. Request lain menggunakan database lokal.

## Peraturan untuk frontend

- Login: `POST auth/login.php`, body JSON email dan password.
- Logout: `POST auth/logout.php` dengan Bearer token.
- Users: admin sahaja. DELETE menyahaktifkan pengguna.
- Venues: admin sahaja. DELETE memadam venue; SQL lokal menghalang venue yang masih dirujuk event daripada dipadam.
- Events: GET untuk semua role yang login; perubahan untuk admin/staff. DELETE membatalkan event.
- Bookings: customer membuat tempahan; admin melihat semua; staff melihat tempahan event sendiri.
- PUT Bookings untuk admin/staff; DELETE membatalkan tempahan dan memulangkan tiket, dengan akses admin atau customer pemilik tempahan.

## Sumber, perubahan dan had ujian

Rujuk `SOURCE_AND_CHANGES.md`. Fail PHP API disalin daripada chat tanpa diubah.
Pakej dan data telah diperiksa secara statik; PHP/MySQL belum dijalankan dalam
persekitaran penyediaan fail ini. Sahkan connection dan login menggunakan langkah
di atas pada laptop kau sebelum sambungkan frontend.
