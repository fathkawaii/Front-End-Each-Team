import { API_BASE } from "./config.js";
import { ROLES } from "./policy.js";
export { API_BASE };
const SESSION_KEY = "event-ticketing-session-v2";
let memorySession = null;

export class ApiError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

function validSession(session) {
  return typeof session?.token === "string" && session.token.length > 0 &&
    Number.isSafeInteger(Number(session.user?.user_id)) && Number(session.user.user_id) > 0 &&
    ROLES.includes(session.user?.role) && session.user?.status !== "inactive";
}

export function getSession() {
  try {
    const stored = sessionStorage.getItem(SESSION_KEY);
    const session = stored ? JSON.parse(stored) : memorySession;
    return validSession(session) ? session : null;
  } catch {
    return validSession(memorySession) ? memorySession : null;
  }
}

export function saveSession(response) {
  if (!validSession(response)) throw new ApiError("This account cannot access the application.", 403);
  memorySession = {
    token: response.token,
    user: { ...response.user },
    expires_at: response.expires_at
  };
  try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(memorySession)); } catch { /* Keep this tab usable. */ }
}

export function clearSession() {
  memorySession = null;
  try { sessionStorage.removeItem(SESSION_KEY); } catch { /* Storage may be unavailable. */ }
}

export async function request(path, options = {}) {
  const headers = { Accept: "application/json" };
  const token = options.auth === false ? null : (options.token ?? getSession()?.token);
  if (token) headers.Authorization = "Bearer " + token;
  if (options.body !== undefined) headers["Content-Type"] = "application/json";

  let response;
  try {
    response = await fetch(API_BASE.replace(/\/$/, "") + "/" + path.replace(/^\//, ""), {
      method: options.method || "GET",
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: options.signal,
      cache: "no-store"
    });
  } catch (error) {
    if (error.name === "AbortError") throw error;
    throw new ApiError("Cannot connect. Check that Apache is running, then try again.");
  }

  // An old request must not clear a newer account's session.
  if (response.status === 401 && token && getSession()?.token === token) clearSession();

  let result;
  try { result = await response.json(); }
  catch {
    throw new ApiError("The service returned an unexpected response. Check the API folder and try again.", response.status);
  }
  if (!response.ok || result?.status === false) {
    throw new ApiError(result?.message || "The request could not be completed.", response.status);
  }
  if (result?.status !== true) throw new ApiError("The service returned an unexpected response.", response.status);
  return result;
}

export function requireList(response) {
  if (!Array.isArray(response.data)) throw new ApiError("The records could not be loaded.");
  return response.data;
}

export function requireRecord(response) {
  if (!response.data || Array.isArray(response.data) || typeof response.data !== "object") {
    throw new ApiError("The record could not be loaded.");
  }
  return response.data;
}
