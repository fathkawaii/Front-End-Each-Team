export const ROLES = ["admin", "staff", "customer"];
export const ROLE_NAMES = { admin: "Administrator", staff: "Staff / Organiser", customer: "Customer" };

export function pagesFor(role) {
  if (role === "admin") return ["events", "venues", "bookings", "users"];
  if (role === "staff") return ["events", "venues", "bookings"];
  if (role === "customer") return ["events", "bookings"];
  return [];
}

export function managesEvents(user) {
  return ["admin", "staff"].includes(user?.role);
}

export function canEditEvent(user, event) {
  return user?.role === "admin" ||
    (user?.role === "staff" && Number(event.organiser_id) === Number(user.user_id));
}

export function canBook(user, event) {
  return user?.role === "customer" && event.status === "upcoming" && Number(event.available_tickets) > 0;
}

export function canEditBooking(user, booking) {
  return user?.role === "admin" ||
    (user?.role === "staff" && Number(booking.organiser_id) === Number(user.user_id));
}

export function canCancelBooking(user, booking) {
  return booking.booking_status !== "cancelled" &&
    (user?.role === "admin" ||
      (user?.role === "customer" && Number(booking.customer_id) === Number(user.user_id)));
}

export function canViewBooking(user, booking) {
  return user?.role === "admin" ||
    (user?.role === "staff" && Number(booking.organiser_id) === Number(user.user_id)) ||
    (user?.role === "customer" && Number(booking.customer_id) === Number(user.user_id));
}
