import test from "node:test";
import assert from "node:assert/strict";
import { request, saveSession, clearSession, getSession } from "../assets/api.js";
import { userPayload, bookingPayload, createBookingPayload } from "../assets/forms.js";
import { pagesFor, canEditEvent, canBook, canEditBooking, canCancelBooking, canViewBooking } from "../assets/policy.js";
import * as service from "../assets/service.js";

const stored = new Map();
globalThis.sessionStorage = {
  getItem: key => stored.get(key) ?? null,
  setItem: (key, value) => stored.set(key, value),
  removeItem: key => stored.delete(key)
};
const accounts = {
  admin: { user_id: 1, name: "Admin", role: "admin", status: "active" },
  staff: { user_id: 2, name: "Staff One", role: "staff", status: "active" },
  customer: { user_id: 4, name: "Customer One", role: "customer", status: "active" }
};
const event = {
  event_id: 1, organiser_id: 2, venue_id: 1, event_name: "Technology Conference 2026",
  description: "Conference about latest technology trends.", event_date: "2026-11-15",
  start_time: "09:00:00", end_time: "17:00:00", ticket_price: "50.00",
  total_tickets: 500, available_tickets: 498, status: "upcoming"
};
const venue = { venue_id: 1, venue_name: "Grand Hall A", capacity: 500, status: "available" };
const booking = {
  booking_id: 1, customer_id: 4, organiser_id: 2, event_id: 1,
  quantity: 2, booking_status: "confirmed", ticket_price: "50.00", total_amount: "100.00"
};
const response = (data, code = 200) => new Response(JSON.stringify(data), { status: code });
const login = role => {
  clearSession();
  saveSession({ token: role + "-token", user: accounts[role] });
};
function fakeApi(handler) {
  const calls = [];
  globalThis.fetch = async (url, options) => {
    const call = { url, method: options.method, body: options.body ? JSON.parse(options.body) : undefined, headers: options.headers };
    calls.push(call);
    return handler(call, calls);
  };
  return calls;
}

test("navigation and ownership rules expose the required scope for each account", () => {
  assert.deepEqual(pagesFor("admin"), ["events", "venues", "bookings", "users"]);
  assert.deepEqual(pagesFor("staff"), ["events", "venues", "bookings"]);
  assert.deepEqual(pagesFor("customer"), ["events", "bookings"]);
  assert.deepEqual(pagesFor("unknown"), []);
  assert.equal(canEditEvent(accounts.staff, event), true);
  assert.equal(canEditEvent(accounts.staff, { ...event, organiser_id: 3 }), false);
  assert.equal(canEditEvent(accounts.customer, event), false);
  assert.equal(canEditBooking(accounts.staff, booking), true);
  assert.equal(canEditBooking(accounts.staff, { ...booking, organiser_id: 3 }), false);
  assert.equal(canViewBooking(accounts.customer, { ...booking, customer_id: 5 }), false);
  assert.equal(canCancelBooking(accounts.customer, booking), true);
  assert.equal(canCancelBooking(accounts.customer, { ...booking, customer_id: 5 }), false);
  assert.equal(canCancelBooking(accounts.staff, booking), false);
  assert.equal(canCancelBooking(accounts.admin, { ...booking, booking_status: "cancelled" }), false);
  assert.equal(canBook(accounts.customer, event), true);
  assert.equal(canBook(accounts.admin, event), false);
  assert.equal(canBook(accounts.customer, { ...event, status: "cancelled" }), false);
  assert.equal(canBook(accounts.customer, { ...event, available_tickets: 0 }), false);
});

test("a delayed 401 for an old token cannot erase a newly signed-in account", async () => {
  login("admin");
  let finish;
  globalThis.fetch = () => new Promise(resolve => { finish = resolve; });
  const pending = request("api/events/");
  login("customer");
  finish(response({ status: false, message: "Old token expired" }, 401));
  await assert.rejects(pending, /expired/);
  assert.equal(getSession().user.role, "customer");
  clearSession();
});

test("failed unauthenticated login does not revoke an existing session", async () => {
  login("customer");
  const calls = fakeApi(() => response({ status: false, message: "Invalid email or password" }, 401));
  await assert.rejects(request("auth/login.php", { auth: false, method: "POST", body: {} }), /Invalid/);
  assert.equal(calls[0].headers.Authorization, undefined);
  assert.equal(getSession().user.role, "customer");
  clearSession();
});

test("new-user validation trims fields and editing with a blank password preserves it", () => {
  const values = { name: " Test ", email: " test@example.com ", password: "secret123", phone: " 01234 ", role: "customer", status: "active" };
  assert.deepEqual(userPayload(values), { name: "Test", email: "test@example.com", password: "secret123", phone: "01234", role: "customer", status: "active" });
  assert.equal("password" in userPayload({ ...values, password: "" }, { user_id: 7 }), false);
  for (const changed of [{ email: "bad" }, { password: "" }, { role: "root" }, { status: "banned" }, { password: "😀".repeat(19) }]) {
    assert.throws(() => userPayload({ ...values, ...changed }));
  }
});

test("staff event form reads venues and its own identity without calling admin-only Users", async () => {
  login("staff");
  const calls = fakeApi(call => {
    assert.equal(call.url, "/event_ticketing_api/api/venues/");
    return response({ status: true, data: [venue] });
  });
  const data = await service.eventFormData();
  assert.equal(data.organisers[0].user_id, 2);
  assert.equal(data.venues[0].capacity, 500);
  assert.equal(calls.length, 1);
  clearSession();
});

test("staff receives a useful setup error if the venue read patch is absent", async () => {
  login("staff");
  fakeApi(() => response({ status: false, message: "Access denied for this role" }, 403));
  await assert.rejects(service.eventFormData(), /Venue access is not enabled/);
  assert.equal(getSession().user.role, "staff");
  clearSession();
});

test("staff event update uses fresh inventory and forces its own organiser identity", async () => {
  login("staff");
  const calls = fakeApi(call => {
    if (call.url.includes("api/events/?id=1") && call.method === "GET") {
      return response({ status: true, data: { ...event, available_tickets: 490 } });
    }
    if (call.url.includes("api/venues/")) return response({ status: true, data: venue });
    assert.equal(call.method, "PUT");
    assert.equal(call.body.organiser_id, 2);
    assert.equal(call.body.total_tickets, 20);
    assert.equal(call.body.available_tickets, 10);
    return response({ status: true, message: "Event updated successfully" });
  });
  await service.saveEvent({ ...event, organiser_id: 1, total_tickets: 20 }, 1);
  assert.deepEqual(calls.map(x => x.method), ["GET", "GET", "PUT"]);
  clearSession();
});

test("staff cannot use the frontend service to edit another organiser's event", async () => {
  login("staff");
  const calls = fakeApi(() => response({ status: true, data: { ...event, organiser_id: 3 } }));
  await assert.rejects(service.saveEvent(event, 1), error => error.status === 403);
  assert.deepEqual(calls.map(x => x.method), ["GET"]);
  clearSession();
});

test("customer booking rechecks availability and sends only event and quantity with its token", async () => {
  login("customer");
  const calls = fakeApi(call => {
    assert.equal(call.headers.Authorization, "Bearer customer-token");
    if (call.method === "GET") return response({ status: true, data: { ...event, available_tickets: 3 } });
    assert.equal(call.url, "/event_ticketing_api/api/bookings/");
    assert.equal(call.method, "POST");
    assert.deepEqual(call.body, { event_id: 1, quantity: 2 });
    assert.equal("customer_id" in call.body, false);
    assert.equal("total_amount" in call.body, false);
    return response({ status: true, message: "Booking created successfully", booking_id: 6 }, 201);
  });
  const result = await service.createBooking({ quantity: "2", customer_id: 999, total_amount: 1 }, 1);
  assert.equal(result.booking_id, 6);
  assert.deepEqual(calls.map(x => x.method), ["GET", "POST"]);
  clearSession();
});

test("reduced availability blocks the booking before POST", async () => {
  login("customer");
  const calls = fakeApi(() => response({ status: true, data: { ...event, available_tickets: 1 } }));
  await assert.rejects(service.createBooking({ quantity: 2 }, 1), /Not enough tickets/);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].method, "GET");
  clearSession();
});

test("server-side rejection after a booking availability race is surfaced without fake success", async () => {
  login("customer");
  fakeApi(call => call.method === "GET" ? response({ status: true, data: event }) :
    response({ status: false, message: "Not enough tickets available" }, 400));
  await assert.rejects(service.createBooking({ quantity: 2 }, 1), error => error.status === 400);
  assert.equal(getSession().user.role, "customer");
  clearSession();
});

test("admin and staff cannot create customer bookings through the service", async () => {
  const calls = fakeApi(() => { throw new Error("Must not reach API"); });
  for (const role of ["admin", "staff"]) {
    login(role);
    await assert.rejects(service.createBooking({ quantity: 1 }, 1), error => error.status === 403);
  }
  assert.equal(calls.length, 0);
  clearSession();
});

test("customer cancellation rereads ownership and cancels with DELETE", async () => {
  login("customer");
  const calls = fakeApi(call => call.method === "GET"
    ? response({ status: true, data: booking })
    : response({ status: true, message: "Booking cancelled successfully" }));
  await service.removeRecord("bookings", 1);
  assert.deepEqual(calls.map(x => x.method), ["GET", "DELETE"]);
  assert.equal(calls[1].url, "/event_ticketing_api/api/bookings/?id=1");
  clearSession();
});

test("another customer's booking is neither displayed nor cancelled by the service", async () => {
  login("customer");
  const calls = fakeApi(() => response({ status: true, data: { ...booking, customer_id: 5 } }));
  await assert.rejects(service.bookingDetails(1), error => error.status === 403);
  await assert.rejects(service.removeRecord("bookings", 1), error => error.status === 403);
  assert.equal(calls.some(x => x.method === "DELETE"), false);
  clearSession();
});

test("staff can update its booking through PUT but cannot use DELETE", async () => {
  login("staff");
  const calls = fakeApi(call => {
    if (call.url.includes("api/bookings/") && call.method === "GET") return response({ status: true, data: booking });
    if (call.url.includes("api/events/")) return response({ status: true, data: event });
    assert.equal(call.method, "PUT");
    assert.deepEqual(call.body, { quantity: 2, booking_status: "cancelled" });
    return response({ status: true, message: "Booking updated successfully" });
  });
  await service.saveBooking({ quantity: 99, booking_status: "cancelled" }, 1);
  await assert.rejects(service.removeRecord("bookings", 1), error => error.status === 403);
  assert.equal(calls.some(x => x.method === "DELETE"), false);
  clearSession();
});

test("reactivating a cancelled booking requires the full requested quantity to be available", async () => {
  login("admin");
  const calls = fakeApi(call => response({ status: true, data: call.url.includes("api/bookings/")
    ? { ...booking, booking_status: "cancelled" } : { ...event, available_tickets: 1 } }));
  await assert.rejects(service.saveBooking({ quantity: 2, booking_status: "confirmed" }, 1), /Not enough tickets/);
  assert.equal(calls.some(x => x.method === "PUT"), false);
  clearSession();
});

test("saving cancelled bookings preserves quantity even when the form control is disabled", () => {
  assert.deepEqual(bookingPayload({ booking_status: "cancelled" }, booking), { quantity: 2, booking_status: "cancelled" });
  assert.deepEqual(bookingPayload({ booking_status: "cancelled" }, { ...booking, booking_status: "cancelled" }), {
    quantity: 2, booking_status: "cancelled"
  });
});

test("administrator user editing does not send an empty password", async () => {
  login("admin");
  const calls = fakeApi(call => call.method === "GET"
    ? response({ status: true, data: { ...accounts.customer, email: "c@example.com" } })
    : response({ status: true, message: "User updated successfully" }));
  await service.saveUser({ name: "Customer", email: "c@example.com", phone: "", password: "", role: "customer", status: "active" }, 4);
  assert.equal(calls[1].method, "PUT");
  assert.equal("password" in calls[1].body, false);
  clearSession();
});

test("administrator cannot deactivate or demote its own account through the service", async () => {
  login("admin");
  const calls = fakeApi(() => response({ status: true, data: accounts.admin }));
  await assert.rejects(service.removeRecord("users", 1), error => error.status === 403);
  await assert.rejects(service.saveUser({ name: "Admin", email: "admin@example.com", role: "customer", status: "active" }, 1),
    error => error.status === 403);
  assert.equal(calls.some(x => ["PUT", "DELETE"].includes(x.method)), false);
  clearSession();
});

test("staff and customers cannot write user or venue records through the service", async () => {
  const calls = fakeApi(() => { throw new Error("Must not reach API"); });
  for (const role of ["staff", "customer"]) {
    login(role);
    await assert.rejects(service.saveVenue({}), error => error.status === 403);
    await assert.rejects(service.saveUser({}), error => error.status === 403);
    await assert.rejects(service.removeRecord("venues", 1), error => error.status === 403);
  }
  assert.equal(calls.length, 0);
  clearSession();
});

test("staff My events pagination filters the complete API result rather than one page", async () => {
  login("staff");
  const rows = Array.from({ length: 60 }, (_, index) => ({
    ...event, event_id: index + 1, organiser_id: [2, 49, 55].includes(index + 1) ? 2 : 3
  }));
  const calls = fakeApi(call => {
    const page = Number(new URL(call.url, "http://localhost").searchParams.get("page"));
    return response({ status: true, data: rows.slice((page - 1) * 50, page * 50), pagination: { total_pages: 2 } });
  });
  const result = await service.eventPage({ scope: "mine", page: 2, limit: 2 });
  assert.equal(calls.length, 2);
  assert.deepEqual(result.data.map(x => x.event_id), [55]);
  assert.equal(result.pagination.total_records, 3);
  assert.equal(result.pagination.total_pages, 2);
  clearSession();
});

test("invalid customer quantities and cancelled events are blocked", () => {
  for (const quantity of [0, -1, 1.2, "abc", ""]) {
    assert.throws(() => createBookingPayload({ quantity }, event));
  }
  assert.throws(() => createBookingPayload({ quantity: 1 }, { ...event, status: "cancelled" }), /not open/);
});
