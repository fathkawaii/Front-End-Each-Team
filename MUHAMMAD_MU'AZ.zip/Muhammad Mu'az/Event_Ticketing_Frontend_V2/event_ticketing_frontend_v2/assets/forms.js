const EVENT_STATUSES = ["upcoming", "ongoing", "completed", "cancelled"];
const BOOKING_STATUSES = ["pending", "confirmed", "cancelled"];

function text(value, label, maxLength) {
  const result = String(value ?? "").trim();
  if (!result) throw new Error(`${label} is required.`);
  if (result.length > maxLength) throw new Error(`${label} must be ${maxLength} characters or fewer.`);
  return result;
}

function positiveInteger(value, label) {
  const result = Number(value);
  if (!Number.isSafeInteger(result) || result < 1 || result > 2147483647) {
    throw new Error(`${label} must be a positive whole number.`);
  }
  return result;
}

function allowedStatus(value, statuses) {
  if (!statuses.includes(value)) throw new Error("Please choose a valid status.");
  return value;
}

export function eventPayload(values, previous, venue) {
  const event_date = String(values.event_date || "");
  const parsedDate = new Date(`${event_date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(event_date) || Number(event_date.slice(0, 4)) < 1000 ||
      Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== event_date) {
    throw new Error("Please enter a valid event date.");
  }
  const timePattern = /^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/;
  if (!timePattern.test(values.start_time) || !timePattern.test(values.end_time)) {
    throw new Error("Please enter valid start and end times.");
  }
  const start_time = `${values.start_time.slice(0, 5)}:00`;
  const end_time = `${values.end_time.slice(0, 5)}:00`;
  if (end_time <= start_time) throw new Error("End time must be later than start time.");

  const ticket_price = Number(values.ticket_price);
  if (!/^(?:\d+|\d*\.\d{1,2})$/.test(String(values.ticket_price)) ||
      !Number.isFinite(ticket_price) || ticket_price < 0 || ticket_price > 99999999.99) {
    throw new Error("Enter a valid ticket price with up to two decimal places.");
  }
  const organiser_id = positiveInteger(values.organiser_id, "Organiser");
  const venue_id = positiveInteger(values.venue_id, "Venue");
  const total_tickets = positiveInteger(values.total_tickets, "Total tickets");
  if (!venue || Number(venue.venue_id) !== venue_id) throw new Error("Please choose a venue.");
  if (venue.status !== "available" && Number(previous?.venue_id) !== venue_id) {
    throw new Error("Please choose an available venue.");
  }
  if (total_tickets > Number(venue.capacity)) throw new Error("Total tickets cannot exceed the venue capacity.");
  // Preserve the tickets already reserved instead of resetting availability.
  const reserved = previous ? Math.max(0, Number(previous.total_tickets) - Number(previous.available_tickets)) : 0;
  if (total_tickets < reserved) throw new Error(`At least ${reserved} tickets are already reserved.`);
  return {
    organiser_id, venue_id,
    event_name: text(values.event_name, "Event name", 150),
    description: String(values.description || "").trim(),
    event_date, start_time, end_time, ticket_price, total_tickets,
    available_tickets: total_tickets - reserved,
    status: allowedStatus(values.status, EVENT_STATUSES)
  };
}

export function venuePayload(values) {
  return {
    venue_name: text(values.venue_name, "Venue name", 150),
    location: text(values.location, "Location", 255),
    capacity: positiveInteger(values.capacity, "Capacity"),
    status: allowedStatus(values.status, ["available", "unavailable"])
  };
}

export function bookingPayload(values, previous) {
  const booking_status = allowedStatus(values.booking_status, BOOKING_STATUSES);
  const quantity = booking_status === "cancelled"
    ? Number(previous.quantity) : positiveInteger(values.quantity, "Quantity");
  return { quantity, booking_status };
}

export function userPayload(values, previous = null) {
  const email = text(values.email, "Email address", 100);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Enter a valid email address.");
  const phone = String(values.phone || "").trim();
  if (phone.length > 20) throw new Error("Phone number must be 20 characters or fewer.");
  const payload = {
    name: text(values.name, "Name", 100), email, phone,
    role: allowedStatus(values.role, ["admin", "staff", "customer"]),
    status: allowedStatus(values.status, ["active", "inactive"])
  };
  const password = String(values.password || "");
  if (!previous || password) {
    if (password.length < 6) throw new Error("Use a password with at least six characters.");
    if (new TextEncoder().encode(password).length > 72) throw new Error("Password is too long. Use 72 bytes or fewer.");
    payload.password = password;
  }
  return payload;
}

export function createBookingPayload(values, event) {
  if (!event || event.status !== "upcoming") throw new Error("This event is not open for booking.");
  const quantity = positiveInteger(values.quantity, "Quantity");
  if (quantity > Number(event.available_tickets)) throw new Error("Not enough tickets available. Choose a smaller quantity.");
  return { event_id: positiveInteger(event.event_id, "Event"), quantity };
}
