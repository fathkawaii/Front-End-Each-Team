import { request, getSession, saveSession, clearSession, requireList, ApiError } from "./api.js";
import { ROLE_NAMES, pagesFor, managesEvents, canEditEvent, canBook, canEditBooking, canCancelBooking } from "./policy.js";
import * as service from "./service.js";

const $ = id => document.getElementById(id);
const pages = ["events", "venues", "bookings", "users"];
const columns = { events: 7, venues: 5, bookings: 7, users: 6 };
const statuses = ["upcoming", "ongoing", "completed", "cancelled", "pending", "confirmed", "available", "unavailable", "active", "inactive"];
const currency = new Intl.NumberFormat("en-MY", { style: "currency", currency: "MYR" });
const state = {
  epoch: 0, dialogRequest: 0, page: "events", eventsPage: 1, totalPages: 1,
  search: "", scope: "all", showLastEventPage: false, loading: false,
  events: [], venues: [], bookings: [], users: [], formVenues: [],
  editingEvent: null, editingVenue: null, editingUser: null, editingBooking: null,
  purchaseEvent: null, detailsEvent: null, listController: null, weatherController: null
};

function node(tag, text = "", className = "") {
  const el = document.createElement(tag);
  el.textContent = String(text ?? "");
  if (className) el.className = className;
  return el;
}
function money(value) {
  return Number.isFinite(Number(value)) ? currency.format(Number(value)) : "—";
}
function date(value) {
  if (!value) return "—";
  const parsed = new Date(String(value).slice(0, 10) + "T00:00:00");
  return Number.isNaN(parsed.getTime()) ? "—" :
    parsed.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
function title(value) {
  const text = String(value || "Unknown");
  return text.charAt(0).toUpperCase() + text.slice(1);
}
function badge(value) {
  const status = statuses.includes(value) ? value : "unknown";
  return node("span", title(status), "badge badge-" + status);
}
function tableMessage(page, message) {
  const row = node("tr");
  const td = node("td", message, "table-message");
  td.colSpan = columns[page];
  row.append(td);
  $(page + "-body").replaceChildren(row);
}
function cell(row, content) {
  const td = node("td");
  if (content instanceof Node) td.append(content);
  else td.textContent = String(content ?? "—");
  row.append(td);
}
function recordName(name, subtitle) {
  const el = node("div");
  el.append(node("span", name, "record-name"));
  if (subtitle) el.append(node("span", subtitle, "record-subtitle"));
  return el;
}
function notice(message = "", type = "success") {
  $("notice").textContent = message;
  $("notice").className = "notice " + type;
  $("notice").hidden = !message;
}
function formError(id, message = "") {
  $(id).textContent = message;
  $(id).hidden = !message;
}
function handleError(error, target) {
  if (error.name === "AbortError") return;
  if (error.status === 401 || (error.status === 403 && /account is inactive/i.test(error.message))) {
    clearSession();
    showLogin(error.status === 401 ? "Your session has expired. Please sign in again." : error.message);
    return;
  }
  if (target) formError(target, error.message);
  else notice(error.message || "Something went wrong. Please try again.", "error");
}
function action(label, callback, { danger = false, disabled = false } = {}) {
  const button = node("button", label, "action-button" + (danger ? " danger" : ""));
  button.type = "button";
  button.disabled = disabled;
  button.addEventListener("click", async () => {
    if (button.disabled) return;
    const epoch = state.epoch;
    button.disabled = true;
    try { await callback(); }
    catch (error) { if (epoch === state.epoch) handleError(error); }
    finally { button.disabled = disabled; }
  });
  return button;
}
function closeDialogs() {
  document.querySelectorAll("dialog[open]").forEach(dialog => dialog.close());
}
function openDialog(id) {
  closeDialogs();
  $(id).showModal();
}
function resetWorkspace() {
  for (const page of pages) state[page] = [];
  state.formVenues = [];
  state.eventsPage = 1;
  state.totalPages = 1;
  state.search = "";
  state.showLastEventPage = false;
  state.purchaseEvent = null;
  state.detailsEvent = null;
  state.editingEvent = null;
  state.editingVenue = null;
  state.editingUser = null;
  state.editingBooking = null;
  state.loading = false;
  for (const id of ["event-search", "venue-search", "booking-search", "booking-filter", "user-search", "user-role-filter", "user-status-filter"]) $(id).value = "";
  document.querySelectorAll("dialog form").forEach(form => form.reset());
  for (const page of pages) $(page + "-body").replaceChildren();
  notice();
}
function showLogin(message = "") {
  state.epoch++;
  state.dialogRequest++;
  state.listController?.abort();
  state.weatherController?.abort();
  closeDialogs();
  resetWorkspace();
  $("app-view").hidden = true;
  $("login-view").hidden = false;
  $("login-password").value = "";
  formError("login-error", message);
  document.title = "Sign in | Event Ticketing";
  $("login-email").focus();
}
function showApp() {
  const session = getSession();
  if (!session) return showLogin();
  state.epoch++;
  resetWorkspace();
  const role = session.user.role;
  const allowed = pagesFor(role);
  state.scope = role === "staff" ? "mine" : "all";
  $("event-scope").value = state.scope;
  $("account-name").textContent = session.user.name;
  $("account-role").textContent = ROLE_NAMES[role];
  document.querySelectorAll(".nav a").forEach(link => { link.hidden = !allowed.includes(link.dataset.page); });
  $("bookings-nav").textContent = role === "customer" ? "My bookings" : "Bookings";
  $("bookings-heading").textContent = role === "customer" ? "My bookings" : "Bookings";
  $("browse-events").hidden = role !== "customer";
  $("add-event").hidden = !managesEvents(session.user);
  $("add-venue").hidden = role !== "admin";
  $("event-scope-wrap").hidden = role !== "staff";
  $("events-intro").textContent = role === "customer"
    ? "Find an event and reserve your tickets."
    : role === "staff" ? "Manage your events, schedules and ticket availability." : "Manage schedules and ticket availability.";
  $("venues-intro").textContent = role === "staff"
    ? "Check locations and capacities for your events." : "Keep venue information up to date.";
  $("bookings-intro").textContent = role === "customer"
    ? "View your tickets and booking status."
    : role === "staff" ? "Review bookings for your own events." : "Review customer bookings and update their status.";
  $("login-view").hidden = true;
  $("app-view").hidden = false;
  route();
}
function route() {
  const session = getSession();
  if (!session) {
    if (!$("app-view").hidden) showLogin();
    return;
  }
  state.dialogRequest++;
  closeDialogs();
  const selected = location.hash.slice(1);
  const allowed = pagesFor(session.user.role);
  state.page = allowed.includes(selected) ? selected : "events";
  if (selected !== state.page) history.replaceState(null, "", "#" + state.page);
  pages.forEach(page => { $(page + "-page").hidden = page !== state.page; });
  document.querySelectorAll(".nav a").forEach(link => {
    if (link.dataset.page === state.page) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  document.title = title(state.page) + " | Event Ticketing";
  return loadCurrentPage();
}
function navigate(page) {
  history.replaceState(null, "", "#" + page);
  return route();
}

async function loadCurrentPage() {
  if (!getSession()) return showLogin();
  const page = state.page;
  const epoch = state.epoch;
  state.listController?.abort();
  const controller = new AbortController();
  state.listController = controller;
  state.loading = true;
  state[page] = [];
  notice();
  tableMessage(page, "Loading " + page + "...");
  $(page + "-count").textContent = "";
  if (page === "events") {
    $("previous-page").disabled = true;
    $("next-page").disabled = true;
    $("page-number").textContent = "";
  }
  try {
    const result = page === "events"
      ? await service.eventPage({ page: state.eventsPage, search: state.search, scope: state.scope, signal: controller.signal })
      : await request("api/" + page + "/", { signal: controller.signal });
    if (controller.signal.aborted || epoch !== state.epoch || page !== state.page) return false;
    state[page] = requireList(result);
    state.loading = false;
    if (page === "events") {
      state.totalPages = Math.max(1, Number(result.pagination?.total_pages || 1));
      if (state.showLastEventPage) {
        state.showLastEventPage = false;
        if (state.eventsPage !== state.totalPages) {
          state.eventsPage = state.totalPages;
          return loadCurrentPage();
        }
      }
      if (state.eventsPage > state.totalPages) {
        state.eventsPage = state.totalPages;
        return loadCurrentPage();
      }
      renderEvents(Number(result.pagination?.total_records ?? state.events.length));
    } else if (page === "venues") renderVenues();
    else if (page === "users") renderUsers();
    else renderBookings();
    return true;
  } catch (error) {
    if (controller.signal.aborted || epoch !== state.epoch) return false;
    state.loading = false;
    tableMessage(page, "Unable to load " + page + ". Use Refresh to try again.");
    if (page === "venues" && getSession()?.user.role === "staff" && error.status === 403) {
      error.message = "Venue access is not enabled for staff. Ask your administrator to check the setup.";
    }
    handleError(error);
    return false;
  }
}

function renderEvents(total) {
  const account = getSession()?.user;
  if (!account) return;
  const body = $("events-body");
  body.replaceChildren();
  for (const event of state.events) {
    const row = node("tr");
    cell(row, recordName(event.event_name, event.organiser_name));
    cell(row, event.venue_name);
    cell(row, date(event.event_date));
    cell(row, event.available_tickets + " / " + event.total_tickets);
    cell(row, money(event.ticket_price));
    cell(row, badge(event.status));
    const controls = node("div", "", "row-actions");
    controls.append(action("Details", () => openEventDetails(event.event_id)));
    if (canEditEvent(account, event)) {
      controls.append(action("Edit", () => openEvent(event.event_id)));
      controls.append(action("Cancel", () => confirmRemove("events", event.event_id, event.event_name), {
        danger: true, disabled: event.status === "cancelled"
      }));
    }
    if (account.role === "customer") {
      controls.append(action(Number(event.available_tickets) < 1 ? "Sold out" : "Book tickets", () => openPurchase(event.event_id), {
        disabled: !canBook(account, event)
      }));
    }
    cell(row, controls);
    body.append(row);
  }
  if (!state.events.length) tableMessage("events", state.search ? "No events match your search." :
    account.role === "staff" && state.scope === "mine" ? "No events assigned to you yet. Add your first event." : "No events available.");
  $("events-count").textContent = total + " event" + (total === 1 ? "" : "s") + (state.search ? " found" : "");
  $("page-number").textContent = "Page " + state.eventsPage + " of " + state.totalPages;
  $("previous-page").disabled = state.eventsPage <= 1;
  $("next-page").disabled = state.eventsPage >= state.totalPages;
}
function renderVenues() {
  if (state.loading) return;
  const account = getSession()?.user;
  const search = $("venue-search").value.trim().toLowerCase();
  const rows = state.venues.filter(venue => (venue.venue_name + " " + venue.location).toLowerCase().includes(search));
  const body = $("venues-body");
  body.replaceChildren();
  for (const venue of rows) {
    const row = node("tr");
    cell(row, recordName(venue.venue_name, "Venue #" + venue.venue_id));
    cell(row, venue.location);
    cell(row, venue.capacity);
    cell(row, badge(venue.status));
    const controls = node("div", "", "row-actions");
    if (account?.role === "admin") controls.append(
      action("Edit", () => openVenue(venue.venue_id)),
      action("Delete", () => confirmRemove("venues", venue.venue_id, venue.venue_name), { danger: true })
    );
    else controls.append(node("span", "View only", "muted"));
    cell(row, controls);
    body.append(row);
  }
  if (!rows.length) tableMessage("venues", search ? "No venues match your search." : "No venues available.");
  $("venues-count").textContent = rows.length + " venue" + (rows.length === 1 ? "" : "s");
}
function renderBookings() {
  if (state.loading) return;
  const account = getSession()?.user;
  if (!account) return;
  const search = $("booking-search").value.trim().toLowerCase();
  const status = $("booking-filter").value;
  const rows = state.bookings.filter(booking =>
    (booking.booking_id + " " + booking.customer_name + " " + booking.event_name).toLowerCase().includes(search) &&
    (!status || booking.booking_status === status));
  const body = $("bookings-body");
  body.replaceChildren();
  for (const booking of rows) {
    const row = node("tr");
    cell(row, "#" + booking.booking_id);
    cell(row, booking.customer_name);
    cell(row, recordName(booking.event_name, date(booking.event_date)));
    cell(row, booking.quantity);
    cell(row, money(booking.total_amount));
    cell(row, badge(booking.booking_status));
    const controls = node("div", "", "row-actions");
    controls.append(action("Details", () => openBookingDetails(booking.booking_id)));
    if (canEditBooking(account, booking)) controls.append(action("Edit", () => openBooking(booking.booking_id)));
    if (account.role === "admin" || account.role === "customer") {
      controls.append(action("Cancel", () => confirmRemove("bookings", booking.booking_id, "booking #" + booking.booking_id), {
        danger: true, disabled: !canCancelBooking(account, booking)
      }));
    }
    cell(row, controls);
    body.append(row);
  }
  if (!rows.length) tableMessage("bookings", search || status ? "No bookings match your filters." :
    account.role === "customer" ? "You have no bookings yet. Browse events to book tickets." : "No bookings available.");
  $("bookings-count").textContent = rows.length + " booking" + (rows.length === 1 ? "" : "s");
}
function renderUsers() {
  if (state.loading) return;
  const search = $("user-search").value.trim().toLowerCase();
  const role = $("user-role-filter").value;
  const status = $("user-status-filter").value;
  const rows = state.users.filter(user =>
    (user.name + " " + user.email + " " + (user.phone || "")).toLowerCase().includes(search) &&
    (!role || user.role === role) && (!status || user.status === status));
  const body = $("users-body");
  body.replaceChildren();
  for (const user of rows) {
    const self = Number(user.user_id) === Number(getSession()?.user.user_id);
    const row = node("tr");
    cell(row, recordName(user.name, "#" + user.user_id + (self ? " · You" : "")));
    cell(row, user.email);
    cell(row, user.phone || "—");
    cell(row, ROLE_NAMES[user.role] || user.role);
    cell(row, badge(user.status));
    const controls = node("div", "", "row-actions");
    controls.append(action("Edit", () => openUser(user.user_id)),
      action("Deactivate", () => confirmRemove("users", user.user_id, user.name), {
        danger: true, disabled: self || user.status === "inactive"
      }));
    cell(row, controls);
    body.append(row);
  }
  if (!rows.length) tableMessage("users", "No users match your filters.");
  $("users-count").textContent = rows.length + " user" + (rows.length === 1 ? "" : "s");
}

async function refreshAfterSave(response, epoch, destination = state.page) {
  if (epoch !== state.epoch) return;
  const loaded = destination === state.page ? await loadCurrentPage() : await navigate(destination);
  if (epoch !== state.epoch) return;
  notice(response.message + (response.booking_id ? " · Booking #" + response.booking_id : "") +
    (loaded ? "" : " The list could not refresh. Use Refresh to try again."), loaded ? "success" : "warning");
}
async function confirmRemove(resource, id, label) {
  const epoch = state.epoch;
  const verb = resource === "users" ? "Deactivate" : resource === "venues" ? "Delete" : "Cancel";
  const note = resource === "bookings" ? "Reserved tickets will be returned." :
    resource === "venues" ? "A venue used by an event cannot be deleted." :
      resource === "users" ? "This user will no longer be able to sign in." : "The event record will be kept as cancelled.";
  if (!window.confirm(verb + " " + label + "?\n\n" + note)) return;
  const response = await service.removeRecord(resource, id);
  await refreshAfterSave(response, epoch);
}
function fill(form, values) {
  for (const [key, value] of Object.entries(values)) {
    const control = form.elements.namedItem(key);
    if (control && control.type !== "password") control.value = value ?? "";
  }
}
function selectOptions(id, records, key, label) {
  const select = $(id);
  const placeholder = node("option", "Choose an option");
  placeholder.value = "";
  select.replaceChildren(placeholder);
  for (const item of records) {
    const option = node("option", label(item));
    option.value = item[key];
    select.append(option);
  }
}
function dialogIsCurrent(ticket, epoch) {
  return ticket === state.dialogRequest && epoch === state.epoch && !!getSession();
}

async function openEvent(id = null) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  const data = await service.eventFormData(id);
  if (!dialogIsCurrent(ticket, epoch)) return;
  const current = data.event;
  const organisers = data.organisers.filter(user =>
    (["admin", "staff"].includes(user.role) && user.status === "active") ||
    Number(user.user_id) === Number(current?.organiser_id));
  const venues = data.venues.filter(venue => venue.status === "available" || Number(venue.venue_id) === Number(current?.venue_id));
  if (!organisers.length || !venues.length) throw new ApiError("An active organiser and an available venue are needed. Ask your administrator if none is available.");
  state.editingEvent = current;
  state.formVenues = data.venues;
  const form = $("event-form");
  form.reset();
  formError("event-error");
  selectOptions("event-organiser", organisers, "user_id", user => user.name + " (" + ROLE_NAMES[user.role] + ")");
  selectOptions("event-venue", venues, "venue_id", venue => venue.venue_name + " (" + venue.capacity + " seats)");
  $("event-organiser").disabled = getSession().user.role === "staff";
  $("event-dialog-title").textContent = current ? "Edit event" : "Add event";
  if (current) fill(form, { ...current, start_time: current.start_time.slice(0, 5), end_time: current.end_time.slice(0, 5) });
  else fill(form, { organiser_id: getSession().user.user_id, ticket_price: "0.00", status: "upcoming" });
  ticketNote();
  openDialog("event-dialog");
}
function ticketNote() {
  const venue = state.formVenues.find(item => Number(item.venue_id) === Number($("event-venue").value));
  const current = state.editingEvent;
  const reserved = current ? Math.max(0, Number(current.total_tickets) - Number(current.available_tickets)) : 0;
  $("ticket-note").textContent = (venue ? "Venue capacity: " + venue.capacity + ". " : "") +
    (current ? reserved + " tickets already reserved. Availability adjusts when the total changes." : "All new tickets start as available.");
}
async function openVenue(id = null) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  if (getSession()?.user.role !== "admin") throw new ApiError("Administrator access is required.", 403);
  const current = id ? await service.getRecord("venues", id) : null;
  if (!dialogIsCurrent(ticket, epoch)) return;
  state.editingVenue = current;
  $("venue-form").reset();
  formError("venue-error");
  $("venue-dialog-title").textContent = current ? "Edit venue" : "Add venue";
  if (current) fill($("venue-form"), current);
  openDialog("venue-dialog");
}
async function openUser(id = null) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  if (getSession()?.user.role !== "admin") throw new ApiError("Administrator access is required.", 403);
  const current = id ? await service.getRecord("users", id) : null;
  if (!dialogIsCurrent(ticket, epoch)) return;
  state.editingUser = current;
  $("user-form").reset();
  formError("user-error");
  $("user-dialog-title").textContent = current ? "Edit user" : "Add user";
  $("user-password").required = !current;
  $("user-password-label").textContent = current ? "New password (optional)" : "Password";
  $("user-password-note").textContent = current ? "Leave blank to keep the existing password." : "Use at least six characters.";
  const self = Number(current?.user_id) === Number(getSession().user.user_id);
  $("user-role").disabled = self;
  $("user-status").disabled = self;
  $("self-account-note").hidden = !self;
  if (current) fill($("user-form"), current);
  openDialog("user-dialog");
}
async function openBooking(id) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  const booking = await service.bookingDetails(id);
  if (!dialogIsCurrent(ticket, epoch)) return;
  if (!canEditBooking(getSession().user, booking)) throw new ApiError("You cannot edit this booking.", 403);
  state.editingBooking = booking;
  $("booking-form").reset();
  formError("booking-error");
  $("booking-dialog-title").textContent = "Edit booking #" + booking.booking_id;
  $("booking-summary").textContent = booking.customer_name + " · " + booking.event_name;
  fill($("booking-form"), booking);
  bookingTotal();
  openDialog("booking-dialog");
}
function bookingTotal() {
  const booking = state.editingBooking;
  if (!booking) return;
  const cancelled = $("booking-status").value === "cancelled";
  $("booking-quantity").disabled = cancelled;
  if (cancelled) $("booking-quantity").value = booking.quantity;
  $("booking-total-note").textContent = cancelled ? "Original quantity is retained when cancelling." :
    "Estimated total: " + money(Number($("booking-quantity").value) * Number(booking.ticket_price)) + " at the current event price.";
}
async function openPurchase(id) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  const event = await service.getRecord("events", id);
  if (!dialogIsCurrent(ticket, epoch)) return;
  if (!canBook(getSession().user, event)) throw new ApiError("This event is not currently available for booking.", 400);
  state.purchaseEvent = event;
  $("purchase-form").reset();
  formError("purchase-error");
  $("purchase-event-name").textContent = event.event_name;
  $("purchase-summary").textContent = date(event.event_date) + " · " + event.venue_name + " · " +
    money(event.ticket_price) + " per ticket · " + event.available_tickets + " available";
  $("purchase-quantity").max = event.available_tickets;
  purchaseTotal();
  openDialog("purchase-dialog");
}
function purchaseTotal() {
  const quantity = Number($("purchase-quantity").value);
  $("purchase-total").textContent = Number.isSafeInteger(quantity) && quantity > 0
    ? money(quantity * Number(state.purchaseEvent?.ticket_price)) : "—";
}

function detailFields(fields) {
  const list = $("details-list");
  list.replaceChildren();
  for (const [label, value] of Object.entries(fields)) list.append(node("dt", label), node("dd", value || "—"));
}
async function openEventDetails(id) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  const event = await service.getRecord("events", id);
  if (!dialogIsCurrent(ticket, epoch)) return;
  openDialog("details-dialog");
  state.detailsEvent = event;
  $("details-title").textContent = event.event_name;
  $("details-description").textContent = event.description || "No description provided.";
  $("details-description").hidden = false;
  detailFields({
    Venue: event.venue_name + " · " + event.venue_location,
    Organiser: event.organiser_name, Date: date(event.event_date),
    Time: event.start_time.slice(0, 5) + " – " + event.end_time.slice(0, 5),
    "Ticket price": money(event.ticket_price), "Tickets available": event.available_tickets + " of " + event.total_tickets,
    Status: title(event.status)
  });
  $("weather-section").hidden = false;
  $("weather-result").textContent = "Check the latest conditions for this location.";
  $("weather-button").disabled = false;
  $("details-book-button").hidden = !canBook(getSession().user, event);
}
async function openBookingDetails(id) {
  const ticket = ++state.dialogRequest;
  const epoch = state.epoch;
  const booking = await service.bookingDetails(id);
  if (!dialogIsCurrent(ticket, epoch)) return;
  openDialog("details-dialog");
  state.detailsEvent = null;
  $("details-title").textContent = "Booking #" + booking.booking_id;
  $("details-description").hidden = true;
  $("weather-section").hidden = true;
  $("details-book-button").hidden = true;
  detailFields({
    Event: booking.event_name, Customer: booking.customer_name, "Event date": date(booking.event_date),
    Quantity: String(booking.quantity), Total: money(booking.total_amount), Status: title(booking.booking_status),
    "Booked on": booking.booking_date ? booking.booking_date.replace("T", " ") : "—"
  });
}

async function submitForm(name, callback, destination) {
  const form = $(name + "-form");
  const dialog = $(name + "-dialog");
  if (dialog.dataset.saving === "true") return;
  formError(name + "-error");
  if (!form.reportValidity()) return;
  const values = Object.fromEntries(new FormData(form));
  const epoch = state.epoch;
  const controls = [...dialog.querySelectorAll("button, input, select, textarea")].map(el => ({ el, disabled: el.disabled }));
  const save = dialog.querySelector(".save-button");
  const original = save.textContent;
  dialog.dataset.saving = "true";
  controls.forEach(({ el }) => { el.disabled = true; });
  save.textContent = name === "purchase" ? "Booking..." : "Saving...";
  try {
    const response = await callback(values, epoch);
    if (epoch !== state.epoch) return;
    dialog.close();
    await refreshAfterSave(response, epoch, destination || state.page);
  } catch (error) {
    if (epoch === state.epoch) handleError(error, name + "-error");
  } finally {
    controls.forEach(({ el, disabled }) => { el.disabled = disabled; });
    dialog.dataset.saving = "false";
    save.textContent = original;
  }
}

$("login-form").addEventListener("submit", async event => {
  event.preventDefault();
  const button = $("login-submit");
  if (button.disabled || !$("login-form").reportValidity()) return;
  formError("login-error");
  button.disabled = true;
  button.textContent = "Signing in...";
  try {
    const result = await request("auth/login.php", { method: "POST", auth: false, body: {
      email: $("login-email").value.trim(), password: $("login-password").value
    } });
    saveSession(result);
    $("login-form").reset();
    showApp();
  } catch (error) { formError("login-error", error.message); }
  finally { button.disabled = false; button.textContent = "Sign in"; }
});
$("logout-button").addEventListener("click", async () => {
  if ($("logout-button").disabled) return;
  $("logout-button").disabled = true;
  let failed = false;
  try { await request("auth/logout.php", { method: "POST" }); }
  catch (error) { failed = error.status !== 401; }
  finally {
    clearSession();
    showLogin(failed ? "Signed out on this device. Server sign-out could not be confirmed." : "");
    $("logout-button").disabled = false;
  }
});
$("event-search-form").addEventListener("submit", event => {
  event.preventDefault();
  state.search = $("event-search").value.trim();
  state.eventsPage = 1;
  loadCurrentPage();
});
$("event-search").addEventListener("input", () => {
  if (!$("event-search").value && state.search) {
    state.search = "";
    state.eventsPage = 1;
    loadCurrentPage();
  }
});
$("event-scope").addEventListener("change", () => {
  state.scope = $("event-scope").value;
  state.eventsPage = 1;
  loadCurrentPage();
});
$("previous-page").addEventListener("click", () => {
  if (!state.loading && state.eventsPage > 1) { state.eventsPage--; loadCurrentPage(); }
});
$("next-page").addEventListener("click", () => {
  if (!state.loading && state.eventsPage < state.totalPages) { state.eventsPage++; loadCurrentPage(); }
});
$("venue-search").addEventListener("input", renderVenues);
$("booking-search").addEventListener("input", renderBookings);
$("booking-filter").addEventListener("change", renderBookings);
$("user-search").addEventListener("input", renderUsers);
$("user-role-filter").addEventListener("change", renderUsers);
$("user-status-filter").addEventListener("change", renderUsers);
document.querySelectorAll(".refresh-button").forEach(button => button.addEventListener("click", loadCurrentPage));

function addButton(id, opener) {
  $(id).addEventListener("click", async () => {
    const button = $(id);
    if (button.disabled) return;
    const epoch = state.epoch;
    const label = button.textContent;
    button.disabled = true;
    button.textContent = "Loading...";
    try { await opener(); }
    catch (error) { if (epoch === state.epoch) handleError(error); }
    finally { button.disabled = false; button.textContent = label; }
  });
}
addButton("add-event", () => openEvent());
addButton("add-venue", () => openVenue());
addButton("add-user", () => openUser());
$("event-venue").addEventListener("change", ticketNote);
$("booking-quantity").addEventListener("input", bookingTotal);
$("booking-status").addEventListener("change", bookingTotal);
$("purchase-quantity").addEventListener("input", purchaseTotal);
$("event-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm("event", async (values, epoch) => {
    const current = state.editingEvent;
    const response = await service.saveEvent(values, current?.event_id);
    if (!current && epoch === state.epoch) {
      state.search = "";
      $("event-search").value = "";
      state.eventsPage = 1;
      state.showLastEventPage = true;
    }
    return response;
  });
});
$("venue-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm("venue", async (values, epoch) => {
    const response = await service.saveVenue(values, state.editingVenue?.venue_id);
    if (epoch === state.epoch) $("venue-search").value = "";
    return response;
  });
});
$("user-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm("user", async (values, epoch) => {
    const current = state.editingUser;
    const session = getSession();
    const self = Number(current?.user_id) === Number(session.user.user_id);
    const submitted = self ? { ...values, role: "admin", status: "active" } : values;
    const response = await service.saveUser(submitted, current?.user_id);
    if (epoch === state.epoch && self && getSession()?.token === session.token) {
      saveSession({ ...session, user: { ...session.user, name: values.name.trim(), email: values.email.trim(), phone: (values.phone || "").trim() } });
      $("account-name").textContent = values.name.trim();
    }
    if (epoch === state.epoch) {
      for (const id of ["user-search", "user-role-filter", "user-status-filter"]) $(id).value = "";
    }
    return response;
  });
});
$("booking-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm("booking", values => service.saveBooking(values, state.editingBooking.booking_id));
});
$("purchase-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm("purchase", values => service.createBooking(values, state.purchaseEvent.event_id), "bookings");
});
$("details-book-button").addEventListener("click", async () => {
  if (!state.detailsEvent || $("details-book-button").disabled) return;
  const epoch = state.epoch;
  const eventId = state.detailsEvent.event_id;
  $("details-book-button").disabled = true;
  try { await openPurchase(eventId); }
  catch (error) { if (epoch === state.epoch) handleError(error); }
  finally { $("details-book-button").disabled = false; }
});

document.querySelectorAll(".close-dialog").forEach(button =>
  button.addEventListener("click", () => button.closest("dialog").close()));
document.querySelectorAll("dialog").forEach(dialog => {
  dialog.addEventListener("cancel", event => {
    if (dialog.dataset.saving === "true") event.preventDefault();
  });
});
$("details-dialog").addEventListener("close", () => {
  if (!$("details-dialog").open) state.weatherController?.abort();
});
$("weather-button").addEventListener("click", async () => {
  if (!state.detailsEvent || $("weather-button").disabled) return;
  const eventId = state.detailsEvent.event_id;
  const epoch = state.epoch;
  state.weatherController?.abort();
  const controller = new AbortController();
  state.weatherController = controller;
  $("weather-button").disabled = true;
  $("weather-result").textContent = "Loading weather...";
  try {
    const response = await request("api/weather/?event_id=" + eventId, { signal: controller.signal });
    if (controller.signal.aborted || epoch !== state.epoch || state.detailsEvent?.event_id !== eventId) return;
    const weather = response.weather;
    if (!weather) throw new ApiError("Weather is unavailable for this location.");
    const parts = [weather.condition || "Current conditions"];
    if (weather.temperature != null) parts.push(weather.temperature + (weather.temperature_unit || "°C"));
    if (weather.humidity != null) parts.push("Humidity " + weather.humidity + (weather.humidity_unit || "%"));
    if (weather.wind_speed != null) parts.push("Wind " + weather.wind_speed + " " + (weather.wind_speed_unit || "km/h"));
    if (weather.time) parts.push("Updated " + weather.time.replace("T", " "));
    $("weather-result").textContent = parts.join(" · ");
  } catch (error) {
    if (controller.signal.aborted || epoch !== state.epoch) return;
    $("weather-result").textContent = error.message;
    if (error.status === 401) handleError(error);
  } finally {
    if (epoch === state.epoch && state.detailsEvent?.event_id === eventId) $("weather-button").disabled = false;
  }
});
document.querySelector(".skip-link").addEventListener("click", event => {
  event.preventDefault();
  $("main-content").focus();
});
window.addEventListener("hashchange", route);
if (getSession()) showApp(); else showLogin();
