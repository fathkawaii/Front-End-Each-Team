export class EventApi {
  constructor(base,token='',onUnauthorized=()=>{}) {
    this.base=base.replace(/\/+$/,''); this.token=token; this.onUnauthorized=onUnauthorized;
  }
  async request(path,method='GET',body) {
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),18000);
    try {
      const headers={Accept:'application/json'};
      if(this.token)headers.Authorization=`Bearer ${this.token}`;
      if(body!==undefined)headers['Content-Type']='application/json';
      const res=await fetch(`${this.base}/${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:controller.signal,cache:'no-store'});
      let json;
      try { json=await res.json(); } catch { throw Error('The server did not return JSON. Check your API address and PHP server.'); }
      if(!res.ok||json.status===false) {
        if(res.status===401&&this.token)this.onUnauthorized();
        throw Error(json.message||`Request failed (${res.status}).`);
      }
      return json;
    } catch(err) {
      if(err.name==='AbortError')throw Error('The server took too long to respond. Please try again.');
      if(err instanceof TypeError)throw Error('Cannot reach the API. Check that Apache and MySQL are running and the API address is correct.');
      throw err;
    } finally {clearTimeout(timer);}
  }
  async allEvents() {
    const first=await this.request('api/events/index.php?page=1&limit=50');
    const all=[...(first.data??[])];
    const total=Number(first.pagination?.total_pages??1);
    for(let page=2;page<=total;page+=6){
      const pages=Array.from({length:Math.min(6,total-page+1)},(_,i)=>page+i);
      const results=await Promise.all(pages.map(p=>this.request(`api/events/index.php?page=${p}&limit=50`)));
      for(const r of results)all.push(...(r.data??[]));
    }
    return all;
  }
  async load(user) {
    const tasks=[this.allEvents(),this.request('api/bookings/index.php').then(r=>r.data??[])];
    if(user.role==='admin')tasks.push(this.request('api/venues/index.php').then(r=>r.data??[]),this.request('api/users/index.php').then(r=>r.data??[]));
    const [events,bookings,venues=[],users=[]]=await Promise.all(tasks);
    return {events,bookings,venues,users};
  }
  save(type,id,data) { return this.request(`api/${type}/index.php${id?'?id='+encodeURIComponent(id):''}`,id?'PUT':'POST',data); }
  remove(type,id) {return this.request(`api/${type}/index.php?id=${encodeURIComponent(id)}`,'DELETE');}
  weather(id) {return this.request(`api/weather/index.php?event_id=${encodeURIComponent(id)}`);}
}
