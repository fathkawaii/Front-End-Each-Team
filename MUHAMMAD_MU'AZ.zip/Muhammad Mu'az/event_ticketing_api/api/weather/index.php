<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../../config/database.php";
require_once "../../helpers/auth.php";


// =====================================================
// HANDLE OPTIONS
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


// =====================================================
// ONLY GET METHOD
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);

    echo json_encode([
        "status" => false,
        "message" => "Method not allowed"
    ]);

    exit;
}


// =====================================================
// AUTHENTICATE USER
// Admin / Staff / Customer can use weather API
// =====================================================

$currentUser = authenticateUser();


// =====================================================
// CHECK EVENT ID
// =====================================================

$eventId = isset($_GET['event_id'])
    ? intval($_GET['event_id'])
    : null;


if (!$eventId) {

    http_response_code(400);

    echo json_encode([
        "status" => false,
        "message" => "Event ID is required"
    ]);

    exit;
}


// =====================================================
// GET EVENT + VENUE
// =====================================================

$stmt = $conn->prepare("
    SELECT
        e.event_id,
        e.event_name,
        e.event_date,
        e.start_time,
        e.status AS event_status,
        v.venue_id,
        v.venue_name,
        v.location
    FROM events e
    INNER JOIN venues v
        ON e.venue_id = v.venue_id
    WHERE e.event_id = ?
");

$stmt->execute([
    $eventId
]);

$event = $stmt->fetch(
    PDO::FETCH_ASSOC
);


if (!$event) {

    http_response_code(404);

    echo json_encode([
        "status" => false,
        "message" => "Event or venue not found"
    ]);

    exit;
}


// =====================================================
// FUNCTION TO CALL EXTERNAL API
// =====================================================

function callExternalApi($url)
{
    // Use cURL if available
    if (function_exists('curl_init')) {

        $ch = curl_init();

        curl_setopt_array(
            $ch,
            [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_HTTPHEADER => [
                    "Accept: application/json"
                ]
            ]
        );

        $response = curl_exec($ch);

        $httpCode = curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );

        $error = curl_error($ch);

        curl_close($ch);


        if ($response === false || $error) {

            return [
                "success" => false,
                "http_code" => $httpCode,
                "response" => null,
                "error" => $error
            ];
        }


        return [
            "success" => true,
            "http_code" => $httpCode,
            "response" => $response,
            "error" => null
        ];
    }


    // Fallback if cURL is unavailable
    $context = stream_context_create([
        "http" => [
            "method" => "GET",
            "timeout" => 15,
            "header" => "Accept: application/json\r\n"
        ]
    ]);


    $response = @file_get_contents(
        $url,
        false,
        $context
    );


    if ($response === false) {

        return [
            "success" => false,
            "http_code" => 0,
            "response" => null,
            "error" => "Unable to connect to external API"
        ];
    }


    return [
        "success" => true,
        "http_code" => 200,
        "response" => $response,
        "error" => null
    ];
}


// =====================================================
// WEATHER CODE DESCRIPTION
// =====================================================

function getWeatherDescription($code)
{
    $code = intval($code);

    if ($code === 0) {
        return "Clear sky";
    }

    if (in_array($code, [1, 2, 3])) {
        return "Partly cloudy";
    }

    if (in_array($code, [45, 48])) {
        return "Fog";
    }

    if (in_array($code, [51, 53, 55])) {
        return "Drizzle";
    }

    if (in_array($code, [56, 57])) {
        return "Freezing drizzle";
    }

    if (in_array($code, [61, 63, 65])) {
        return "Rain";
    }

    if (in_array($code, [66, 67])) {
        return "Freezing rain";
    }

    if (in_array($code, [71, 73, 75, 77])) {
        return "Snow";
    }

    if (in_array($code, [80, 81, 82])) {
        return "Rain showers";
    }

    if (in_array($code, [85, 86])) {
        return "Snow showers";
    }

    if (in_array($code, [95, 96, 99])) {
        return "Thunderstorm";
    }

    return "Unknown weather condition";
}


// =====================================================
// STEP 1:
// CONVERT VENUE LOCATION TO LATITUDE/LONGITUDE
// USING OPEN-METEO GEOCODING API
// =====================================================

$location = trim(
    $event['location']
);


$geocodingUrl =
    "https://geocoding-api.open-meteo.com/v1/search"
    . "?name="
    . urlencode($location)
    . "&count=1"
    . "&language=en"
    . "&format=json";


$geoResult = callExternalApi(
    $geocodingUrl
);


if (!$geoResult['success']) {

    http_response_code(502);

    echo json_encode([
        "status" => false,
        "message" => "Unable to connect to geocoding service"
    ]);

    exit;
}


$geoData = json_decode(
    $geoResult['response'],
    true
);


if (
    !isset($geoData['results']) ||
    empty($geoData['results'])
) {

    http_response_code(404);

    echo json_encode([
        "status" => false,
        "message" => "Venue location could not be found by external API",
        "location" => $location
    ]);

    exit;
}


$place = $geoData['results'][0];

$latitude = $place['latitude'];
$longitude = $place['longitude'];


// =====================================================
// STEP 2:
// GET CURRENT WEATHER
// =====================================================

$weatherUrl =
    "https://api.open-meteo.com/v1/forecast"
    . "?latitude="
    . urlencode($latitude)
    . "&longitude="
    . urlencode($longitude)
    . "&current="
    . "temperature_2m,"
    . "relative_humidity_2m,"
    . "apparent_temperature,"
    . "precipitation,"
    . "weather_code,"
    . "wind_speed_10m"
    . "&timezone=auto";


$weatherResult = callExternalApi(
    $weatherUrl
);


if (!$weatherResult['success']) {

    http_response_code(502);

    echo json_encode([
        "status" => false,
        "message" => "Unable to connect to weather service"
    ]);

    exit;
}


$weatherData = json_decode(
    $weatherResult['response'],
    true
);


if (
    !isset($weatherData['current'])
) {

    http_response_code(502);

    echo json_encode([
        "status" => false,
        "message" => "Invalid response from weather service"
    ]);

    exit;
}


$current = $weatherData['current'];


// =====================================================
// SUCCESS RESPONSE
// =====================================================

echo json_encode([
    "status" => true,

    "message" =>
        "External weather data retrieved successfully",

    "external_api" => [
        "provider" => "Open-Meteo",
        "service" => "Weather Forecast API",
        "authentication" =>
            "No API key required"
    ],

    "event" => [
        "event_id" =>
            intval($event['event_id']),

        "event_name" =>
            $event['event_name'],

        "event_date" =>
            $event['event_date'],

        "start_time" =>
            $event['start_time'],

        "event_status" =>
            $event['event_status']
    ],

    "venue" => [
        "venue_id" =>
            intval($event['venue_id']),

        "venue_name" =>
            $event['venue_name'],

        "location" =>
            $event['location'],

        "resolved_location" =>
            $place['name'] ?? $location,

        "country" =>
            $place['country'] ?? null,

        "latitude" =>
            $latitude,

        "longitude" =>
            $longitude
    ],

    "weather" => [
        "time" =>
            $current['time'] ?? null,

        "temperature" =>
            $current['temperature_2m'] ?? null,

        "temperature_unit" =>
            $weatherData['current_units']['temperature_2m']
            ?? "°C",

        "feels_like" =>
            $current['apparent_temperature']
            ?? null,

        "humidity" =>
            $current['relative_humidity_2m']
            ?? null,

        "humidity_unit" =>
            "%",

        "precipitation" =>
            $current['precipitation']
            ?? null,

        "precipitation_unit" =>
            $weatherData['current_units']['precipitation']
            ?? "mm",

        "wind_speed" =>
            $current['wind_speed_10m']
            ?? null,

        "wind_speed_unit" =>
            $weatherData['current_units']['wind_speed_10m']
            ?? "km/h",

        "weather_code" =>
            $current['weather_code']
            ?? null,

        "condition" =>
            getWeatherDescription(
                $current['weather_code']
                ?? -1
            )
    ]
]);

?>
