<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../../config/database.php";
require_once "../../helpers/auth.php";


// =====================================================
// HANDLE OPTIONS
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


// =====================================================
// AUTHENTICATE USER
// =====================================================

$currentUser = authenticateUser();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id'])
    ? intval($_GET['id'])
    : null;


// =====================================================
// MAIN REQUEST
// =====================================================

switch ($method) {

    // =====================================================
    // GET BOOKING / BOOKINGS
    // =====================================================

    case 'GET':

        // -------------------------------------------------
        // GET ONE BOOKING
        // -------------------------------------------------

        if ($id) {

            $stmt = $conn->prepare("
                SELECT
                    b.booking_id,
                    b.customer_id,
                    u.name AS customer_name,
                    b.event_id,
                    e.event_name,
                    e.organiser_id,
                    e.event_date,
                    e.start_time,
                    e.end_time,
                    e.ticket_price,
                    b.quantity,
                    b.total_amount,
                    b.booking_date,
                    b.booking_status
                FROM bookings b
                INNER JOIN users u
                    ON b.customer_id = u.user_id
                INNER JOIN events e
                    ON b.event_id = e.event_id
                WHERE b.booking_id = ?
            ");

            $stmt->execute([
                $id
            ]);

            $booking = $stmt->fetch(
                PDO::FETCH_ASSOC
            );


            if (!$booking) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,
                    "message" => "Booking not found"
                ]);

                exit;
            }


            // Customer can only view own booking
            if (
                $currentUser['role'] === 'customer' &&
                intval($booking['customer_id']) !==
                intval($currentUser['user_id'])
            ) {

                http_response_code(403);

                echo json_encode([
                    "status" => false,
                    "message" => "You can only view your own bookings"
                ]);

                exit;
            }


            // Staff can only view booking for event they manage
            if (
                $currentUser['role'] === 'staff' &&
                intval($booking['organiser_id']) !==
                intval($currentUser['user_id'])
            ) {

                http_response_code(403);

                echo json_encode([
                    "status" => false,
                    "message" => "You can only view bookings for your own events"
                ]);

                exit;
            }


            echo json_encode([
                "status" => true,
                "message" => "Booking retrieved successfully",
                "data" => $booking
            ]);

        } else {

            // -------------------------------------------------
            // ADMIN - VIEW ALL BOOKINGS
            // -------------------------------------------------

            if ($currentUser['role'] === 'admin') {

                $stmt = $conn->prepare("
                    SELECT
                        b.booking_id,
                        b.customer_id,
                        u.name AS customer_name,
                        b.event_id,
                        e.event_name,
                        e.organiser_id,
                        e.event_date,
                        e.ticket_price,
                        b.quantity,
                        b.total_amount,
                        b.booking_date,
                        b.booking_status
                    FROM bookings b
                    INNER JOIN users u
                        ON b.customer_id = u.user_id
                    INNER JOIN events e
                        ON b.event_id = e.event_id
                    ORDER BY b.booking_id ASC
                ");

                $stmt->execute();
            }


            // -------------------------------------------------
            // STAFF - VIEW BOOKINGS FOR OWN EVENTS
            // -------------------------------------------------

            elseif ($currentUser['role'] === 'staff') {

                $stmt = $conn->prepare("
                    SELECT
                        b.booking_id,
                        b.customer_id,
                        u.name AS customer_name,
                        b.event_id,
                        e.event_name,
                        e.organiser_id,
                        e.event_date,
                        e.ticket_price,
                        b.quantity,
                        b.total_amount,
                        b.booking_date,
                        b.booking_status
                    FROM bookings b
                    INNER JOIN users u
                        ON b.customer_id = u.user_id
                    INNER JOIN events e
                        ON b.event_id = e.event_id
                    WHERE e.organiser_id = ?
                    ORDER BY b.booking_id ASC
                ");

                $stmt->execute([
                    $currentUser['user_id']
                ]);
            }


            // -------------------------------------------------
            // CUSTOMER - VIEW OWN BOOKINGS ONLY
            // -------------------------------------------------

            else {

                $stmt = $conn->prepare("
                    SELECT
                        b.booking_id,
                        b.customer_id,
                        u.name AS customer_name,
                        b.event_id,
                        e.event_name,
                        e.event_date,
                        e.ticket_price,
                        b.quantity,
                        b.total_amount,
                        b.booking_date,
                        b.booking_status
                    FROM bookings b
                    INNER JOIN users u
                        ON b.customer_id = u.user_id
                    INNER JOIN events e
                        ON b.event_id = e.event_id
                    WHERE b.customer_id = ?
                    ORDER BY b.booking_id ASC
                ");

                $stmt->execute([
                    $currentUser['user_id']
                ]);
            }


            $bookings = $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );


            echo json_encode([
                "status" => true,
                "message" => "Bookings retrieved successfully",
                "data" => $bookings
            ]);
        }

        break;


    // =====================================================
    // CREATE BOOKING
    // CUSTOMER ONLY
    // =====================================================

    case 'POST':

        if ($currentUser['role'] !== 'customer') {

            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" => "Only customers can create bookings"
            ]);

            exit;
        }


        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        if (
            empty($data['event_id']) ||
            empty($data['quantity'])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Event ID and quantity are required"
            ]);

            exit;
        }


        // IMPORTANT:
        // customer_id comes from login token
        // not from JSON body

        $customer_id =
            intval($currentUser['user_id']);

        $event_id =
            intval($data['event_id']);

        $quantity =
            intval($data['quantity']);


        if ($quantity <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Quantity must be greater than 0"
            ]);

            exit;
        }


        // =================================================
        // CHECK EVENT
        // =================================================

        $eventCheck = $conn->prepare("
            SELECT
                event_id,
                event_name,
                ticket_price,
                available_tickets,
                status
            FROM events
            WHERE event_id = ?
        ");

        $eventCheck->execute([
            $event_id
        ]);

        $event = $eventCheck->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$event) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Event not found"
            ]);

            exit;
        }


        // Only upcoming event can be booked
        if ($event['status'] !== 'upcoming') {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "This event is not available for booking"
            ]);

            exit;
        }


        if (
            $quantity >
            intval($event['available_tickets'])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Not enough tickets available"
            ]);

            exit;
        }


        // =================================================
        // CALCULATE TOTAL
        // =================================================

        $ticket_price =
            floatval($event['ticket_price']);

        $total_amount =
            $ticket_price * $quantity;

        $booking_status =
            'pending';


        // =================================================
        // INSERT BOOKING
        // =================================================

        try {

            $conn->beginTransaction();


            $stmt = $conn->prepare("
                INSERT INTO bookings
                (
                    customer_id,
                    event_id,
                    quantity,
                    total_amount,
                    booking_status
                )
                VALUES
                (?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $customer_id,
                $event_id,
                $quantity,
                $total_amount,
                $booking_status
            ]);


            $booking_id =
                $conn->lastInsertId();


            // Reduce ticket availability
            $ticketUpdate = $conn->prepare("
                UPDATE events
                SET available_tickets =
                    available_tickets - ?
                WHERE event_id = ?
            ");


            $ticketUpdate->execute([
                $quantity,
                $event_id
            ]);


            $conn->commit();


            http_response_code(201);


            echo json_encode([
                "status" => true,
                "message" => "Booking created successfully",
                "booking_id" => $booking_id,
                "customer_id" => $customer_id,
                "event_id" => $event_id,
                "quantity" => $quantity,
                "ticket_price" => number_format(
                    $ticket_price,
                    2,
                    '.',
                    ''
                ),
                "total_amount" => number_format(
                    $total_amount,
                    2,
                    '.',
                    ''
                ),
                "booking_status" => $booking_status
            ]);

        } catch (PDOException $e) {

            if ($conn->inTransaction()) {
                $conn->rollBack();
            }


            http_response_code(500);


            echo json_encode([
                "status" => false,
                "message" => "Failed to create booking"
            ]);
        }

        break;


    // =====================================================
    // UPDATE BOOKING
    // ADMIN / STAFF ONLY
    // =====================================================

    case 'PUT':

        if (
            !in_array(
                $currentUser['role'],
                ['admin', 'staff']
            )
        ) {

            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" => "Only admin or staff can update bookings"
            ]);

            exit;
        }


        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Booking ID is required"
            ]);

            exit;
        }


        // =================================================
        // GET EXISTING BOOKING
        // =================================================

        $check = $conn->prepare("
            SELECT
                b.*,
                e.organiser_id,
                e.ticket_price,
                e.available_tickets
            FROM bookings b
            INNER JOIN events e
                ON b.event_id = e.event_id
            WHERE b.booking_id = ?
        ");

        $check->execute([
            $id
        ]);


        $existingBooking =
            $check->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$existingBooking) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Booking not found"
            ]);

            exit;
        }


        // Staff can only update bookings for own event
        if (
            $currentUser['role'] === 'staff' &&
            intval($existingBooking['organiser_id']) !==
            intval($currentUser['user_id'])
        ) {

            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" => "You can only manage bookings for your own events"
            ]);

            exit;
        }


        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        $newQuantity =
            isset($data['quantity'])
            ? intval($data['quantity'])
            : intval($existingBooking['quantity']);


        $newStatus =
            $data['booking_status']
            ?? $existingBooking['booking_status'];


        if ($newQuantity <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Quantity must be greater than 0"
            ]);

            exit;
        }


        $allowedStatus = [
            'pending',
            'confirmed',
            'cancelled'
        ];


        if (
            !in_array(
                $newStatus,
                $allowedStatus
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Booking status must be pending, confirmed or cancelled"
            ]);

            exit;
        }


        $oldQuantity =
            intval($existingBooking['quantity']);

        $oldStatus =
            $existingBooking['booking_status'];

        $availableTickets =
            intval($existingBooking['available_tickets']);

        $ticketAdjustment = 0;


        // =================================================
        // CALCULATE TICKET ADJUSTMENT
        // =================================================

        if ($oldStatus !== 'cancelled') {

            // Active booking becomes cancelled
            if ($newStatus === 'cancelled') {

                // Keep original quantity when cancelling
                $newQuantity = $oldQuantity;

                // Return tickets
                $ticketAdjustment =
                    $oldQuantity;

            } else {

                $difference =
                    $newQuantity -
                    $oldQuantity;


                if (
                    $difference > 0 &&
                    $difference > $availableTickets
                ) {

                    http_response_code(400);

                    echo json_encode([
                        "status" => false,
                        "message" => "Not enough tickets available"
                    ]);

                    exit;
                }


                // Increase booking = reduce available tickets
                // Reduce booking = return tickets

                $ticketAdjustment =
                    -$difference;
            }

        } else {

            // Reactivate cancelled booking
            if ($newStatus !== 'cancelled') {

                if (
                    $newQuantity >
                    $availableTickets
                ) {

                    http_response_code(400);

                    echo json_encode([
                        "status" => false,
                        "message" => "Not enough tickets available"
                    ]);

                    exit;
                }


                $ticketAdjustment =
                    -$newQuantity;
            }
        }


        $total_amount =
            floatval(
                $existingBooking['ticket_price']
            ) * $newQuantity;


        // =================================================
        // UPDATE BOOKING
        // =================================================

        try {

            $conn->beginTransaction();


            $stmt = $conn->prepare("
                UPDATE bookings
                SET
                    quantity = ?,
                    total_amount = ?,
                    booking_status = ?
                WHERE booking_id = ?
            ");


            $stmt->execute([
                $newQuantity,
                $total_amount,
                $newStatus,
                $id
            ]);


            if ($ticketAdjustment != 0) {

                $ticketUpdate =
                    $conn->prepare("
                        UPDATE events
                        SET available_tickets =
                            available_tickets + ?
                        WHERE event_id = ?
                    ");


                $ticketUpdate->execute([
                    $ticketAdjustment,
                    $existingBooking['event_id']
                ]);
            }


            $conn->commit();


            echo json_encode([
                "status" => true,
                "message" => "Booking updated successfully",
                "booking_id" => $id,
                "quantity" => $newQuantity,
                "total_amount" => number_format(
                    $total_amount,
                    2,
                    '.',
                    ''
                ),
                "booking_status" => $newStatus
            ]);

        } catch (PDOException $e) {

            if ($conn->inTransaction()) {
                $conn->rollBack();
            }


            http_response_code(500);


            echo json_encode([
                "status" => false,
                "message" => "Failed to update booking"
            ]);
        }

        break;


    // =====================================================
    // DELETE / CANCEL BOOKING
    // CUSTOMER OWN BOOKING OR ADMIN
    // =====================================================

    case 'DELETE':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Booking ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT *
            FROM bookings
            WHERE booking_id = ?
        ");

        $check->execute([
            $id
        ]);


        $booking = $check->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$booking) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Booking not found"
            ]);

            exit;
        }


        // Staff cannot cancel bookings
        if ($currentUser['role'] === 'staff') {

            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" => "Staff cannot cancel customer bookings"
            ]);

            exit;
        }


        // Customer only cancels own booking
        if (
            $currentUser['role'] === 'customer' &&
            intval($booking['customer_id']) !==
            intval($currentUser['user_id'])
        ) {

            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" => "You can only cancel your own booking"
            ]);

            exit;
        }


        if (
            $booking['booking_status']
            === 'cancelled'
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Booking is already cancelled"
            ]);

            exit;
        }


        // =================================================
        // CANCEL BOOKING
        // =================================================

        try {

            $conn->beginTransaction();


            $stmt = $conn->prepare("
                UPDATE bookings
                SET booking_status = 'cancelled'
                WHERE booking_id = ?
            ");


            $stmt->execute([
                $id
            ]);


            // Return tickets
            $ticketUpdate = $conn->prepare("
                UPDATE events
                SET available_tickets =
                    available_tickets + ?
                WHERE event_id = ?
            ");


            $ticketUpdate->execute([
                $booking['quantity'],
                $booking['event_id']
            ]);


            $conn->commit();


            echo json_encode([
                "status" => true,
                "message" => "Booking cancelled successfully"
            ]);

        } catch (PDOException $e) {

            if ($conn->inTransaction()) {
                $conn->rollBack();
            }


            http_response_code(500);


            echo json_encode([
                "status" => false,
                "message" => "Failed to cancel booking"
            ]);
        }

        break;


    // =====================================================
    // INVALID METHOD
    // =====================================================

    default:

        http_response_code(405);

        echo json_encode([
            "status" => false,
            "message" => "Method not allowed"
        ]);

        break;
}

?>