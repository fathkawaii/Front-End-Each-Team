<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../../config/database.php";
require_once "../../helpers/auth.php";


// =====================================================
// HANDLE OPTIONS REQUEST
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


// =====================================================
// ADMIN ONLY
// =====================================================

$currentUser = requireAdmin();


// =====================================================
// REQUEST METHOD + ID
// =====================================================

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id'])
    ? intval($_GET['id'])
    : null;


switch ($method) {

    // =====================================================
    // GET USER / USERS
    // =====================================================

    case 'GET':

        if ($id) {

            $stmt = $conn->prepare("
                SELECT
                    user_id,
                    name,
                    email,
                    phone,
                    role,
                    status,
                    created_at
                FROM users
                WHERE user_id = ?
            ");

            $stmt->execute([
                $id
            ]);

            $user = $stmt->fetch(
                PDO::FETCH_ASSOC
            );


            if (!$user) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,
                    "message" => "User not found"
                ]);

                exit;
            }


            echo json_encode([
                "status" => true,
                "message" => "User retrieved successfully",
                "data" => $user
            ]);

        } else {

            $stmt = $conn->prepare("
                SELECT
                    user_id,
                    name,
                    email,
                    phone,
                    role,
                    status,
                    created_at
                FROM users
                ORDER BY user_id ASC
            ");

            $stmt->execute();

            $users = $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );


            echo json_encode([
                "status" => true,
                "message" => "Users retrieved successfully",
                "data" => $users
            ]);
        }

        break;


    // =====================================================
    // CREATE USER
    // =====================================================

    case 'POST':

        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        if (
            empty($data['name']) ||
            empty($data['email']) ||
            empty($data['password']) ||
            empty($data['role'])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Name, email, password and role are required"
            ]);

            exit;
        }


        $name = trim(
            $data['name']
        );

        $email = trim(
            $data['email']
        );

        $password =
            $data['password'];

        $phone =
            $data['phone'] ?? null;

        $role = strtolower(
            trim($data['role'])
        );

        $status =
            $data['status'] ?? 'active';


        // =================================================
        // EMAIL VALIDATION
        // =================================================

        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid email format"
            ]);

            exit;
        }


        // =================================================
        // ROLE VALIDATION
        // =================================================

        $allowedRoles = [
            'admin',
            'staff',
            'customer'
        ];


        if (
            !in_array(
                $role,
                $allowedRoles
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Role must be admin, staff or customer"
            ]);

            exit;
        }


        // =================================================
        // STATUS VALIDATION
        // =================================================

        $allowedStatus = [
            'active',
            'inactive'
        ];


        if (
            !in_array(
                $status,
                $allowedStatus
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Status must be active or inactive"
            ]);

            exit;
        }


        // =================================================
        // CHECK DUPLICATE EMAIL
        // =================================================

        $check = $conn->prepare("
            SELECT user_id
            FROM users
            WHERE email = ?
        ");

        $check->execute([
            $email
        ]);


        if ($check->fetch()) {

            http_response_code(409);

            echo json_encode([
                "status" => false,
                "message" => "Email already exists"
            ]);

            exit;
        }


        // =================================================
        // HASH PASSWORD
        // =================================================

        $hashedPassword = password_hash(
            $password,
            PASSWORD_DEFAULT
        );


        // =================================================
        // INSERT USER
        // =================================================

        try {

            $stmt = $conn->prepare("
                INSERT INTO users
                (
                    name,
                    email,
                    password,
                    phone,
                    role,
                    status
                )
                VALUES
                (?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $name,
                $email,
                $hashedPassword,
                $phone,
                $role,
                $status
            ]);


            http_response_code(201);


            echo json_encode([
                "status" => true,
                "message" => "User created successfully",
                "user_id" => $conn->lastInsertId()
            ]);

        } catch (PDOException $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" => "Failed to create user"
            ]);
        }

        break;


    // =====================================================
    // UPDATE USER
    // =====================================================

    case 'PUT':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "User ID is required"
            ]);

            exit;
        }


        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        $check = $conn->prepare("
            SELECT *
            FROM users
            WHERE user_id = ?
        ");

        $check->execute([
            $id
        ]);


        $existingUser = $check->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$existingUser) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "User not found"
            ]);

            exit;
        }


        $name =
            $data['name']
            ?? $existingUser['name'];

        $email =
            $data['email']
            ?? $existingUser['email'];

        $phone =
            $data['phone']
            ?? $existingUser['phone'];

        $role =
            $data['role']
            ?? $existingUser['role'];

        $status =
            $data['status']
            ?? $existingUser['status'];


        // =================================================
        // EMAIL VALIDATION
        // =================================================

        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid email format"
            ]);

            exit;
        }


        // =================================================
        // ROLE VALIDATION
        // =================================================

        $allowedRoles = [
            'admin',
            'staff',
            'customer'
        ];


        if (
            !in_array(
                $role,
                $allowedRoles
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid role"
            ]);

            exit;
        }


        // =================================================
        // STATUS VALIDATION
        // =================================================

        $allowedStatus = [
            'active',
            'inactive'
        ];


        if (
            !in_array(
                $status,
                $allowedStatus
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid status"
            ]);

            exit;
        }


        // =================================================
        // CHECK EMAIL USED BY ANOTHER USER
        // =================================================

        $emailCheck = $conn->prepare("
            SELECT user_id
            FROM users
            WHERE email = ?
            AND user_id != ?
        ");


        $emailCheck->execute([
            $email,
            $id
        ]);


        if ($emailCheck->fetch()) {

            http_response_code(409);

            echo json_encode([
                "status" => false,
                "message" => "Email already used by another user"
            ]);

            exit;
        }


        // =================================================
        // UPDATE WITH NEW PASSWORD
        // =================================================

        if (
            !empty($data['password'])
        ) {

            $hashedPassword =
                password_hash(
                    $data['password'],
                    PASSWORD_DEFAULT
                );


            $stmt = $conn->prepare("
                UPDATE users
                SET
                    name = ?,
                    email = ?,
                    password = ?,
                    phone = ?,
                    role = ?,
                    status = ?
                WHERE user_id = ?
            ");


            $stmt->execute([
                $name,
                $email,
                $hashedPassword,
                $phone,
                $role,
                $status,
                $id
            ]);

        } else {

            // =================================================
            // UPDATE WITHOUT CHANGING PASSWORD
            // =================================================

            $stmt = $conn->prepare("
                UPDATE users
                SET
                    name = ?,
                    email = ?,
                    phone = ?,
                    role = ?,
                    status = ?
                WHERE user_id = ?
            ");


            $stmt->execute([
                $name,
                $email,
                $phone,
                $role,
                $status,
                $id
            ]);
        }


        echo json_encode([
            "status" => true,
            "message" => "User updated successfully"
        ]);

        break;


    // =====================================================
    // DELETE / DEACTIVATE USER
    // =====================================================

    case 'DELETE':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "User ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT user_id
            FROM users
            WHERE user_id = ?
        ");

        $check->execute([
            $id
        ]);


        if (!$check->fetch()) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "User not found"
            ]);

            exit;
        }


        $stmt = $conn->prepare("
            UPDATE users
            SET status = 'inactive'
            WHERE user_id = ?
        ");


        $stmt->execute([
            $id
        ]);


        echo json_encode([
            "status" => true,
            "message" => "User deactivated successfully"
        ]);

        break;


    // =====================================================
    // INVALID METHOD
    // =====================================================

    default:

        http_response_code(405);

        echo json_encode([
            "status" => false,
            "message" => "Method not allowed"
        ]);

        break;
}

?>