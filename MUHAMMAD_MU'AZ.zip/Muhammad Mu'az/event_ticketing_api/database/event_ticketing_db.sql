-- Local setup reconstructed from the supplied shared chats.
-- Import into a NEW database only. Existing tables are not dropped or replaced.
-- Local adjustments: bcrypt demo passwords, restricted venue deletion,
-- and ticket availability reconciled with the sample bookings.

CREATE DATABASE IF NOT EXISTS event_ticketing_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_ticketing_db;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin', 'staff', 'customer') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE venues (
    venue_id INT AUTO_INCREMENT PRIMARY KEY,
    venue_name VARCHAR(150) NOT NULL,
    location VARCHAR(255) NOT NULL,
    capacity INT NOT NULL,
    status ENUM('available', 'unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    organiser_id INT NOT NULL,
    venue_id INT NOT NULL,
    event_name VARCHAR(150) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    ticket_price DECIMAL(10,2) NOT NULL,
    total_tickets INT NOT NULL,
    available_tickets INT NOT NULL,
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (organiser_id)
        REFERENCES users(user_id)
        ON DELETE CASCADE,

    FOREIGN KEY (venue_id)
        REFERENCES venues(venue_id)
        ON DELETE RESTRICT
);

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    event_id INT NOT NULL,
    quantity INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    booking_status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',

    FOREIGN KEY (customer_id)
        REFERENCES users(user_id)
        ON DELETE CASCADE,

    FOREIGN KEY (event_id)
        REFERENCES events(event_id)
        ON DELETE CASCADE
);

CREATE TABLE auth_tokens (
    token_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE CASCADE
);

START TRANSACTION;

-- =========================
-- SAMPLE DATA FOR USERS
-- =========================

INSERT INTO users (name, email, password, phone, role, status) VALUES
('Admin User', 'admin@gmail.com', '$2y$12$Bm4aw1WbWb0BGYcSmv.UXe9jb61Iam5ZqZsl0fwOQg77IPYZlduMu', '0123456789', 'admin', 'active'),
('Staff One', 'staff1@gmail.com', '$2y$12$dx2xfzWyfAPKY6WwcixhNeiQ5bdWPiDm05lVRQxR8wLEgJQfVUNqy', '0111111111', 'staff', 'active'),
('Staff Two', 'staff2@gmail.com', '$2y$12$dx2xfzWyfAPKY6WwcixhNeiQ5bdWPiDm05lVRQxR8wLEgJQfVUNqy', '0112222222', 'staff', 'active'),
('Customer One', 'customer1@gmail.com', '$2y$12$xN18V5K8yuowX8yUSsIIX.MN7.OOf9olYht6mvcZzp5D4fMvz1bmu', '0131111111', 'customer', 'active'),
('Customer Two', 'customer2@gmail.com', '$2y$12$xN18V5K8yuowX8yUSsIIX.MN7.OOf9olYht6mvcZzp5D4fMvz1bmu', '0132222222', 'customer', 'active'),
('Customer Three', 'customer3@gmail.com', '$2y$12$xN18V5K8yuowX8yUSsIIX.MN7.OOf9olYht6mvcZzp5D4fMvz1bmu', '0133333333', 'customer', 'active');


-- =========================
-- SAMPLE DATA FOR VENUES
-- =========================

INSERT INTO venues (venue_name, location, capacity, status) VALUES
('Grand Hall A', 'Kuala Lumpur', 500, 'available'),
('Convention Hall B', 'Selangor', 300, 'available'),
('Auditorium C', 'Putrajaya', 250, 'available'),
('Event Space D', 'Shah Alam', 200, 'available'),
('Multipurpose Hall E', 'Cyberjaya', 350, 'available');


-- =========================
-- SAMPLE DATA FOR EVENTS
-- =========================

INSERT INTO events
(organiser_id, venue_id, event_name, description, event_date, start_time, end_time, ticket_price, total_tickets, available_tickets, status)
VALUES
(2, 1, 'Technology Conference 2026', 'Conference about latest technology trends.', '2026-11-15', '09:00:00', '17:00:00', 50.00, 500, 500, 'upcoming'),

(2, 2, 'Music Festival 2026', 'Live music event featuring local artists.', '2026-11-20', '18:00:00', '23:00:00', 80.00, 300, 300, 'upcoming'),

(3, 3, 'Business Seminar', 'Seminar for young entrepreneurs.', '2026-12-01', '10:00:00', '15:00:00', 30.00, 250, 250, 'upcoming'),

(3, 4, 'Gaming Tournament', 'Competitive gaming tournament.', '2026-12-10', '10:00:00', '20:00:00', 40.00, 200, 200, 'upcoming'),

(2, 5, 'Career Fair 2026', 'Career and employment opportunities event.', '2026-12-15', '09:00:00', '16:00:00', 10.00, 350, 350, 'upcoming');


-- =========================
-- SAMPLE DATA FOR BOOKINGS
-- =========================

INSERT INTO bookings
(customer_id, event_id, quantity, total_amount, booking_status)
VALUES
(4, 1, 2, 100.00, 'confirmed'),
(5, 2, 1, 80.00, 'confirmed'),
(6, 3, 3, 90.00, 'pending'),
(4, 4, 2, 80.00, 'confirmed'),
(5, 5, 4, 40.00, 'pending');

-- Pending and confirmed sample bookings both reserve tickets.
UPDATE events e
SET available_tickets = e.total_tickets - (
    SELECT COALESCE(SUM(b.quantity), 0)
    FROM bookings b
    WHERE b.event_id = e.event_id
      AND b.booking_status IN ('pending', 'confirmed')
);

COMMIT;
