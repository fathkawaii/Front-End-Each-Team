// Domain helpers are shared by the dashboard and its verification checks.
export const uidKey = {events:'event_id',bookings:'booking_id',venues:'venue_id',users:'user_id'};
export function dateKey(value = new Date()) {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) return value.slice(0,10);
  const d = new Date(value);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
export function plusDays(n, from = new Date()) { const d = new Date(from); d.setDate(d.getDate()+n); return dateKey(d); }
export function weekDates(offset=0,today=new Date()) {
  const start=new Date(today);start.setHours(12,0,0,0);
  start.setDate(start.getDate()-((start.getDay()+6)%7)+offset*7);
  return Array.from({length:7},(_,i)=>plusDays(i,start));
}
export function agendaEvents(events,{mode='upcoming',date='',offset=0}={},today=new Date()) {
  const week=weekDates(offset,today);
  return events.filter(ev=>mode==='day'?ev.event_date===date:mode==='week'?ev.event_date>=week[0]&&ev.event_date<=week[6]:['upcoming','ongoing'].includes(ev.status))
    .sort((a,b)=>a.event_date.localeCompare(b.event_date)||String(a.start_time).localeCompare(String(b.start_time)));
}
export function scopedData(data, user) {
  const bookings = user.role==='admin' ? data.bookings : data.bookings.filter(b => user.role==='customer' ? +b.customer_id===+user.user_id : +b.organiser_id===+user.user_id);
  return {...data,bookings,users:user.role==='admin'?data.users:[],venues:user.role==='admin'?data.venues:[]};
}
export function metrics(data) {
  const active = data.bookings.filter(b=>b.booking_status!=='cancelled');
  const confirmed = active.filter(b=>b.booking_status==='confirmed');
  return {
    value: confirmed.reduce((s,b)=>s+Number(b.total_amount),0),
    tickets: active.reduce((s,b)=>s+Number(b.quantity),0),
    activeEvents:data.events.filter(e=>['upcoming','ongoing'].includes(e.status)).length,
    pending:data.bookings.filter(b=>b.booking_status==='pending').length,
    confirmed:confirmed.length,
    cancelled:data.bookings.filter(b=>b.booking_status==='cancelled').length,
    total: data.bookings.length,
  };
}
export function dailySeries(bookings, count, today=new Date()) {
  const days = Array.from({length:count},(_,i)=>({date:plusDays(i-count+1,today),value:0,tickets:0}));
  for(const b of bookings) {
    if(b.booking_status!=='confirmed') continue;
    const day=days.find(d=>d.date===dateKey(b.booking_date));
    if(day) { day.value+=Number(b.total_amount); day.tickets+=Number(b.quantity); }
  }
  return days;
}
export function csvText(rows) {
  const safe=value=>{
    let s=String(value??'');
    if(/^[\s]*[=+\-@]/.test(s)) s="'"+s;
    return '"'+s.replaceAll('"','""')+'"';
  };
  return '\ufeff'+rows.map(row=>row.map(safe).join(',')).join('\r\n');
}
export function validateEvent(event, venue) {
  if(!event.event_name.trim()) throw Error('Give your event a name.');
  if(!event.organiser_id || !event.venue_id) throw Error('Select an organiser and venue.');
  if(!event.event_date || !event.start_time || !event.end_time) throw Error('Choose the event date and times.');
  if(event.end_time<=event.start_time) throw Error('End time must be after start time.');
  if(+event.ticket_price<0) throw Error('The ticket price cannot be negative.');
  if(!Number.isInteger(+event.total_tickets) || +event.total_tickets<1) throw Error('Enter a positive whole number of tickets.');
  if(+event.available_tickets<0 || +event.available_tickets>+event.total_tickets) throw Error('Available tickets must be between zero and the ticket limit.');
  if(venue && +event.total_tickets>+venue.capacity) throw Error(`This venue has a capacity of ${venue.capacity} people.`);
  if(venue && venue.status!=='available') throw Error('Choose an available venue.');
}
export function adjustBooking(data,id,patch) {
  const b=data.bookings.find(b=>+b.booking_id===+id);
  if(!b)throw Error('Booking not found.');
  const ev=data.events.find(e=>+e.event_id===+b.event_id);
  if(!ev)throw Error('Event not found.');
  const status=patch.booking_status??b.booking_status;
  if(!['confirmed','pending','cancelled'].includes(status))throw Error('Choose a valid booking status.');
  const qty=status==='cancelled'?+b.quantity:+(patch.quantity??b.quantity);
  if(!Number.isInteger(qty)||qty<1)throw Error('Quantity must be a positive whole number.');
  const oldReserved=b.booking_status==='cancelled'?0:+b.quantity;
  const newReserved=status==='cancelled'?0:qty;
  const remaining=+ev.available_tickets+oldReserved-newReserved;
  if(remaining<0)throw Error('Not enough tickets are available.');
  ev.available_tickets=remaining;
  Object.assign(b,{quantity:qty,booking_status:status,total_amount:qty*Number(ev.ticket_price)});
  return b;
}
export function seedData(today=new Date()) {
  const venues=[
    {venue_id:1,venue_name:'The Glasshouse',location:'Kuala Lumpur',capacity:800,status:'available'},
    {venue_id:2,venue_name:'REXKL',location:'Kuala Lumpur',capacity:500,status:'available'},
    {venue_id:3,venue_name:'KL Convention Centre',location:'Kuala Lumpur',capacity:2000,status:'available'},
    {venue_id:4,venue_name:'The Campus',location:'Petaling Jaya',capacity:400,status:'available'},
    {venue_id:5,venue_name:'Botanical Pavilion',location:'Putrajaya',capacity:600,status:'unavailable'},
  ];
  const users=[
    {user_id:1,name:'Aisha Rahman',email:'aisha@example.com',phone:'012-345 6789',role:'admin',status:'active'},
    {user_id:2,name:'Daniel Lee',email:'daniel@example.com',phone:'013-567 8901',role:'staff',status:'active'},
    {user_id:3,name:'Sofia Ahmad',email:'sofia@example.com',phone:'017-456 7890',role:'customer',status:'active'},
    {user_id:4,name:'Amir Hakim',email:'amir@example.com',phone:'016-678 9012',role:'customer',status:'active'},
    {user_id:5,name:'Mei Lin',email:'mei@example.com',phone:'018-789 0123',role:'customer',status:'active'},
    {user_id:6,name:'Adam Yusuf',email:'adam@example.com',phone:'019-890 1234',role:'customer',status:'active'},
    {user_id:7,name:'Nur Iman',email:'iman@example.com',phone:'011-901 2345',role:'staff',status:'active'},
    {user_id:8,name:'Ravi Kumar',email:'ravi@example.com',phone:'014-123 4567',role:'customer',status:'inactive'},
  ].map(u=>({...u,created_at:plusDays(-40,today)+' 09:00:00'}));
  const defs=[
    ['The Creative Assembly',2,1,3,89,650,'upcoming','A gathering of curious minds. Talks, ideas, and conversations about the future of creative work.'],
    ['After Hours: Live Sessions',2,2,6,65,450,'upcoming','An intimate evening of live music with independent local artists.'],
    ['Future Forward Summit',1,3,10,150,1200,'upcoming','Meet the people building what comes next in technology and business.'],
    ['Sunday Design Club',7,4,14,35,280,'upcoming','A relaxed, hands-on design workshop with a creative community.'],
    ['Founders & Friends',1,1,18,55,350,'upcoming','Good conversations and new connections for founders and makers.'],
    ['Local Makers Market',7,2,0,15,400,'ongoing','Discover thoughtfully made products from independent Malaysian makers.'],
    ['Small Ideas, Big Impact',1,4,-8,45,250,'completed','A community meetup celebrating small ideas that make a difference.'],
    ['Open Air Stories',2,5,22,40,300,'cancelled','An evening of storytelling in the gardens.'],
  ];
  const events=defs.map((a,i)=>{const v=venues.find(v=>v.venue_id===a[2]);return {
    event_id:i+1,event_name:a[0],organiser_id:a[1],venue_id:a[2],event_date:plusDays(a[3],today),start_time:i===1?'19:00:00':'10:00:00',end_time:i===1?'22:00:00':'17:00:00',ticket_price:a[4],total_tickets:a[5],available_tickets:a[5],status:a[6],description:a[7],organiser_name:users.find(u=>u.user_id===a[1]).name,venue_name:v.venue_name,venue_location:v.location,created_at:plusDays(-35,today)+' 12:00:00',
  };});
  const bookings=Array.from({length:64},(_,i)=>{
    const ev=events[i%7]; const u=users[2+(i%4)]; const q=2+(i*7)%14;
    const status=i%11===0?'cancelled':i%6===0?'pending':'confirmed';
    if(status!=='cancelled')ev.available_tickets-=q;
    return {booking_id:1001+i,customer_id:u.user_id,customer_name:u.name,event_id:ev.event_id,event_name:ev.event_name,organiser_id:ev.organiser_id,event_date:ev.event_date,ticket_price:ev.ticket_price,quantity:q,total_amount:q*ev.ticket_price,booking_status:status,booking_date:plusDays(-Math.floor((63-i)/3),today)+` ${String(9+i%11).padStart(2,'0')}:${String((i*13)%60).padStart(2,'0')}:00`};
  });
  return {events,bookings,venues,users};
}
