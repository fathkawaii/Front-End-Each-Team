# V2 changes

Frontend:
- Shared login recognises admin, staff and customer returned by the PHP API.
- Role-based navigation and guarded frontend actions.
- Admin Users management with add/edit/deactivate and optional password update.
- Staff event creation uses the signed-in organiser and a real venue list.
- Staff My events aggregates API pages before filtering by organiser.
- Customer booking creation, total preview, own history/details/cancellation.
- Fresh event availability checks before booking submission.
- Fresh booking records before quantity/status changes and cancellations.
- Search/filter, loading, empty/error states and protected duplicate submits.
- Current weather integration retained.
- Safe text rendering for API values.
- Old responses cannot clear or update a newer signed-in account's interface.

One backend compatibility patch:
- File: event_ticketing_api/api/venues/index.php
- GET calls requireStaffOrAdmin().
- All other protected methods still call requireAdmin().
- SQL and business operations below that role block are unchanged.
- OPTIONS behaviour is retained.

Not included:
- Database reset, changed seed records or payment processing.
- JWT/API-key/global PHP error-handler changes.
- Backend event ownership or concurrent booking fixes.
- Claims that manual/browser tests have already passed.
