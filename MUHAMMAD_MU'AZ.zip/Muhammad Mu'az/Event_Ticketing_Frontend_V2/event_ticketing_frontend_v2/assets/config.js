// Both folders run on the same XAMPP server.
export const API_BASE = "/event_ticketing_api";
