<?php

require_once __DIR__ . "/../config/database.php";


// =====================================================
// GET BEARER TOKEN
// =====================================================

function getBearerToken()
{
    $headers = [];

    if (function_exists('getallheaders')) {
        $headers = getallheaders();
    }

    $authorization = null;

    if (isset($headers['Authorization'])) {
        $authorization = $headers['Authorization'];
    }

    if (
        !$authorization &&
        isset($headers['authorization'])
    ) {
        $authorization = $headers['authorization'];
    }

    if (
        !$authorization &&
        isset($_SERVER['HTTP_AUTHORIZATION'])
    ) {
        $authorization =
            $_SERVER['HTTP_AUTHORIZATION'];
    }

    if (!$authorization) {
        return null;
    }

    if (
        !preg_match(
            '/Bearer\s+(\S+)/i',
            $authorization,
            $matches
        )
    ) {
        return null;
    }

    return $matches[1];
}


// =====================================================
// AUTHENTICATE USER
// =====================================================

function authenticateUser()
{
    global $conn;

    $token = getBearerToken();

    if (!$token) {

        http_response_code(401);

        echo json_encode([
            "status" => false,
            "message" => "Authentication token is required"
        ]);

        exit;
    }


    $tokenHash = hash(
        'sha256',
        $token
    );


    $stmt = $conn->prepare("
        SELECT
            u.user_id,
            u.name,
            u.email,
            u.phone,
            u.role,
            u.status,
            t.token_id,
            t.expires_at
        FROM auth_tokens t
        INNER JOIN users u
            ON t.user_id = u.user_id
        WHERE t.token_hash = ?
        AND t.expires_at > NOW()
        LIMIT 1
    ");

    $stmt->execute([
        $tokenHash
    ]);

    $user = $stmt->fetch(
        PDO::FETCH_ASSOC
    );


    if (!$user) {

        http_response_code(401);

        echo json_encode([
            "status" => false,
            "message" => "Invalid or expired authentication token"
        ]);

        exit;
    }


    if ($user['status'] !== 'active') {

        http_response_code(403);

        echo json_encode([
            "status" => false,
            "message" => "User account is inactive"
        ]);

        exit;
    }


    return $user;
}


// =====================================================
// REQUIRE SPECIFIC ROLE
// =====================================================

function requireRole($allowedRoles)
{
    $user = authenticateUser();

    if (!is_array($allowedRoles)) {
        $allowedRoles = [$allowedRoles];
    }

    if (
        !in_array(
            $user['role'],
            $allowedRoles
        )
    ) {

        http_response_code(403);

        echo json_encode([
            "status" => false,
            "message" => "Access denied for this role"
        ]);

        exit;
    }

    return $user;
}


// =====================================================
// REQUIRE ADMIN
// =====================================================

function requireAdmin()
{
    return requireRole([
        'admin'
    ]);
}


// =====================================================
// REQUIRE STAFF OR ADMIN
// =====================================================

function requireStaffOrAdmin()
{
    return requireRole([
        'admin',
        'staff'
    ]);
}


// =====================================================
// REQUIRE CUSTOMER
// =====================================================

function requireCustomer()
{
    return requireRole([
        'customer'
    ]);
}

?>