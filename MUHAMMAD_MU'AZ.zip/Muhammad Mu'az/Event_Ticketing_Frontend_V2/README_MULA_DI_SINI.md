# Event Ticketing — Frontend V2

Versi ini menyokong Admin, Staff/Organiser dan Customer dalam satu aplikasi.
UI menggunakan English dan berjalan terus melalui XAMPP.
Tak perlu install Node.js atau jalankan npm untuk menggunakan website.

## 1. Sebelum pasang

- Backend asal mesti masih berada di C:\xampp\htdocs\event_ticketing_api.
- Gunakan database sedia ada yang sudah berjaya diuji.
- Jangan import semula SQL atau padam database untuk pemasangan frontend ini.
- Sign out daripada frontend lama dahulu.

## 2. Pasang frontend

1. Extract Event_Ticketing_Frontend_V2.zip.
2. Dalam hasil extract, cari folder event_ticketing_frontend_v2.
3. Copy keseluruhan folder itu ke C:\xampp\htdocs.
4. Pastikan fail ini wujud:
   C:\xampp\htdocs\event_ticketing_frontend_v2\index.html
5. Pastikan folder assets juga berada dalam folder yang sama dengan index.html.

Jangan letakkan semua fail terus di dalam htdocs tanpa folder projek.
Frontend lama boleh disimpan berasingan.

## 3. Pasang satu fail pembetulan akses venue

Backend asal membenarkan Admin sahaja membaca venue. Staff memerlukan bacaan
ini untuk memilih venue dan menyemak kapasiti ketika mengurus event.

1. Buka folder backend sedia ada:
   C:\xampp\htdocs\event_ticketing_api\api\venues
2. Buat salinan backup fail index.php di tempat lain.
3. Dalam ZIP baharu, buka:
   backend_patch\event_ticketing_api\api\venues
4. Copy fail index.php daripada folder tersebut.
5. Paste dan replace fail index.php dalam folder venues backend sedia ada.

Perubahan ini hanya membenarkan GET venue untuk Admin dan Staff.
POST, PUT dan DELETE venue kekal Admin sahaja.
Customer tidak diberi akses ke endpoint venue.
Fail backend lain dan database tidak perlu diganti.

Jika patch tidak dipasang, Staff masih boleh sign in tetapi bacaan venue dan
borang event akan menerima ralat akses.

## 4. Buka aplikasi

1. Buka XAMPP Control Panel.
2. Start Apache dan MySQL.
3. Buka browser:
   http://localhost/event_ticketing_frontend_v2/
4. Jika browser memaparkan versi lama, tekan Ctrl + F5.
5. Jangan buka index.html dengan double-click atau URL file:///.

## 5. Akaun demo daripada database setup asal

Admin:
- Email: admin@gmail.com
- Password: admin123

Staff:
- Email: staff1@gmail.com
- Password: staff123

Customer:
- Email: customer1@gmail.com
- Password: cust123

Gunakan password sebenar jika akaun ini sudah diubah.
Tiada akaun atau data demo palsu dijana oleh frontend.
Akaun baharu boleh dicipta oleh Admin melalui menu Users.
Customer tidak mempunyai halaman self-registration kerana API asal
mengehadkan penciptaan pengguna kepada Admin.

## 6. Fungsi mengikut peranan

Admin:
- Events: view, search, pagination, add, edit, cancel, details, weather.
- Venues: view, add, edit dan delete venue yang tidak digunakan.
- Bookings: view, details, edit quantity/status dan cancel.
- Users: view, search/filter, add, edit password/role/status dan deactivate.
- Edit user yang inactive dan pilih Active untuk mengaktifkannya semula.
- Akaun sendiri dikekalkan sebagai Admin yang active dalam interface ini.

Staff/Organiser:
- Events: My events dan All events.
- Add event dengan akaun sendiri sebagai organiser.
- Edit/cancel event sendiri melalui interface.
- View venues selepas patch dipasang; tiada operasi tulis venue.
- View/edit booking untuk event sendiri.
- Status booking termasuk Cancelled boleh ditetapkan melalui Edit,
  selaras dengan PUT booking API. Endpoint DELETE booking tidak dibuka untuk Staff.

Customer:
- Browse/search event, view details dan current venue weather.
- Book tickets untuk event upcoming yang masih mempunyai tiket.
- Quantity dan anggaran total dipaparkan sebelum booking.
- My bookings: view details, status dan cancel booking sendiri.
- Tiada bayaran online; booking baharu bermula sebagai pending.

## 7. Cara mula menguji

Mula dengan Admin:
1. Sign in menggunakan admin@gmail.com.
2. Pastikan menu Events, Venues, Bookings dan Users kelihatan.
3. Buka Users dan tambah satu akaun customer untuk ujian.
4. Sign out.

Kemudian cuba Staff dan Customer secara berasingan.
Gunakan CHECKLIST_UJIAN.md untuk langkah ujian yang lebih lengkap.
Jangan guna satu token Admin sebagai token Staff atau Customer dalam Postman.

## 8. Jika ada masalah

404 ketika membuka frontend:
- Semak index.html tepat dalam folder event_ticketing_frontend_v2 di htdocs.
- Elakkan folder bersarang seperti
  htdocs\event_ticketing_frontend_v2\event_ticketing_frontend_v2\index.html.

Cannot connect / unexpected response:
- Pastikan Apache hidup.
- Semak backend masih bernama event_ticketing_api.
- Cuba http://localhost/event_ticketing_api/test_connection.php.
- Jika menggunakan port Apache berbeza, gunakan port itu dalam URL frontend.
- Untuk nama folder backend yang berbeza, ubah API_BASE dalam assets/config.js.

Staff tidak boleh baca venue / buka borang event:
- Pasang fail PHP patch dalam langkah 3.
- Pastikan fail itu menggantikan API venue, bukannya API event.

Invalid email or password:
- Gunakan akaun yang masih active dan password yang betul.
- Semak backend login secara berasingan menggunakan Postman.
- Jangan reset database semata-mata untuk mengganti frontend.

Weather tidak tersedia:
- Pastikan komputer/server boleh mengakses internet.
- Semak endpoint weather asal dalam Postman.
- Paparan cuaca ialah keadaan semasa, bukan ramalan pada tarikh event.

## 9. Semakan yang sudah dibuat

- 36 automated JavaScript tests: passed.
- JavaScript syntax dan struktur HTML/asset: diperiksa semasa packaging.
- Ujian menggunakan respons API terkawal; bukan live MySQL atau PHP.
- Visual browser dan live PHP/XAMPP belum diuji dalam persekitaran pengguna.
- Keputusan manual perlu direkodkan sendiri selepas pemasangan.

Untuk menjalankan semula automated tests jika Node.js tersedia:
1. Buka terminal dalam folder event_ticketing_frontend_v2.
2. Jalankan: npm test
Tiada package installation diperlukan untuk tests ini.

## 10. Nota untuk report dan group

Frontend ini disambungkan kepada backend PHP yang diberi.
Jangan nyatakan JWT, API-key protection atau central PHP error handler sebagai
siap berdasarkan frontend ini. Ciri tersebut memerlukan perubahan backend
berasingan.

Backend event asal membenarkan role Admin/Staff mengubah event secara umum.
Interface ini hanya memberikan tindakan edit/cancel event sendiri kepada Staff.
Jika group memerlukan ownership restriction pada event di peringkat server,
kuatkuasakan peraturan itu dalam backend juga.

Booking writes asal menggunakan transactions, tetapi semakan availability
tidak dilindungi row lock/conditional update. Pembacaan semula di frontend
tidak menyelesaikan concurrent booking race di backend.

Setiap ahli masih perlu membangunkan frontend individu mengikut arahan tugasan
dan menyediakan bukti sumbangan serta ujian yang sebenar.
