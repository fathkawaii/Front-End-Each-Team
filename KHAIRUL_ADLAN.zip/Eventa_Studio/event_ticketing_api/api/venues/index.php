<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../../config/database.php";
require_once "../../helpers/auth.php";


// =====================================================
// HANDLE OPTIONS
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


// =====================================================
// ADMIN ONLY
// =====================================================

$currentUser = requireAdmin();


// =====================================================
// REQUEST METHOD + ID
// =====================================================

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id'])
    ? intval($_GET['id'])
    : null;


switch ($method) {

    // =====================================================
    // GET VENUE / VENUES
    // =====================================================

    case 'GET':

        if ($id) {

            $stmt = $conn->prepare("
                SELECT
                    venue_id,
                    venue_name,
                    location,
                    capacity,
                    status,
                    created_at
                FROM venues
                WHERE venue_id = ?
            ");

            $stmt->execute([
                $id
            ]);

            $venue = $stmt->fetch(
                PDO::FETCH_ASSOC
            );


            if (!$venue) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,
                    "message" => "Venue not found"
                ]);

                exit;
            }


            echo json_encode([
                "status" => true,
                "message" => "Venue retrieved successfully",
                "data" => $venue
            ]);

        } else {

            $stmt = $conn->prepare("
                SELECT
                    venue_id,
                    venue_name,
                    location,
                    capacity,
                    status,
                    created_at
                FROM venues
                ORDER BY venue_id ASC
            ");

            $stmt->execute();

            $venues = $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );


            echo json_encode([
                "status" => true,
                "message" => "Venues retrieved successfully",
                "data" => $venues
            ]);
        }

        break;


    // =====================================================
    // CREATE VENUE
    // =====================================================

    case 'POST':

        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        if (
            empty($data['venue_name']) ||
            empty($data['location']) ||
            !isset($data['capacity'])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Venue name, location and capacity are required"
            ]);

            exit;
        }


        $venue_name = trim(
            $data['venue_name']
        );

        $location = trim(
            $data['location']
        );

        $capacity = intval(
            $data['capacity']
        );

        $status =
            $data['status'] ?? 'available';


        // =================================================
        // CAPACITY VALIDATION
        // =================================================

        if ($capacity <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Capacity must be greater than 0"
            ]);

            exit;
        }


        // =================================================
        // STATUS VALIDATION
        // =================================================

        $allowedStatus = [
            'available',
            'unavailable'
        ];


        if (
            !in_array(
                $status,
                $allowedStatus
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Status must be available or unavailable"
            ]);

            exit;
        }


        // =================================================
        // INSERT VENUE
        // =================================================

        try {

            $stmt = $conn->prepare("
                INSERT INTO venues
                (
                    venue_name,
                    location,
                    capacity,
                    status
                )
                VALUES
                (?, ?, ?, ?)
            ");


            $stmt->execute([
                $venue_name,
                $location,
                $capacity,
                $status
            ]);


            http_response_code(201);


            echo json_encode([
                "status" => true,
                "message" => "Venue created successfully",
                "venue_id" => $conn->lastInsertId()
            ]);

        } catch (PDOException $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" => "Failed to create venue"
            ]);
        }

        break;


    // =====================================================
    // UPDATE VENUE
    // =====================================================

    case 'PUT':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Venue ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT *
            FROM venues
            WHERE venue_id = ?
        ");

        $check->execute([
            $id
        ]);


        $existingVenue = $check->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$existingVenue) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Venue not found"
            ]);

            exit;
        }


        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        $venue_name =
            $data['venue_name']
            ?? $existingVenue['venue_name'];

        $location =
            $data['location']
            ?? $existingVenue['location'];

        $capacity =
            isset($data['capacity'])
            ? intval($data['capacity'])
            : intval($existingVenue['capacity']);

        $status =
            $data['status']
            ?? $existingVenue['status'];


        // =================================================
        // CAPACITY VALIDATION
        // =================================================

        if ($capacity <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Capacity must be greater than 0"
            ]);

            exit;
        }


        // =================================================
        // STATUS VALIDATION
        // =================================================

        $allowedStatus = [
            'available',
            'unavailable'
        ];


        if (
            !in_array(
                $status,
                $allowedStatus
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Status must be available or unavailable"
            ]);

            exit;
        }


        // =================================================
        // UPDATE VENUE
        // =================================================

        try {

            $stmt = $conn->prepare("
                UPDATE venues
                SET
                    venue_name = ?,
                    location = ?,
                    capacity = ?,
                    status = ?
                WHERE venue_id = ?
            ");


            $stmt->execute([
                $venue_name,
                $location,
                $capacity,
                $status,
                $id
            ]);


            echo json_encode([
                "status" => true,
                "message" => "Venue updated successfully"
            ]);

        } catch (PDOException $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" => "Failed to update venue"
            ]);
        }

        break;


    // =====================================================
    // DELETE VENUE
    // =====================================================

    case 'DELETE':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Venue ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT venue_id
            FROM venues
            WHERE venue_id = ?
        ");

        $check->execute([
            $id
        ]);


        if (!$check->fetch()) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Venue not found"
            ]);

            exit;
        }


        try {

            $stmt = $conn->prepare("
                DELETE FROM venues
                WHERE venue_id = ?
            ");


            $stmt->execute([
                $id
            ]);


            echo json_encode([
                "status" => true,
                "message" => "Venue deleted successfully"
            ]);

        } catch (PDOException $e) {

            http_response_code(409);

            echo json_encode([
                "status" => false,
                "message" => "Venue cannot be deleted because it is being used by an event"
            ]);
        }

        break;


    // =====================================================
    // INVALID METHOD
    // =====================================================

    default:

        http_response_code(405);

        echo json_encode([
            "status" => false,
            "message" => "Method not allowed"
        ]);

        break;
}

?>