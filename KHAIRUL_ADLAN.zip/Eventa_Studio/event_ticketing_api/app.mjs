import {uidKey,dateKey,seedData,scopedData,metrics,csvText,validateEvent,adjustBooking} from './domain.mjs';
import {EventApi} from './api.mjs';
import {esc,icon,num,money,initials,prettyDate,time,status,button,progress,formError,field,selectField} from './ui.mjs';
import {routes,allowedRoutes,shell,page,filteredEvents,filteredBookings,reportRows} from './views.mjs';

const storage={
  get(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}},
  set(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{toast('Browser storage is unavailable. Changes will last for this visit.');}},
};
const now=new Date();
const savedDemo=storage.get('eventa-demo-v1',null);
let demo=savedDemo&&['events','bookings','users','venues'].every(k=>Array.isArray(savedDemo[k]))?savedDemo:seedData();
const defaultBase=/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname)?new URL('.',location.href).href.replace(/\/$/,''):'http://localhost/event_ticketing_api';
let api=null,modalTrigger=null,modalHandler=null,toastTimer=null;
const state={
  mode:'demo',user:demo.users.find(u=>u.role==='admin'&&u.status==='active')??seedData().users[0],data:demo,
  route:'overview',page:1,range:7,overviewStatus:'all',eventView:storage.get('eventa-view','grid'),theme:storage.get('eventa-theme','light'),
  scheduleMode:'upcoming',scheduleDate:'',weekOffset:0,
  apiBase:storage.get('eventa-base',defaultBase),calendar:{month:now.getMonth(),year:now.getFullYear()},
  filters:{events:{q:'',status:'all',sort:'date',scope:'all',availability:'all'},bookings:{q:'',status:'all'},venues:{q:'',status:'all'},users:{q:'',role:'all'}},
};
const app=document.getElementById('app');
const modalRoot=document.getElementById('modal-root');
function scope(){state.data=state.mode==='demo'?scopedData(demo,state.user):state.data;}
function render(){scope();document.documentElement.dataset.theme=state.theme;document.title=`${routes[state.route]} · Eventa`;app.innerHTML=shell(state);}
function renderMain(){scope();document.getElementById('main').innerHTML=page(state);}
function navigate(route){if(!allowedRoutes(state.user.role).includes(route))route='overview';state.route=route;state.page=1;render();}
function notifyError(error){toast(error.message||String(error),true);}
function toast(message,error=false){clearTimeout(toastTimer);document.getElementById('toast-root').innerHTML=`<div class="toast ${error?'error':''}">${icon(error?'info':'check')}<span>${esc(message)}</span></div>`;toastTimer=setTimeout(()=>{document.getElementById('toast-root').innerHTML='';},5200);}
function busy(message){let el=document.getElementById('busy');if(!message){el?.remove();return;}if(!el){el=document.createElement('div');el.id='busy';document.body.append(el);}el.className='loading-overlay';el.innerHTML=`<div class="loading-message"><span class="spinner"></span>${esc(message)}</div>`;}
function persistDemo(){storage.set('eventa-demo-v1',demo);scope();}
function setFormError(err){const el=document.getElementById('form-error');if(el){el.textContent=err.message||String(err);el.classList.add('visible');el.scrollIntoView({block:'nearest'});}else notifyError(err);}
function modal(title,subtitle,body,footer='',wide=false){
  if(!modalRoot.firstElementChild)modalTrigger=document.activeElement;
  modalHandler=null;
  modalRoot.innerHTML=`<div class="modal-backdrop"><section class="modal ${wide?'wide':''}" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header class="modal-heading"><div><h2 id="modal-title">${esc(title)}</h2><p>${esc(subtitle)}</p></div><button class="icon-button" data-action="close-modal" aria-label="Close dialog">${icon('close')}</button></header>${body}${footer?`<footer class="modal-actions">${footer}</footer>`:''}</section></div>`;
  document.body.style.overflow='hidden';
  app.inert=true;
  requestAnimationFrame(()=>(modalRoot.querySelector('input:not([type="hidden"]),select,textarea')??modalRoot.querySelector('button'))?.focus());
}
function closeModal(){modalRoot.innerHTML='';app.inert=false;document.body.style.overflow='';modalHandler=null;if(modalTrigger?.isConnected)modalTrigger.focus();}
function formModal(title,subtitle,fields,submitText,submit,extraFooter='',wide=false){
  modal(title,subtitle,`<form id="modal-form"><div class="modal-body">${formError}<div class="form-grid">${fields}</div></div><footer class="modal-actions">${extraFooter}${button('Cancel','close-modal','','')}<button type="submit" class="button primary" id="form-submit">${icon('check')}${submitText}</button></footer></form>`,'',wide);
  modalHandler=async form=>{
    const submitBtn=form.querySelector('[type=submit]');
    const errorEl=document.getElementById('form-error');errorEl?.classList.remove('visible');
    submitBtn.disabled=true;
    try{await submit(Object.fromEntries(new FormData(form)));}catch(err){setFormError(err);}finally{if(submitBtn.isConnected)submitBtn.disabled=false;}
  };
}
function requireRole(...roles){if(!roles.includes(state.user.role))throw Error('This action is not available for your role.');}
async function refresh(message=true){
  if(state.mode==='demo'){render();if(message)toast('Your sample workspace is up to date.');return;}
  busy('Refreshing your workspace…');
  try{state.data=await api.load(state.user);render();if(message)toast('Workspace refreshed.');}finally{busy();}
}
function expiredSession(){
  if(state.mode!=='live')return;
  sessionStorage.removeItem('eventa-session');api=null;state.mode='demo';state.user=demo.users.find(u=>u.role==='admin')??seedData().users[0];state.route='overview';render();
  setTimeout(()=>{toast('Your session expired. Sign in again to continue.',true);connectModal();},0);
}
async function saveRecord(type,id,data){
  if(state.mode==='live'){
    const response=await api.save(type,id,data);
    try{state.data=await api.load(state.user);}catch(err){closeModal();render();throw Error('Your change was saved, but the workspace could not refresh. Use Refresh data.');}
    if(type==='users'&&+id===+state.user.user_id){
      const updated=state.data.users.find(u=>+u.user_id===+id);
      if(updated){state.user={...state.user,...updated};try{const session=JSON.parse(sessionStorage.getItem('eventa-session'));if(session){session.user=state.user;sessionStorage.setItem('eventa-session',JSON.stringify(session));}}catch{}}
    }
    render();return response;
  }
  const key=uidKey[type];
  if(type==='bookings'&&id){adjustBooking(demo,id,data);}
  else if(type==='bookings'){
    const ev=demo.events.find(e=>+e.event_id===+data.event_id);const qty=+data.quantity;
    if(!ev||ev.status!=='upcoming')throw Error('Only upcoming events can be booked.');
    if(!Number.isInteger(qty)||qty<1||qty>+ev.available_tickets)throw Error('Choose a quantity within the available tickets.');
    const id=Math.max(1000,...demo.bookings.map(b=>+b.booking_id))+1;
    demo.bookings.push({booking_id:id,customer_id:state.user.user_id,customer_name:state.user.name,event_id:ev.event_id,event_name:ev.event_name,organiser_id:ev.organiser_id,event_date:ev.event_date,ticket_price:ev.ticket_price,quantity:qty,total_amount:qty*ev.ticket_price,booking_status:'pending',booking_date:dateKey()+' '+new Date().toTimeString().slice(0,8)});
    ev.available_tickets-=qty;
  }else{
    const clean={...data};delete clean.password;
    if(id)Object.assign(demo[type].find(r=>+r[key]===+id),clean);
    else demo[type].push({...clean,[key]:Math.max(0,...demo[type].map(r=>+r[key]))+1,created_at:dateKey()+' 12:00:00'});
  }
  for(const ev of demo.events){const v=demo.venues.find(v=>+v.venue_id===+ev.venue_id),u=demo.users.find(u=>+u.user_id===+ev.organiser_id);if(v){ev.venue_name=v.venue_name;ev.venue_location=v.location;}if(u)ev.organiser_name=u.name;}
  for(const b of demo.bookings){const ev=demo.events.find(e=>+e.event_id===+b.event_id),u=demo.users.find(u=>+u.user_id===+b.customer_id);if(ev){b.event_name=ev.event_name;b.event_date=ev.event_date;b.organiser_id=ev.organiser_id;}if(u)b.customer_name=u.name;}
  if(type==='users'&&+id===+state.user.user_id)state.user={...demo.users.find(u=>+u.user_id===+id)};
  persistDemo();render();return {status:true};
}
async function removeRecord(type,id){
  if(state.mode==='live'){
    await api.remove(type,id);
    try{state.data=await api.load(state.user);}catch{closeModal();render();throw Error('Your change was saved, but the workspace could not refresh. Use Refresh data.');}
  }else{
    if(type==='events')demo.events.find(e=>+e.event_id===+id).status='cancelled';
    if(type==='bookings')adjustBooking(demo,id,{booking_status:'cancelled'});
    if(type==='users')demo.users.find(u=>+u.user_id===+id).status='inactive';
    if(type==='venues'){
      if(demo.events.some(e=>+e.venue_id===+id))throw Error('This venue is linked to events. Set it to unavailable instead.');
      demo.venues=demo.venues.filter(v=>+v.venue_id!==+id);
    }
    persistDemo();
  }
  render();
}
function confirmModal(title,message,action,label='Confirm'){
  modal(title,'Please review this change.',`<div class="modal-body">${formError}<p class="confirm-message">${message}</p></div>`,button('Go back','close-modal','','')+`<button class="button danger" id="confirm-action">${label}</button>`);
  document.getElementById('confirm-action').addEventListener('click',async ev=>{ev.currentTarget.disabled=true;try{await action();closeModal();}catch(err){setFormError(err);const btn=document.getElementById('confirm-action');if(btn)btn.disabled=false;}});
}
function eventForm(id){
  requireRole('admin','staff');
  const ev=state.data.events.find(e=>+e.event_id===+id);
  const organisers=state.user.role==='admin'?state.data.users.filter(u=>['admin','staff'].includes(u.role)&&u.status==='active'):[state.user];
  if(ev&&!organisers.some(u=>+u.user_id===+ev.organiser_id))organisers.push({user_id:ev.organiser_id,name:ev.organiser_name||'Current organiser'});
  const venueField=state.user.role==='admin'?selectField('Venue','venue_id',[[0,'Choose a venue'],...state.data.venues.filter(v=>v.status==='available'||+v.venue_id===+ev?.venue_id).map(v=>[v.venue_id,`${v.venue_name} · ${v.capacity} capacity${v.status!=='available'?' · unavailable':''}`])],ev?.venue_id??0,'required'):`<div class="field"><label for="f-venue_id">Venue ID</label><input id="f-venue_id" name="venue_id" type="number" min="1" step="1" required value="${ev?.venue_id??''}" list="known-venues"><datalist id="known-venues">${[...new Map(state.data.events.map(e=>[e.venue_id,e])).values()].map(e=>`<option value="${e.venue_id}">${esc(e.venue_name)}</option>`).join('')}</datalist><small>Use a venue ID from your admin. The venue directory is admin-only in this API.</small></div>`;
  const fields=field('Event name','event_name',ev?.event_name??'','text','required maxlength="150" autocomplete="off"')+
    selectField('Event organiser','organiser_id',organisers.map(u=>[u.user_id,u.name]),ev?.organiser_id??state.user.user_id,'required')+venueField+
    field('Event date','event_date',ev?.event_date??dateKey(),'date','required')+
    field('Start time','start_time',ev?.start_time?.slice(0,5)??'10:00','time','required')+field('End time','end_time',ev?.end_time?.slice(0,5)??'17:00','time','required')+
    field('Ticket price (RM)','ticket_price',ev?.ticket_price??'0','number','required min="0" step="0.01"')+field('Total tickets','total_tickets',ev?.total_tickets??'100','number','required min="1" step="1"')+
    (ev?field('Available tickets','available_tickets',ev.available_tickets,'number',`required min="0" max="${+ev.total_tickets}" step="1"`):'')+
    selectField('Status','status',['upcoming','ongoing','completed','cancelled'].map(x=>[x,x[0].toUpperCase()+x.slice(1)]),ev?.status??'upcoming')+field('Description','description',ev?.description??'','textarea','maxlength="3000" placeholder="What makes this event worth coming to?"');
  formModal(ev?'Edit your event':'Something great starts here.',ev?'Update the details and keep everyone on the same page.':'Add the essentials. You can fine-tune the details later.',fields,ev?'Save changes':'Create event',async values=>{
    const data={...values};for(const key of ['organiser_id','venue_id','ticket_price','total_tickets','available_tickets'])if(key in data)data[key]=Number(data[key]);
    if(!ev)data.available_tickets=data.total_tickets;
    const venue=(state.mode==='demo'?demo.venues:state.data.venues).find(v=>+v.venue_id===data.venue_id);
    if(state.mode==='demo'&&!venue)throw Error('This venue ID does not exist. Choose a known venue.');
    validateEvent(data,venue);
    await saveRecord('events',ev?.event_id,data);closeModal();toast(ev?'Event updated.':'Your event is ready.');
  },'',true);
  if(ev){document.getElementById('f-total_tickets').addEventListener('input',e=>{document.getElementById('f-available_tickets').max=e.target.value;});}
}
function eventDetails(id){
  const ev=state.data.events.find(e=>+e.event_id===+id);if(!ev)throw Error('This event is no longer available.');
  const details=`<div class="modal-body"><div class="spotlight-art detail-art"><div class="art-label">AN EVENT WORTH BEING PART OF</div><div class="art-title">${esc(ev.event_name)}</div><span class="orbit"></span></div><div style="display:flex;align-items:center;justify-content:space-between">${status(ev.status)}<strong style="font-size:17px">${money(ev.ticket_price,2)} <small class="subdued" style="font-weight:400">/ ticket</small></strong></div><div class="detail-grid"><div class="detail-item">${icon('calendar')}<div><small>Date</small><strong>${prettyDate(ev.event_date)}</strong></div></div><div class="detail-item">${icon('clock')}<div><small>Time</small><strong>${time(ev.start_time)} – ${time(ev.end_time)}</strong></div></div><div class="detail-item">${icon('location')}<div><small>Venue</small><strong>${esc(ev.venue_name||'Venue #'+ev.venue_id)}</strong><small>${esc(ev.venue_location)} · ID ${ev.venue_id}</small></div></div><div class="detail-item">${icon('user')}<div><small>Organiser</small><strong>${esc(ev.organiser_name||'Organiser #'+ev.organiser_id)}</strong></div></div></div><p class="detail-description">${esc(ev.description||'No description has been added yet.').replaceAll('\n','<br>')}</p><div style="margin-top:18px">${progress(ev)}</div><div id="weather-result"></div></div>`;
  const adminActions=state.user.role!=='customer'?`${ev.status!=='cancelled'?button('Cancel event','cancel-event','trash','danger',`data-id="${ev.event_id}"`):''}${button('Edit event','edit-event','edit','primary',`data-id="${ev.event_id}"`)}`:ev.status==='upcoming'&&+ev.available_tickets>0?button('Book tickets','create-booking','ticket','primary',`data-id="${ev.event_id}"`):'';
  modal(ev.event_name,'Event details · EVT-'+String(ev.event_id).padStart(4,'0'),details,button('Venue weather','weather','cloud','left-action',`data-id="${ev.event_id}"`)+adminActions,true);
}
function venueForm(id){
  requireRole('admin');const v=state.data.venues.find(v=>+v.venue_id===+id);
  formModal(v?'Edit venue':'Add a new space.',v?'Keep your venue details up to date.':'Set the scene for your next event.',
    field('Venue name','venue_name',v?.venue_name??'','text','required maxlength="150"')+field('Location / city','location',v?.location??'','text','required maxlength="150"')+field('Capacity','capacity',v?.capacity??100,'number','required min="1" step="1"')+selectField('Availability','status',[['available','Available'],['unavailable','Unavailable']],v?.status??'available'),'Save venue',async values=>{values.capacity=+values.capacity;await saveRecord('venues',v?.venue_id,values);closeModal();toast(v?'Venue updated.':'New venue added.');});
}
function userForm(id){
  requireRole('admin');const u=state.data.users.find(u=>+u.user_id===+id),self=+u?.user_id===+state.user.user_id;
  const fields=field('Full name','name',u?.name??'','text','required maxlength="100" autocomplete="name"')+field('Email address','email',u?.email??'','email','required autocomplete="email"')+field('Phone number','phone',u?.phone??'','tel','maxlength="30" autocomplete="tel"')+field(u?'New password (optional)':'Password','password','','password',`${u?'':'required '}minlength="8" autocomplete="new-password"`)+selectField('Role','role',(self?['admin']:['admin','staff','customer']).map(r=>[r,r[0].toUpperCase()+r.slice(1)]),u?.role??'customer')+selectField('Account status','status',(self?['active']:['active','inactive']).map(r=>[r,r[0].toUpperCase()+r.slice(1)]),u?.status??'active')+(state.mode==='demo'?'<div class="info-note" style="grid-column:1/-1">Sample accounts are used for previewing roles. Passwords are not saved in the demo.</div>':'');
  formModal(u?'Edit account':'Welcome someone new.',u?'Update their details and workspace access.':'Create an account for your team or a customer.',fields,u?'Save changes':'Create account',async values=>{
    if(!values.name.trim())throw Error('Please enter a name.');
    if(!values.password)delete values.password;
    if(state.mode==='demo'&&demo.users.some(p=>p.email.toLowerCase()===values.email.toLowerCase()&&+p.user_id!==+u?.user_id))throw Error('This email is already in use.');
    await saveRecord('users',u?.user_id,values);closeModal();toast(u?'Account updated.':'Account created.');
  });
}
function bookingDetails(id){
  const b=state.data.bookings.find(b=>+b.booking_id===+id);if(!b)throw Error('Booking not found.');
  const details=`<div class="info-note" style="grid-column:1/-1"><strong>${esc(b.event_name)}</strong><br>${esc(b.customer_name)} · ${prettyDate(b.event_date)}<br>Booking #BK-${b.booking_id} · Current value ${money(b.total_amount,2)}</div>`;
  if(state.user.role==='customer'){
    modal('Your booking','Booking #BK-'+b.booking_id,`<div class="modal-body">${details}<div class="detail-grid"><div><small class="subdued">Tickets</small><h2>${num(b.quantity)}</h2></div><div><small class="subdued">Status</small><div style="margin-top:5px">${status(b.booking_status)}</div></div></div></div>`,button('Close','close-modal','','')+(b.booking_status!=='cancelled'?button('Cancel booking','cancel-booking','trash','danger',`data-id="${b.booking_id}"`):''));
    return;
  }
  formModal('Manage booking','Confirm, adjust, or cancel this booking.',details+field('Ticket quantity','quantity',b.quantity,'number','required min="1" step="1"')+selectField('Booking status','booking_status',[['pending','Pending'],['confirmed','Confirmed'],['cancelled','Cancelled']],b.booking_status),'Save booking',async values=>{values.quantity=+values.quantity;await saveRecord('bookings',b.booking_id,values);closeModal();toast('Booking updated. Ticket availability has been adjusted.');});
}
function createBooking(id){
  requireRole('customer');const ev=state.data.events.find(e=>+e.event_id===+id);
  if(!ev||ev.status!=='upcoming'||+ev.available_tickets<1)throw Error('This event is not accepting bookings.');
  formModal('Save your spot.',ev.event_name,`<div class="info-note" style="grid-column:1/-1">${prettyDate(ev.event_date)} · ${esc(ev.venue_name)}<br>${num(ev.available_tickets)} tickets available at ${money(ev.ticket_price,2)} each.</div>`+field('Number of tickets','quantity',1,'number',`required min="1" max="${+ev.available_tickets}" step="1"`)+`<div class="field"><label>Booking total</label><strong id="booking-total" style="font-size:24px;padding-top:3px">${money(ev.ticket_price,2)}</strong></div><div class="form-note" style="grid-column:1/-1">Your booking will be pending until an organiser confirms it.</div>`,'Book tickets',async values=>{await saveRecord('bookings',null,{event_id:ev.event_id,quantity:+values.quantity});closeModal();toast('Your booking is in. Awaiting organiser confirmation.');});
  document.getElementById('f-quantity').addEventListener('input',e=>{document.getElementById('booking-total').textContent=money(+e.target.value*+ev.ticket_price,2);});
}
function connectModal(){
  modal('Your events. Your workspace.','Explore the design or connect to your own PHP backend.',`<div class="modal-body"><h3 style="font-size:12px">Explore the sample workspace</h3><div class="login-choice">${[['admin','shield','Full workspace access'],['staff','users','Events & own bookings'],['customer','ticket','Browse & book tickets']].map(([r,i,desc])=>`<button class="role-choice" data-demo-role="${r}">${icon(i)}<strong>${r[0].toUpperCase()+r.slice(1)}</strong><small>${desc}</small></button>`).join('')}</div><div class="modal-divider">OR USE YOUR REAL PROJECT</div><form id="modal-form">${formError}<div class="form-stack">${field('API base address','base',state.apiBase,'url','required placeholder="http://localhost/event_ticketing_api"')}${field('Email address','email','','email','required autocomplete="username" placeholder="Your existing account email"')}${field('Password','password','','password','required autocomplete="current-password"')}<p class="form-note">Run Apache and MySQL, then sign in using an account from your database. For a local API, open the downloaded frontend from the same local server.</p><button id="form-submit" type="submit" class="button primary" style="width:100%">${icon('link')}Connect & sign in</button></div></form></div>`);
  modalHandler=async form=>{
    const values=Object.fromEntries(new FormData(form)),submitBtn=form.querySelector('[type=submit]');submitBtn.disabled=true;
    try{
      const url=new URL(values.base);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw Error('Enter an HTTP or HTTPS base address without credentials, a query, or a fragment.');
      const base=url.href.replace(/\/+$/,'');
      const candidate=new EventApi(base,'',expiredSession);const login=await candidate.request('auth/login.php','POST',{email:values.email.trim(),password:values.password});
      if(!login.token||!login.user||!['admin','staff','customer'].includes(login.user.role))throw Error('The login response did not include a supported account and token.');
      candidate.token=login.token;const data=await candidate.load(login.user);
      state.apiBase=base;storage.set('eventa-base',base);api=candidate;state.user=login.user;state.data=data;state.mode='live';state.route='overview';state.page=1;
      sessionStorage.setItem('eventa-session',JSON.stringify({base,token:login.token,user:login.user,expires:login.expires_at}));
      closeModal();render();toast(`Welcome, ${state.user.name.split(' ')[0]}. Your backend is connected.`);
    }catch(err){setFormError(err);}finally{if(submitBtn.isConnected)submitBtn.disabled=false;}
  };
}
async function switchRole(role){
  if(!['admin','staff','customer'].includes(role))return;
  if(state.mode==='live'){
    try{await api.request('auth/logout.php','POST');}catch{}
    sessionStorage.removeItem('eventa-session');api=null;
  }
  const user=demo.users.find(u=>u.role===role&&u.status==='active');
  if(!user)throw Error('No active sample account is available for this role. Reset the demo to restore it.');
  closeModal();state.mode='demo';state.user=user;state.route=allowedRoutes(role).includes(state.route)?state.route:'overview';state.page=1;render();toast(`Previewing the ${role} workspace.`);
}
async function weather(id,trigger){
  const target=document.getElementById('weather-result');if(!target)return;
  trigger.disabled=true;target.innerHTML='<div class="weather-result">Checking venue weather…</div>';
  try{
    let weather,venue,sample=state.mode==='demo';
    if(sample){weather={temperature:29,temperature_unit:'°C',condition:'Partly cloudy',humidity:74,wind_speed:7.2,wind_speed_unit:'km/h'};venue=state.data.events.find(e=>+e.event_id===+id).venue_location;}
    else{const result=await api.weather(id);weather=result.weather;venue=result.venue.resolved_location;}
    target.innerHTML=`<div class="weather-result"><div class="weather-main">${icon('cloud')}<strong>${esc(weather.temperature)}${esc(weather.temperature_unit)}</strong><div>${esc(weather.condition)}<br><small>${esc(venue)}</small></div></div>Humidity ${esc(weather.humidity)}% · Wind ${esc(weather.wind_speed)} ${esc(weather.wind_speed_unit)}<br><small>${sample?'Illustrative sample weather. Connect your backend for current readings.':'Current venue conditions via Open-Meteo. This is not a forecast for the event date.'}</small></div>`;
  }catch(err){target.innerHTML=`<div class="weather-result">${esc(err.message)}</div>`;}finally{if(trigger.isConnected)trigger.disabled=false;}
}
function exportCsv(){
  let rows,name;
  if(state.route==='bookings'){
    rows=[['Booking ID','Customer','Event','Quantity','Amount (MYR)','Booking date','Status'],...filteredBookings(state).map(b=>[b.booking_id,b.customer_name,b.event_name,b.quantity,b.total_amount,b.booking_date,b.booking_status])];name='eventa-bookings';
  }else{rows=[['Event ID','Event name','Event date','Status','Confirmed bookings','Confirmed tickets','Confirmed value (MYR)'],...reportRows(state).map(r=>[r.event.event_id,r.event.event_name,r.event.event_date,r.event.status,r.count,r.tickets,r.value])];name='eventa-report';}
  const url=URL.createObjectURL(new Blob([csvText(rows)],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download=`${name}-${dateKey()}.csv`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Your CSV is ready.');
}
function notifications(){
  const pending=state.data.bookings.filter(b=>b.booking_status==='pending');
  modal('A few things to keep an eye on.',`${pending.length} pending bookings in your workspace.`,`<div class="modal-body"><div class="notification-list">${pending.slice(0,8).map(b=>`<article class="notification-item">${icon('clock')}<div><strong>${esc(b.customer_name)} · ${num(b.quantity)} tickets</strong><p>${esc(b.event_name)} · #BK-${b.booking_id}</p>${button(state.user.role==='customer'?'View booking':'Review booking','booking-details','right','sm',`data-id="${b.booking_id}"`)}</div></article>`).join('')||'<p class="form-note">You’re all caught up. New pending bookings will appear here.</p>'}</div></div>`,button('Close','close-modal','',''));
}
function searchWorkspace(query){
  const q=query.trim().toLowerCase();if(!q)return;
  const results=[...state.data.events.filter(e=>[e.event_name,e.venue_name,e.description].join(' ').toLowerCase().includes(q)).map(e=>({label:e.event_name,desc:prettyDate(e.event_date)+' · '+e.venue_name,action:'event-details',id:e.event_id,ico:'ticket'})),...state.data.bookings.filter(b=>[b.customer_name,b.event_name,String(b.booking_id)].join(' ').toLowerCase().includes(q)).map(b=>({label:'#BK-'+b.booking_id+' · '+b.customer_name,desc:b.event_name,action:'booking-details',id:b.booking_id,ico:'bookings'})),...state.data.venues.filter(v=>[v.venue_name,v.location].join(' ').toLowerCase().includes(q)).map(v=>({label:v.venue_name,desc:v.location,action:'edit-venue',id:v.venue_id,ico:'venue'})),...state.data.users.filter(u=>[u.name,u.email].join(' ').toLowerCase().includes(q)).map(u=>({label:u.name,desc:u.email,action:'edit-user',id:u.user_id,ico:'user'}))];
  modal('Search your workspace',`${results.length} results for “${query.trim()}”`,`<div class="modal-body"><div class="results-list">${results.slice(0,30).map(r=>`<button class="result-item" data-action="${r.action}" data-id="${r.id}">${icon(r.ico)}<span><strong>${esc(r.label)}</strong><small>${esc(r.desc)}</small></span>${icon('right')}</button>`).join('')||'<p class="form-note">No results found. Try another event name, person, or booking ID.</p>'}</div>${results.length>30?'<p class="form-note" style="margin-top:12px">Showing the first 30 results. Refine your search for more specific matches.</p>':''}</div>`);
}
function help(){
  modal('A little guidance goes a long way.','Get started with your Eventa frontend.',`<div class="modal-body"><div class="notification-list"><article class="notification-item">${icon('spark')}<div><strong>Explore the sample workspace</strong><p>Create events, confirm bookings, and try the calendar. Sample changes stay in this browser. Settings lets you switch between admin, staff, and customer.</p></div></article><article class="notification-item">${icon('link')}<div><strong>Connect your project</strong><p>Place the frontend files beside the api, auth, config, and helpers folders in your XAMPP project. Start Apache and MySQL, then open your project through localhost and choose Connect API.</p></div></article><article class="notification-item">${icon('shield')}<div><strong>Use your existing account</strong><p>The frontend uses the email and password from your database. No new login credentials are created for you. This upload does not include a database SQL file.</p></div></article><article class="notification-item">${icon('users')}<div><strong>Roles match your backend</strong><p>Admin manages everything. Staff can manage events and bookings for their own events. Customers can book upcoming events, view their own bookings, and cancel them.</p></div></article></div><div class="info-note" style="margin-top:15px">A hosted preview cannot run PHP or connect directly to a MySQL server on your computer. Use the included files on your local PHP server to connect the real project.</div></div>`,button('Got it','close-modal','','primary'));
}
function toggleMenu(open){document.querySelector('.sidebar')?.classList.toggle('open',open);document.querySelector('.mobile-overlay')?.classList.toggle('open',open);document.querySelector('.mobile-menu')?.setAttribute('aria-expanded',String(open));}

document.addEventListener('submit',async event=>{
  if(event.target.id==='modal-form'){event.preventDefault();await modalHandler?.(event.target);}
  if(event.target.id==='global-search-form'){event.preventDefault();searchWorkspace(document.getElementById('global-search').value);}
});
document.addEventListener('click',async event=>{
  const target=event.target.closest('button,a,[data-action]');
  if(event.target.classList.contains('modal-backdrop')){closeModal();return;}
  if(!target||target.disabled)return;
  if(target.matches('a[href^="#"]')){toggleMenu(false);closeModal();if(location.hash===target.getAttribute('href'))navigate(location.hash.slice(1));return;}
  try{
    if(target.dataset.scheduleMode){state.scheduleMode=target.dataset.scheduleMode;state.scheduleDate='';if(state.scheduleMode==='week')state.weekOffset=0;renderMain();return;}
    if(target.dataset.scheduleDate){state.scheduleDate=target.dataset.scheduleDate;state.scheduleMode='day';renderMain();return;}
    if(target.dataset.range){state.range=+target.dataset.range;renderMain();return;}
    if(target.dataset.overviewStatus){state.overviewStatus=target.dataset.overviewStatus;renderMain();return;}
    if(target.dataset.eventView){state.eventView=target.dataset.eventView;storage.set('eventa-view',state.eventView);renderMain();return;}
    if(target.dataset.page){state.page=+target.dataset.page;renderMain();return;}
    if(target.dataset.demoRole){await switchRole(target.dataset.demoRole);return;}
    if(target.dataset.themeChoice){state.theme=target.dataset.themeChoice;storage.set('eventa-theme',state.theme);render();return;}
    const id=+target.dataset.id;
    switch(target.dataset.action){
      case 'menu':toggleMenu(true);break;case 'close-menu':toggleMenu(false);break;case 'close-modal':closeModal();break;
      case 'create-event':eventForm();break;case 'edit-event':eventForm(id);break;case 'event-details':eventDetails(id);break;
      case 'create-venue':venueForm();break;case 'edit-venue':venueForm(id);break;
      case 'create-user':userForm();break;case 'edit-user':userForm(id);break;
      case 'booking-details':bookingDetails(id);break;case 'create-booking':createBooking(id);break;
      case 'quick-confirm':{
        requireRole('admin','staff');
        const booking=state.data.bookings.find(b=>+b.booking_id===id);
        if(!booking)throw Error('This booking is not available in your workspace.');
        if(state.user.role==='staff'&&+booking.organiser_id!==+state.user.user_id)throw Error('You can only confirm bookings for your own events.');
        if(booking.booking_status!=='pending'){toast('This booking has already been processed.');break;}
        target.disabled=true;
        try{await saveRecord('bookings',id,{booking_status:'confirmed'});toast(`Booking #BK-${id} confirmed.`);}finally{if(target.isConnected)target.disabled=false;}
        break;
      }
      case 'cancel-event':requireRole('admin','staff');confirmModal('Cancel this event?','<strong>'+esc(state.data.events.find(e=>+e.event_id===id)?.event_name)+'</strong> will be marked as cancelled. Existing bookings remain in the system for review.',async()=>{await removeRecord('events',id);toast('Event cancelled. Review any existing bookings.');},'Cancel event');break;
      case 'cancel-booking':requireRole('admin','customer');confirmModal('Cancel your booking?','The booking will be cancelled and its tickets returned to the event’s availability.',async()=>{await removeRecord('bookings',id);toast('Booking cancelled. Tickets have been released.');},'Cancel booking');break;
      case 'delete-venue':requireRole('admin');confirmModal('Delete this venue?','Venues linked to an event may need to be marked unavailable instead.',async()=>{await removeRecord('venues',id);toast('Venue deleted.');},'Delete venue');break;
      case 'deactivate-user':requireRole('admin');if(+state.user.user_id===id)throw Error('You cannot deactivate your own account here.');confirmModal('Deactivate this account?','This person will lose access to the workspace. Their records will be kept.',async()=>{await removeRecord('users',id);toast('Account deactivated.');},'Deactivate');break;
      case 'connect':connectModal();break;case 'refresh':await refresh();break;case 'help':help();break;case 'weather':await weather(id,target);break;
      case 'notifications':notifications();break;case 'export':exportCsv();break;
      case 'review-pending':requireRole('admin','staff');state.filters.bookings.status='pending';state.filters.bookings.q='';state.page=1;if(location.hash==='#bookings')navigate('bookings');else location.hash='bookings';break;
      case 'open-calendar':location.hash='calendar';break;case 'browse-events':location.hash='events';break;
      case 'week-prev':state.weekOffset--;state.scheduleMode='week';state.scheduleDate='';renderMain();break;
      case 'week-next':state.weekOffset++;state.scheduleMode='week';state.scheduleDate='';renderMain();break;
      case 'week-today':state.weekOffset=0;state.scheduleMode='week';state.scheduleDate='';renderMain();break;
      case 'calendar-prev':case 'calendar-next':{const d=new Date(state.calendar.year,state.calendar.month+(target.dataset.action==='calendar-next'?1:-1),1);state.calendar={year:d.getFullYear(),month:d.getMonth()};renderMain();break;}
      case 'calendar-today':state.calendar={year:new Date().getFullYear(),month:new Date().getMonth()};renderMain();break;
      case 'signout':if(state.mode==='demo'){connectModal();break;}try{await api.request('auth/logout.php','POST');toast('Signed out.');}catch{toast('Signed out in this browser. The server could not revoke the token.',true);}sessionStorage.removeItem('eventa-session');api=null;state.mode='demo';state.user=demo.users.find(u=>u.role==='admin')??seedData().users[0];state.route='overview';closeModal();render();connectModal();break;
      case 'reset-demo':confirmModal('Reset the sample workspace?','This will restore the original sample events, people, venues, and bookings in this browser.',async()=>{const role=state.user.role;demo=seedData();state.user=demo.users.find(u=>u.role===role);persistDemo();render();toast('Sample workspace restored.');},'Reset demo');break;
    }
  }catch(err){notifyError(err);}
});
function filterChange(target){
  const [group,key]=target.dataset.filter.split('.');state.filters[group][key]=target.value;state.page=1;
  const inputId=target.id,pos=target.selectionStart;
  renderMain();const replacement=document.getElementById(inputId);if(replacement){replacement.focus();if(typeof pos==='number')replacement.setSelectionRange(pos,pos);}
}
document.addEventListener('input',event=>{if(event.target.dataset.filter&&event.target.tagName==='INPUT')filterChange(event.target);});
document.addEventListener('change',event=>{if(event.target.dataset.filter&&event.target.tagName==='SELECT')filterChange(event.target);if(event.target.id==='demo-role')switchRole(event.target.value).catch(notifyError);});
document.addEventListener('keydown',event=>{
  if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();if(!modalRoot.firstElementChild)document.getElementById('global-search')?.focus();}
  if(event.key==='Escape'){closeModal();toggleMenu(false);}
  if(event.key==='Tab'&&modalRoot.firstElementChild){const nodes=[...modalRoot.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled)')];const first=nodes[0],last=nodes.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}
});
window.addEventListener('hashchange',()=>{navigate(location.hash.slice(1));window.scrollTo({top:0,behavior:'instant'});});
state.route=allowedRoutes(state.user.role).includes(location.hash.slice(1))?location.hash.slice(1):'overview';render();
let savedSession=null;try{savedSession=JSON.parse(sessionStorage.getItem('eventa-session'));}catch{}
if(savedSession?.token&&savedSession?.user&&['admin','staff','customer'].includes(savedSession.user.role)){
  busy('Opening your connected workspace…');
  const candidate=new EventApi(savedSession.base,savedSession.token);
  candidate.load(savedSession.user).then(data=>{api=candidate;api.onUnauthorized=expiredSession;state.mode='live';state.user=savedSession.user;state.data=data;state.apiBase=savedSession.base;state.route=allowedRoutes(state.user.role).includes(state.route)?state.route:'overview';render();}).catch(err=>{sessionStorage.removeItem('eventa-session');notifyError(err);connectModal();}).finally(()=>busy());
}
