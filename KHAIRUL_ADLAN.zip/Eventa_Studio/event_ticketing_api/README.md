# Eventa — Event Ticketing & Venue Management Frontend

A responsive, build-free frontend designed for the PHP API in `event_ticketing_api(3).zip`.

## Studio redesign

The new design uses bold black, ivory, deep violet, and soft lilac. A slim navigation rail, oversized event header, featured ticket, poster-style event cards, and blueprint-style venue cards give it a distinct visual identity. The overview now provides an interactive weekly schedule, a priority booking queue with quick confirmation, a pending-booking shortcut, ticket-demand rankings, and a booking-value bar chart. These frontend changes use the same existing PHP API and database.

Quick confirmation is available only to admins and staff managing their own event bookings. Customers can review their own pending bookings. The weekly agenda supports date selection, previous/next week, and a return to the current week. The event catalogue includes My events and 20%-or-fewer-tickets-left filters. The Noir/Violet edition uses a black header, ivory panels, and purple/lilac accents in both themes.

## Run on Windows

Extract the ZIP, then double-click **START_EVENTA.bat**. It discovers PHP, selects a free local port, starts a local server, waits for it to respond, and opens the dashboard. Keep its PHP server window open. If PHP is unavailable, it opens the complete sample dashboard directly.

You can also double-click **index.html** in the project folder to see and use the sample design without a server. This downloadable entry now contains all JavaScript and CSS, so it does not depend on loading browser modules through localhost. The modular `.mjs` and CSS source files remain included for reference.

Real PHP/MySQL operations still need your existing database and a running PHP server. Start MySQL before connecting an existing account. No database, credentials, or PHP endpoint was changed. The Windows launcher could not be executed in this Linux environment; the standalone JavaScript was checked separately.

## Start with the design

The hosted version opens in a clearly labelled **sample workspace**. Explore all three roles from Settings or by clicking **Demo data** in the header. Sample changes are saved in your browser, independently of your real database. Reset them from Settings.

## Connect your existing PHP backend

1. Start Apache and MySQL in XAMPP. Your existing `event_ticketing_db` database and tables must already be installed. The supplied backend ZIP does **not** contain a database SQL export.
2. Extract the included `event_ticketing_api` folder into `C:\xampp\htdocs\`. If you already have that folder, keep your existing database configuration and copy only the new frontend files into it: `index.html`, `styles.css`, `studio.css`, `app.mjs`, `api.mjs`, `domain.mjs`, `views.mjs`, `studio.mjs`, `ui.mjs`, `favicon.svg`, and `.htaccess`.
3. Open **http://localhost/event_ticketing_api/** in your browser. You can open the same project folder in NetBeans to edit the files. No npm installation or build step is needed.
4. Choose **Demo data** in the header, or **Settings → Connect API**. Enter `http://localhost/event_ticketing_api` as the base address, plus an existing account's email and password.
5. After a successful login and data load, the header changes to **Connected**. Create/edit actions now call your PHP API. The frontend does not create a default admin account or change anyone's password.

If your Apache port or project folder differs, use its actual URL. For example, `http://localhost:8080/event_ticketing_api`. For real backend operations, open the frontend through the launcher or Apache. Directly opening `index.html` is supported for the sample workspace. A hosted HTTPS preview cannot run PHP or reach a MySQL database on your own computer; the local files are intended for that connection.

The ZIP preserves the supplied PHP files. In particular, `config/database.php` retains the original local database settings; use your existing working configuration if different. `.htaccess` adds the JavaScript MIME type for `.mjs` modules on Apache.

## Included screens

- **Overview:** an interactive weekly schedule, quick booking confirmation, ticket-demand rankings, calculated booking totals, and a 7/30-day bar chart.
- **Events:** search, status filters, sorting, grid/table view, event details, create/edit, cancellation, and venue weather.
- **Bookings:** search, filter, edit quantity/status, automatic ticket adjustments through the API, and CSV export.
- **Calendar:** event dates, month navigation, and event details.
- **Venues:** availability, capacity, create/edit/delete for admins.
- **People:** create/edit accounts and deactivate access for admins.
- **Reports:** booking status, confirmation rate, event performance, and CSV export.
- **Settings:** API login, role previews, sample data reset, and persistent light/dark theme.

Keyboard: use **Ctrl+K** (or **Cmd+K**) for search, **Enter** to submit, and **Escape** to close a dialog. Dialogs contain keyboard focus and the sidebar adapts to mobile screens.

## API permissions

| Action | Admin | Staff | Customer |
| --- | --- | --- | --- |
| Browse events and venue weather | Yes | Yes | Yes |
| Create, edit, cancel events | Yes | Yes | No |
| Read bookings | All | Own events | Own bookings |
| Change booking quantity/status | Yes | Own events | No |
| Create a ticket booking | No | No | Yes |
| Cancel via DELETE | Yes | No; use status update | Own bookings |
| Manage venues and accounts | Yes | No | No |

The frontend follows the uploaded API's permissions. Your server remains responsible for enforcing access. The staff event form asks for a **venue ID** because this backend allows only admins to read the venue directory. Known venue IDs are suggested from existing events. Staff should obtain other IDs from an admin.

## Data definitions

- Confirmed booking value is the sum of `total_amount` for confirmed bookings; it does not indicate collected payments.
- Tickets booked include pending and confirmed quantities. Cancelled tickets are excluded.
- The chart groups confirmed bookings by booking date, using browser-local date labels.
- A staff member's booking totals and reports cover their own event bookings. Customers see only their own bookings. The API provides the event catalogue to all signed-in users.
- Venue weather is a **current** reading, rather than a forecast for a future event date. Sample weather is explicitly marked illustrative.
- Cancelling an event changes the event status, as in your existing API. Existing bookings are retained and must be reviewed separately.
- Live authentication tokens are kept in session storage; account passwords are never persisted by the frontend. Sample account passwords are never stored.

## Files

`index.html` is the entry point; `styles.css` provides the component foundation; `studio.css` provides the black/ivory/purple visual design and new responsive layout; `app.mjs` handles interactions; `views.mjs` renders screens; `studio.mjs` renders the new navigation, overview, event posters, and venue cards; `ui.mjs` contains reusable interface helpers; `domain.mjs` contains calculations and sample data; `api.mjs` talks to the PHP backend.

## Verification

Thirteen automated checks cover JavaScript execution, route rendering, role scope, booking stock adjustments, quick booking confirmation, selected dates and weekly agenda boundaries, CSV escaping, event validation, login response handling, endpoint mapping, and event pagination. This environment does not provide the supported browser QA tool, PHP runtime, or your running MySQL database, so visual browser QA and a live PHP/MySQL integration test could not be completed here. Use the connection steps above to verify your existing database setup.
