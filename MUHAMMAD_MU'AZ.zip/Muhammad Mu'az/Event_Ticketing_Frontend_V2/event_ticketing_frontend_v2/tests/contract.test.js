import test from "node:test";
import assert from "node:assert/strict";
import { ApiError, request, saveSession, getSession, clearSession, requireList } from "../assets/api.js";
import { eventPayload, venuePayload, bookingPayload } from "../assets/forms.js";

const stored = new Map();
globalThis.sessionStorage = {
  getItem: key => stored.get(key) ?? null,
  setItem: (key, value) => stored.set(key, value),
  removeItem: key => stored.delete(key)
};
const login = { status: true, token: "test-admin-token", user: { user_id: 1, name: "Admin User", role: "admin" } };
const venue = { venue_id: 1, venue_name: "Grand Hall A", capacity: 500, status: "available" };
// The first event returned by the user's successful GET Events request.
const existing = {
  event_id: 1, organiser_id: 2, venue_id: 1,
  event_name: "Technology Conference 2026", description: "Conference about latest technology trends.",
  event_date: "2026-11-15", start_time: "09:00:00", end_time: "17:00:00",
  ticket_price: "50.00", total_tickets: 500, available_tickets: 498, status: "upcoming"
};
const values = { ...existing, organiser_id: "2", venue_id: "1", start_time: "09:00", end_time: "17:00", total_tickets: "500" };
const response = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

test("login sends JSON without an old Bearer token and accepts admin session", async () => {
  saveSession(login);
  globalThis.fetch = async (url, options) => {
    assert.equal(url, "/event_ticketing_api/auth/login.php");
    assert.equal(options.method, "POST");
    assert.equal(options.headers.Authorization, undefined);
    assert.equal(options.headers["Content-Type"], "application/json");
    assert.deepEqual(JSON.parse(options.body), { email: "admin@gmail.com", password: "admin123" });
    return response(login);
  };
  const result = await request("auth/login.php", { method: "POST", auth: false, body: { email: "admin@gmail.com", password: "admin123" } });
  saveSession(result);
  assert.equal(getSession().user.role, "admin");
  clearSession();
});

test("GET Events uses the saved token and reads the confirmed paginated contract", async () => {
  saveSession(login);
  globalThis.fetch = async (url, options) => {
    assert.equal(url, "/event_ticketing_api/api/events/?page=1&limit=5");
    assert.equal(options.headers.Authorization, "Bearer test-admin-token");
    assert.equal(options.body, undefined);
    return response({ status: true, message: "Events retrieved successfully", search: "", pagination: { current_page: 1, limit: 5, total_records: 5, total_pages: 1 }, data: [existing] });
  };
  const result = await request("api/events/?page=1&limit=5");
  assert.equal(requireList(result)[0].available_tickets, 498);
  assert.equal(result.pagination.total_records, 5);
  clearSession();
});

test("401 clears the session and preserves the server's explanation", async () => {
  saveSession(login);
  globalThis.fetch = async () => response({ status: false, message: "Invalid or expired authentication token" }, 401);
  await assert.rejects(request("api/events/"), error => error instanceof ApiError && error.status === 401 && error.message.includes("expired"));
  assert.equal(getSession(), null);
});

test("403 and 400 do not erase a valid admin session", async () => {
  saveSession(login);
  for (const [status, message] of [[403, "Access denied for this role"], [400, "Not enough tickets available"]]) {
    globalThis.fetch = async () => response({ status: false, message }, status);
    await assert.rejects(request("api/bookings/?id=1", { method: "PUT", body: { quantity: 999 } }), error => error.status === status && error.message === message);
    assert.equal(getSession().token, login.token);
  }
  clearSession();
});

test("an unsuccessful JSON response is rejected even when HTTP is 200", async () => {
  globalThis.fetch = async () => response({ status: false, message: "Database connection failed" });
  await assert.rejects(request("api/events/"), /Database connection failed/);
});

test("HTML, network errors and cancelled reads are handled distinctly", async () => {
  globalThis.fetch = async () => new Response("<html>Not Found</html>", { status: 404 });
  await assert.rejects(request("api/events/"), error => error.status === 404 && error.message.includes("unexpected"));
  globalThis.fetch = async () => { throw new TypeError("Failed to fetch"); };
  await assert.rejects(request("api/events/"), /Cannot connect/);
  const cancelled = new DOMException("Cancelled", "AbortError");
  globalThis.fetch = async () => { throw cancelled; };
  await assert.rejects(request("api/events/"), error => error === cancelled);
});

test("all three real roles can sign in while unknown or inactive roles are rejected", () => {
  for (const role of ["admin", "customer", "staff"]) {
    saveSession({ ...login, user: { ...login.user, role } });
    assert.equal(getSession().user.role, role);
    clearSession();
  }
  for (const user of [{ ...login.user, role: "superuser" }, { ...login.user, status: "inactive" }]) {
    assert.throws(() => saveSession({ ...login, user }), /cannot access/);
    assert.equal(getSession(), null);
  }
});

test("record endpoints require an actual data array", () => {
  assert.deepEqual(requireList({ status: true, data: [] }), []);
  assert.throws(() => requireList({ status: true, data: { event_id: 1 } }), /records could not be loaded/);
});

test("new events start with all tickets available and numeric JSON fields", () => {
  const payload = eventPayload({ ...values, total_tickets: "100", ticket_price: "0.50" }, null, venue);
  assert.equal(payload.total_tickets, 100);
  assert.equal(payload.available_tickets, 100);
  assert.equal(payload.ticket_price, 0.5);
  assert.equal(payload.organiser_id, 2);
  assert.equal(payload.start_time, "09:00:00");
});

test("editing preserves existing reserved tickets and validates smaller capacity", () => {
  const unchanged = eventPayload(values, existing, venue);
  assert.equal(unchanged.available_tickets, 498);
  const reduced = eventPayload({ ...values, total_tickets: "10" }, existing, venue);
  assert.equal(reduced.available_tickets, 8);
  assert.throws(() => eventPayload({ ...values, total_tickets: "1" }, existing, venue), /already reserved/);
  assert.throws(() => eventPayload({ ...values, total_tickets: "501" }, existing, venue), /venue capacity/);
  // More bookings may arrive while an edit form is open: the fresh record matters.
  const fresh = { ...existing, available_tickets: 490 };
  assert.equal(eventPayload({ ...values, total_tickets: "20" }, fresh, venue).available_tickets, 10);
});

test("invalid dates, times, quantities, prices and statuses are blocked", () => {
  for (const changes of [
    { event_date: "2026-02-30" }, { start_time: "25:00" }, { end_time: "08:00" },
    { total_tickets: "2.5" }, { total_tickets: "0" }, { ticket_price: "-1" },
    { ticket_price: "5.123" }, { event_name: "   " }, { status: "unknown" }
  ]) assert.throws(() => eventPayload({ ...values, ...changes }, null, venue), Error);
});

test("an unavailable venue can only be retained by an existing event", () => {
  const unavailable = { ...venue, status: "unavailable" };
  assert.throws(() => eventPayload(values, null, unavailable), /available venue/);
  assert.equal(eventPayload(values, existing, unavailable).venue_id, 1);
});

test("venue fields are trimmed and capacity must be a positive integer", () => {
  assert.deepEqual(venuePayload({ venue_name: " Hall ", location: " KL ", capacity: "10", status: "available" }), { venue_name: "Hall", location: "KL", capacity: 10, status: "available" });
  for (const capacity of ["0", "-5", "1.5", "", "NaN"]) assert.throws(() => venuePayload({ ...venue, location: "KL", capacity }), /whole number/);
});

test("cancelling retains the original quantity and permits meaningful status updates", () => {
  const previous = { quantity: 2, booking_status: "confirmed" };
  assert.deepEqual(bookingPayload({ quantity: "9", booking_status: "cancelled" }, previous), { quantity: 2, booking_status: "cancelled" });
  assert.deepEqual(bookingPayload({ quantity: "3", booking_status: "confirmed" }, previous), { quantity: 3, booking_status: "confirmed" });
  assert.throws(() => bookingPayload({ quantity: "0", booking_status: "confirmed" }, previous), /positive/);
  assert.throws(() => bookingPayload({ quantity: "2", booking_status: "paid" }, previous), /valid status/);
});
