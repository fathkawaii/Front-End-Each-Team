<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../../config/database.php";
require_once "../../helpers/auth.php";

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id'])
    ? intval($_GET['id'])
    : null;


// =====================================================
// ROLE ACCESS
// =====================================================

// All logged-in users can view events
if ($method === 'GET') {

    $currentUser = authenticateUser();

} else {

    // Only Admin / Staff can manage events
    $currentUser = requireStaffOrAdmin();
}


switch ($method) {

    // =====================================================
    // GET EVENT / EVENTS
    // SEARCH + PAGINATION
    // =====================================================

    case 'GET':

        // -------------------------------------------------
        // GET ONE EVENT
        // -------------------------------------------------

        if ($id) {

            $stmt = $conn->prepare("
                SELECT
                    e.*,
                    u.name AS organiser_name,
                    v.venue_name,
                    v.location AS venue_location
                FROM events e
                LEFT JOIN users u
                    ON e.organiser_id = u.user_id
                LEFT JOIN venues v
                    ON e.venue_id = v.venue_id
                WHERE e.event_id = ?
            ");

            $stmt->execute([$id]);

            $event = $stmt->fetch(
                PDO::FETCH_ASSOC
            );

            if (!$event) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,
                    "message" => "Event not found"
                ]);

                exit;
            }

            echo json_encode([
                "status" => true,
                "message" => "Event retrieved successfully",
                "data" => $event
            ]);

            exit;
        }


        // -------------------------------------------------
        // SEARCH
        // -------------------------------------------------

        $search = isset($_GET['search'])
            ? trim($_GET['search'])
            : "";


        // -------------------------------------------------
        // PAGINATION
        // -------------------------------------------------

        $page = isset($_GET['page'])
            ? intval($_GET['page'])
            : 1;

        $limit = isset($_GET['limit'])
            ? intval($_GET['limit'])
            : 5;


        if ($page < 1) {
            $page = 1;
        }


        if ($limit < 1) {
            $limit = 5;
        }


        // Prevent huge request
        if ($limit > 50) {
            $limit = 50;
        }


        $offset =
            ($page - 1) * $limit;


        // -------------------------------------------------
        // COUNT TOTAL RECORDS
        // -------------------------------------------------

        if ($search !== "") {

            $searchValue =
                "%" . $search . "%";


            $countStmt = $conn->prepare("
                SELECT COUNT(*)
                FROM events e
                LEFT JOIN venues v
                    ON e.venue_id = v.venue_id
                WHERE
                    e.event_name LIKE ?
                    OR e.description LIKE ?
                    OR v.venue_name LIKE ?
                    OR v.location LIKE ?
                    OR e.status LIKE ?
            ");


            $countStmt->execute([
                $searchValue,
                $searchValue,
                $searchValue,
                $searchValue,
                $searchValue
            ]);

        } else {

            $countStmt = $conn->prepare("
                SELECT COUNT(*)
                FROM events
            ");

            $countStmt->execute();
        }


        $totalRecords =
            intval($countStmt->fetchColumn());


        $totalPages =
            $totalRecords > 0
            ? ceil($totalRecords / $limit)
            : 0;


        // -------------------------------------------------
        // GET EVENTS
        // -------------------------------------------------

        if ($search !== "") {

            $stmt = $conn->prepare("
                SELECT
                    e.*,
                    u.name AS organiser_name,
                    v.venue_name,
                    v.location AS venue_location
                FROM events e

                LEFT JOIN users u
                    ON e.organiser_id = u.user_id

                LEFT JOIN venues v
                    ON e.venue_id = v.venue_id

                WHERE
                    e.event_name LIKE ?
                    OR e.description LIKE ?
                    OR v.venue_name LIKE ?
                    OR v.location LIKE ?
                    OR e.status LIKE ?

                ORDER BY e.event_id ASC

                LIMIT $limit OFFSET $offset
            ");


            $stmt->execute([
                $searchValue,
                $searchValue,
                $searchValue,
                $searchValue,
                $searchValue
            ]);

        } else {

            $stmt = $conn->prepare("
                SELECT
                    e.*,
                    u.name AS organiser_name,
                    v.venue_name,
                    v.location AS venue_location
                FROM events e

                LEFT JOIN users u
                    ON e.organiser_id = u.user_id

                LEFT JOIN venues v
                    ON e.venue_id = v.venue_id

                ORDER BY e.event_id ASC

                LIMIT $limit OFFSET $offset
            ");

            $stmt->execute();
        }


        $events = $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );


        echo json_encode([
            "status" => true,

            "message" =>
                "Events retrieved successfully",

            "search" =>
                $search,

            "pagination" => [
                "current_page" =>
                    $page,

                "limit" =>
                    $limit,

                "total_records" =>
                    $totalRecords,

                "total_pages" =>
                    $totalPages
            ],

            "data" =>
                $events
        ]);

        break;


    // =====================================================
    // CREATE EVENT
    // ADMIN / STAFF ONLY
    // =====================================================

    case 'POST':

        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        if (
            empty($data['organiser_id']) ||
            empty($data['venue_id']) ||
            empty($data['event_name']) ||
            empty($data['event_date']) ||
            empty($data['start_time']) ||
            empty($data['end_time']) ||
            !isset($data['ticket_price']) ||
            empty($data['total_tickets'])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Required event fields are missing"
            ]);

            exit;
        }


        $organiser_id =
            intval($data['organiser_id']);

        $venue_id =
            intval($data['venue_id']);

        $event_name =
            trim($data['event_name']);

        $description =
            $data['description'] ?? null;

        $event_date =
            $data['event_date'];

        $start_time =
            $data['start_time'];

        $end_time =
            $data['end_time'];

        $ticket_price =
            floatval($data['ticket_price']);

        $total_tickets =
            intval($data['total_tickets']);

        $available_tickets =
            isset($data['available_tickets'])
            ? intval($data['available_tickets'])
            : $total_tickets;

        $status =
            $data['status'] ?? 'upcoming';


        // -------------------------------------------------
        // CHECK ORGANISER
        // -------------------------------------------------

        $organiserCheck = $conn->prepare("
            SELECT
                user_id,
                role,
                status
            FROM users
            WHERE user_id = ?
        ");

        $organiserCheck->execute([
            $organiser_id
        ]);

        $organiser = $organiserCheck->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$organiser) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Organiser not found"
            ]);

            exit;
        }


        if (
            !in_array(
                $organiser['role'],
                ['admin', 'staff']
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Organiser must be admin or staff"
            ]);

            exit;
        }


        if ($organiser['status'] !== 'active') {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Organiser account is inactive"
            ]);

            exit;
        }


        // -------------------------------------------------
        // CHECK VENUE
        // -------------------------------------------------

        $venueCheck = $conn->prepare("
            SELECT
                venue_id,
                status
            FROM venues
            WHERE venue_id = ?
        ");

        $venueCheck->execute([
            $venue_id
        ]);

        $venue = $venueCheck->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$venue) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Venue not found"
            ]);

            exit;
        }


        if ($venue['status'] !== 'available') {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Venue is currently unavailable"
            ]);

            exit;
        }


        // -------------------------------------------------
        // VALIDATE STATUS
        // -------------------------------------------------

        $allowedStatus = [
            'upcoming',
            'ongoing',
            'completed',
            'cancelled'
        ];


        if (!in_array($status, $allowedStatus)) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid event status"
            ]);

            exit;
        }


        if ($ticket_price < 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Ticket price cannot be negative"
            ]);

            exit;
        }


        if ($total_tickets <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Total tickets must be greater than 0"
            ]);

            exit;
        }


        if (
            $available_tickets < 0 ||
            $available_tickets > $total_tickets
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid available ticket amount"
            ]);

            exit;
        }


        try {

            $stmt = $conn->prepare("
                INSERT INTO events
                (
                    organiser_id,
                    venue_id,
                    event_name,
                    description,
                    event_date,
                    start_time,
                    end_time,
                    ticket_price,
                    total_tickets,
                    available_tickets,
                    status
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $organiser_id,
                $venue_id,
                $event_name,
                $description,
                $event_date,
                $start_time,
                $end_time,
                $ticket_price,
                $total_tickets,
                $available_tickets,
                $status
            ]);


            http_response_code(201);


            echo json_encode([
                "status" => true,
                "message" => "Event created successfully",
                "event_id" => $conn->lastInsertId()
            ]);

        } catch (PDOException $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" => "Failed to create event"
            ]);
        }

        break;


    // =====================================================
    // UPDATE EVENT
    // ADMIN / STAFF ONLY
    // =====================================================

    case 'PUT':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Event ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT *
            FROM events
            WHERE event_id = ?
        ");

        $check->execute([$id]);

        $existingEvent = $check->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$existingEvent) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Event not found"
            ]);

            exit;
        }


        $data = json_decode(
            file_get_contents("php://input"),
            true
        );


        $organiser_id =
            $data['organiser_id']
            ?? $existingEvent['organiser_id'];

        $venue_id =
            $data['venue_id']
            ?? $existingEvent['venue_id'];

        $event_name =
            $data['event_name']
            ?? $existingEvent['event_name'];

        $description =
            $data['description']
            ?? $existingEvent['description'];

        $event_date =
            $data['event_date']
            ?? $existingEvent['event_date'];

        $start_time =
            $data['start_time']
            ?? $existingEvent['start_time'];

        $end_time =
            $data['end_time']
            ?? $existingEvent['end_time'];

        $ticket_price =
            $data['ticket_price']
            ?? $existingEvent['ticket_price'];

        $total_tickets =
            $data['total_tickets']
            ?? $existingEvent['total_tickets'];

        $available_tickets =
            $data['available_tickets']
            ?? $existingEvent['available_tickets'];

        $status =
            $data['status']
            ?? $existingEvent['status'];


        $allowedStatus = [
            'upcoming',
            'ongoing',
            'completed',
            'cancelled'
        ];


        if (!in_array($status, $allowedStatus)) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid event status"
            ]);

            exit;
        }


        if (floatval($ticket_price) < 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Ticket price cannot be negative"
            ]);

            exit;
        }


        if (intval($total_tickets) <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Total tickets must be greater than 0"
            ]);

            exit;
        }


        if (
            intval($available_tickets) < 0 ||
            intval($available_tickets) >
            intval($total_tickets)
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid available ticket amount"
            ]);

            exit;
        }


        try {

            $stmt = $conn->prepare("
                UPDATE events
                SET
                    organiser_id = ?,
                    venue_id = ?,
                    event_name = ?,
                    description = ?,
                    event_date = ?,
                    start_time = ?,
                    end_time = ?,
                    ticket_price = ?,
                    total_tickets = ?,
                    available_tickets = ?,
                    status = ?
                WHERE event_id = ?
            ");


            $stmt->execute([
                $organiser_id,
                $venue_id,
                $event_name,
                $description,
                $event_date,
                $start_time,
                $end_time,
                $ticket_price,
                $total_tickets,
                $available_tickets,
                $status,
                $id
            ]);


            echo json_encode([
                "status" => true,
                "message" => "Event updated successfully"
            ]);

        } catch (PDOException $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" => "Failed to update event"
            ]);
        }

        break;


    // =====================================================
    // DELETE / CANCEL EVENT
    // ADMIN / STAFF ONLY
    // =====================================================

    case 'DELETE':

        if (!$id) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Event ID is required"
            ]);

            exit;
        }


        $check = $conn->prepare("
            SELECT event_id
            FROM events
            WHERE event_id = ?
        ");

        $check->execute([$id]);


        if (!$check->fetch()) {

            http_response_code(404);

            echo json_encode([
                "status" => false,
                "message" => "Event not found"
            ]);

            exit;
        }


        $stmt = $conn->prepare("
            UPDATE events
            SET status = 'cancelled'
            WHERE event_id = ?
        ");


        $stmt->execute([$id]);


        echo json_encode([
            "status" => true,
            "message" => "Event cancelled successfully"
        ]);

        break;


    // =====================================================
    // INVALID METHOD
    // =====================================================

    default:

        http_response_code(405);

        echo json_encode([
            "status" => false,
            "message" => "Method not allowed"
        ]);

        break;
}

?>