import { request, getSession, ApiError, requireList, requireRecord } from "./api.js";
import { eventPayload, venuePayload, userPayload, bookingPayload, createBookingPayload } from "./forms.js";
import { canEditEvent, canEditBooking, canCancelBooking, canViewBooking, managesEvents } from "./policy.js";

function user() {
  const account = getSession()?.user;
  if (!account) throw new ApiError("Please sign in again.", 401);
  return account;
}
function allow(condition) {
  if (!condition) throw new ApiError("This action is not available for your account.", 403);
}
function sameAccount(token) {
  if (!getSession() || getSession().token !== token) throw new DOMException("Session changed", "AbortError");
}
function id(value) {
  const result = Number(value);
  if (!Number.isSafeInteger(result) || result < 1) throw new ApiError("A valid record ID is required.", 400);
  return result;
}

export async function getRecord(resource, recordId, options = {}) {
  return requireRecord(await request("api/" + resource + "/?id=" + id(recordId), options));
}

export async function allEvents(search = "", signal) {
  const token = getSession()?.token;
  const rows = [];
  let page = 1;
  let totalPages = 1;
  do {
    const params = new URLSearchParams({ search, page: String(page), limit: "50" });
    const result = await request("api/events/?" + params, { signal });
    sameAccount(token);
    rows.push(...requireList(result));
    totalPages = Math.max(1, Number(result.pagination?.total_pages || 1));
    page++;
  } while (page <= totalPages);
  return rows;
}

export async function eventPage({ search = "", page = 1, limit = 5, scope = "all", signal } = {}) {
  const account = user();
  if (account.role === "staff" && scope === "mine") {
    // The supplied API has no organiser filter; aggregate its real pages first.
    const rows = (await allEvents(search, signal)).filter(row => Number(row.organiser_id) === Number(account.user_id));
    const totalPages = Math.max(1, Math.ceil(rows.length / limit));
    const current = Math.min(Math.max(1, page), totalPages);
    return { data: rows.slice((current - 1) * limit, current * limit), pagination: {
      current_page: current, total_pages: totalPages, total_records: rows.length
    } };
  }
  const params = new URLSearchParams({ page: String(page), limit: String(limit), search });
  return request("api/events/?" + params, { signal });
}

export async function eventFormData(eventId = null) {
  const session = getSession();
  const account = user();
  allow(managesEvents(account));
  const [venues, organisers, event] = await Promise.all([
    request("api/venues/").catch(error => {
      if (account.role === "staff" && error.status === 403) {
        throw new ApiError("Venue access is not enabled for staff. Ask your administrator to check the setup.", 403);
      }
      throw error;
    }),
    account.role === "admin" ? request("api/users/") : Promise.resolve({ data: [account] }),
    eventId ? getRecord("events", eventId) : Promise.resolve(null)
  ]);
  sameAccount(session.token);
  if (event) allow(canEditEvent(account, event));
  return { venues: requireList(venues), organisers: requireList(organisers), event };
}

export async function saveEvent(values, previousId = null) {
  const session = getSession();
  const account = user();
  allow(managesEvents(account));
  const current = previousId ? await getRecord("events", previousId) : null;
  sameAccount(session.token);
  if (current) allow(canEditEvent(account, current));
  const venue = await getRecord("venues", values.venue_id);
  sameAccount(session.token);
  const submitted = account.role === "staff" ? { ...values, organiser_id: account.user_id } : values;
  const body = eventPayload(submitted, current, venue);
  return request("api/events/" + (previousId ? "?id=" + id(previousId) : ""), {
    method: previousId ? "PUT" : "POST", body
  });
}

export async function saveVenue(values, previousId = null) {
  allow(user().role === "admin");
  return request("api/venues/" + (previousId ? "?id=" + id(previousId) : ""), {
    method: previousId ? "PUT" : "POST", body: venuePayload(values)
  });
}

export async function saveUser(values, previousId = null) {
  const session = getSession();
  const account = user();
  allow(account.role === "admin");
  const previous = previousId ? await getRecord("users", previousId) : null;
  sameAccount(session.token);
  const body = userPayload(values, previous);
  if (Number(previousId) === Number(account.user_id)) {
    allow(body.role === "admin" && body.status === "active");
  }
  return request("api/users/" + (previousId ? "?id=" + id(previousId) : ""), {
    method: previousId ? "PUT" : "POST", body
  });
}

export async function createBooking(values, eventId) {
  const session = getSession();
  allow(user().role === "customer");
  const event = await getRecord("events", eventId);
  sameAccount(session.token);
  return request("api/bookings/", { method: "POST", body: createBookingPayload(values, event) });
}

export async function saveBooking(values, bookingId) {
  const session = getSession();
  const account = user();
  allow(["admin", "staff"].includes(account.role));
  const current = await getRecord("bookings", bookingId);
  sameAccount(session.token);
  allow(canEditBooking(account, current));
  const event = await getRecord("events", current.event_id);
  sameAccount(session.token);
  const body = bookingPayload(values, current);
  const held = current.booking_status === "cancelled" ? 0 : Number(current.quantity);
  if (body.booking_status !== "cancelled" && body.quantity - held > Number(event.available_tickets)) {
    throw new ApiError("Not enough tickets available for this quantity.", 400);
  }
  return request("api/bookings/?id=" + id(bookingId), { method: "PUT", body });
}

export async function bookingDetails(bookingId) {
  const session = getSession();
  const account = user();
  const booking = await getRecord("bookings", bookingId);
  sameAccount(session.token);
  allow(canViewBooking(account, booking));
  return booking;
}

export async function removeRecord(resource, recordId) {
  const session = getSession();
  const account = user();
  if (resource === "venues" || resource === "users") {
    allow(account.role === "admin");
    if (resource === "users") allow(Number(recordId) !== Number(account.user_id));
  } else if (resource === "events") {
    const event = await getRecord("events", recordId);
    sameAccount(session.token);
    allow(canEditEvent(account, event));
  } else if (resource === "bookings") {
    const booking = await getRecord("bookings", recordId);
    sameAccount(session.token);
    allow(canCancelBooking(account, booking));
  } else throw new ApiError("This action is not available.", 400);
  return request("api/" + resource + "/?id=" + id(recordId), { method: "DELETE" });
}
