@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Eventa - Start
for %%I in ("%~dp0.") do set "EVENTA_PROJECT=%%~fI"
if exist "%EVENTA_PROJECT%\event_ticketing_api\index.html" set "EVENTA_PROJECT=%EVENTA_PROJECT%\event_ticketing_api"
if not exist "%EVENTA_PROJECT%\index.html" goto missing_files

set "EVENTA_PHP="
if exist "C:\xampp\php\php.exe" set "EVENTA_PHP=C:\xampp\php\php.exe"
if not defined EVENTA_PHP if exist "D:\xampp\php\php.exe" set "EVENTA_PHP=D:\xampp\php\php.exe"
if not defined EVENTA_PHP if exist "C:\wamp64\bin\php" for /d %%P in ("C:\wamp64\bin\php\php*") do if exist "%%P\php.exe" set "EVENTA_PHP=%%P\php.exe"
if not defined EVENTA_PHP for /f "delims=" %%P in ('where php.exe 2^>nul') do if not defined EVENTA_PHP set "EVENTA_PHP=%%P"
if not defined EVENTA_PHP goto offline_preview
"%EVENTA_PHP%" -v >nul 2>&1
if errorlevel 1 goto offline_preview

echo Starting Eventa from:
echo %EVENTA_PROJECT%
echo.
set "EVENTA_PORT="
for /f "delims=" %%P in ('powershell.exe -NoProfile -Command "$l=[System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,0);$l.Start();$l.LocalEndpoint.Port;$l.Stop()" 2^>nul') do set "EVENTA_PORT=%%P"
if not defined EVENTA_PORT goto offline_preview

echo Opening http://127.0.0.1:%EVENTA_PORT%/index.html
start "Eventa PHP Server - keep this window open" "%EVENTA_PHP%" -S 127.0.0.1:%EVENTA_PORT% -t "%EVENTA_PROJECT%"
powershell.exe -NoProfile -Command "$u='http://127.0.0.1:'+$env:EVENTA_PORT+'/index.html';for($n=0;$n -lt 25;$n++){try{$r=Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 1;if($r.StatusCode -eq 200 -and $r.Content.Contains('eventa-application')){Start-Process $u;exit 0}}catch{};Start-Sleep -Milliseconds 200};exit 1"
if errorlevel 1 goto offline_preview
echo.
echo Eventa is open. Keep the Eventa PHP Server window open while using it.
echo The sample dashboard does not need a database.
echo For real records, start MySQL in XAMPP and use your existing account.
echo The Connect API window will suggest this server's address.
echo.
pause
exit /b 0

:offline_preview
echo.
echo Opening the dashboard directly in your browser.
echo This preview works without Apache, PHP, or MySQL.
echo It uses clearly labelled sample data.
echo.
start "" "%EVENTA_PROJECT%\index.html"
echo For live records, start your existing PHP backend and MySQL server.
echo If the page does not open, open the event_ticketing_api folder
echo and double-click index.html.
echo.
pause
exit /b 0

:missing_files
echo.
echo The project files were not found beside this launcher.
echo Right-click the downloaded ZIP and choose Extract All first.
echo Then double-click START_EVENTA.bat in the extracted folder.
echo If this still fails, send a screenshot of this window.
echo.
pause
exit /b 1
