# Manual test checklist — V2

Status awal: belum dijalankan pada XAMPP pengguna.
Isi actual result, pass/fail dan screenshot selepas setiap ujian.
Gunakan rekod ujian baharu supaya rekod lama tidak perlu diubah.

## A. Pemasangan dan login

A01. Apache/MySQL hidup; database connection test berjaya.
A02. Frontend V2 dibuka melalui localhost.
A03. Password salah: error dipaparkan dan aplikasi tidak dibuka.
A04. Admin sign in: Events, Venues, Bookings, Users dipaparkan.
A05. Sign out: login kembali; refresh kekal signed out.
A06. Staff sign in: Users tidak kelihatan.
A07. Customer sign in: hanya Events dan My bookings kelihatan.
A08. Tukar hash kepada #users ketika customer: kembali ke Events.

## B. Admin — Users

B01. Add user:
- Name: UI Test Customer
- Email: uitest.customer@example.com
- Password: Test1234
- Role: Customer
- Status: Active
- Expected: akaun dicipta dan muncul dalam Users.

B02. Search nama/email; kosongkan search untuk melihat senarai penuh.
B03. Edit phone, biarkan password kosong; password asal masih boleh digunakan.
B04. Cuba duplicate email: API error dipaparkan tanpa data palsu.
B05. Tukar akaun ujian kepada Inactive: login akaun itu ditolak.
B06. Sign in Admin, edit akaun ujian kembali Active.
B07. Deactivate akaun sendiri tidak tersedia dalam interface.

## C. Admin — Venues

C01. Add venue UI Test Hall, Kuala Lumpur, capacity 100, Available.
C02. Edit nama kepada UI Test Hall Updated dan capacity 120.
C03. Delete venue itu sebelum ia digunakan oleh event.
C04. Cuba delete venue yang sudah dirujuk event: error dependency dijangka.
C05. Capacity 0 atau pecahan: borang ditolak.

## D. Staff — Events

D01. Sign in staff1@gmail.com; buka Venues. Senarai boleh dibaca selepas patch.
D02. Tindakan add/edit/delete venue tidak dipaparkan untuk Staff.
D03. Buka Add event:
- Name: UI Test Event
- Venue: Grand Hall A
- Date: 30 November 2026, atau tarikh ujian sesuai yang dipersetujui group
- Start: 09:00
- End: 17:00
- Price: RM10
- Total tickets: 20
- Status: Upcoming
- Expected: organiser ialah akaun Staff semasa; availability 20.
D04. My events memaparkan event tersebut; All events juga boleh dibaca.
D05. Event organiser lain mempunyai Details tetapi tiada Edit/Cancel.
D06. Edit nama/description event sendiri; perubahan kekal selepas Refresh.
D07. End time sebelum start time / total melebihi kapasiti: ditolak.
D08. Event details > Check weather: catat respons sebenar dan screenshot.

## E. Customer — Booking

E01. Sign in akaun UI Test Customer yang dicipta melalui Users.
E02. Cari UI Test Event dan buka Details.
E03. Book tickets: kuantiti 21 ditolak jika baki 20.
E04. Book 2 tickets: anggaran RM20; booking berjaya sebagai Pending.
E05. My bookings menunjukkan rekod baharu, quantity 2, total RM20.
E06. Refresh Events: availability berkurang daripada 20 kepada 18.
E07. Buka booking Details: ID, event, quantity, total dan status betul.
E08. Customer lain tidak dapat melihat booking ini dalam My bookings.
E09. Customer tiada tindakan edit booking, manage event atau manage user.

## F. Staff/Admin — Booking management

F01. Staff pemilik event melihat booking ujian.
F02. Staff edit quantity 3 dan status Confirmed.
- Expected: total RM30; availability 17.
F03. Staff lain tidak melihat booking event tersebut.
F04. Admin boleh melihat semua booking dan perubahan tadi.
F05. Reactivate booking cancelled hanya jika tiket mencukupi.

## G. Customer — Cancellation

G01. Akaun pemilik booking memilih Cancel dan mengesahkan.
G02. Booking kekal dalam sejarah dengan status Cancelled.
G03. Availability event kembali kepada 20 jika tiada booking lain.
G04. Cancel pada rekod yang sudah cancelled tidak boleh ditekan.
G05. Refresh My bookings dan Events; kedua-dua rekod konsisten.

## H. Penutupan dan bukti

H01. Staff boleh cancel UI Test Event sendiri; status kekal selepas Refresh.
H02. Login setiap role semula untuk memastikan tiada data/filter role lama.
H03. Uji missing token dan wrong role dalam Postman.
H04. Uji layout pada skrin kecil dan keyboard navigation dalam browser.
H05. Ambil screenshot sebenar bagi success dan error.
H06. Redact token sebelum screenshot dimasukkan ke report.

Untuk setiap test, rekod:
Test ID | Tarikh | Expected | Actual | Pass/Fail | Screenshot/commit

Jangan tandakan semua test sebagai passed tanpa menjalankannya.
