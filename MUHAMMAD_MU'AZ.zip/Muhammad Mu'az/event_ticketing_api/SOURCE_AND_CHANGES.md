# Sumber dan penyesuaian setup lokal

Sumber kod yang diberikan oleh pengguna:

1. https://chatgpt.com/share/6acf9a6a-fd28-83ec-bac7-6bf1dc2e8159
2. https://chatgpt.com/share/6acf9b0d-4b1c-83ec-b405-c40ccc3c88cc

Database, sample data, connection dan test connection diambil daripada link kedua.
Versi terakhir users, venues, events, bookings, weather, login, logout dan helper
authentication diambil daripada link pertama. Versi terdahulu dalam chat tidak
digunakan untuk menggantikan kod yang lebih akhir.

Penyesuaian yang dibuat untuk pakej setup lokal ini:

- SQL digabungkan menjadi satu fail yang membina database dan memasukkan sample data.
- Password sample SQL ditukar kepada bcrypt hash supaya serasi dengan password_verify().
- FK daripada events.venue_id kepada venues.venue_id menggunakan ON DELETE RESTRICT,
  menggantikan CASCADE asal. Ini sepadan dengan mesej endpoint venue yang menyatakan
  venue yang digunakan event tidak boleh dipadam.
- Baki tiket sample dikira semula selepas sample bookings dimasukkan. Booking pending
  dan confirmed mengurangkan available_tickets seperti peraturan API.
- index.php ringkas ditambah untuk mengenal pasti API, tanpa mengubah endpoint.
- Collection Postman tambahan disediakan untuk connection/login dan GET checks.
  Collection asal pengguna tidak diubah. Collection tambahan ini bukan koleksi
  lengkap yang diperlukan untuk submission kumpulan.

Had kod asal yang masih memerlukan semakan kumpulan:

- Authentication menggunakan token rawak yang disimpan dalam auth_tokens; JWT belum
  diimplementasikan dalam versi chat ini.
- Semakan baki tiket dan status booking berlaku sebelum transaction bermula.
  Request booking/update/cancel serentak belum dilindungi dengan row locking atau
  conditional update. Ujian serentak diperlukan sebelum penggunaan sebenar.
- Fail dalam pakej ini ialah reconstruction daripada shared chat. Bandingkan dengan
  folder rasmi kumpulan jika kawan telah membuat perubahan selepas chat dikongsi.

Semakan yang selesai: salinan fail PHP sepadan dengan sumber yang dipilih,
laluan require tempatan wujud, lima table dijana, password hash disahkan menggunakan
bcrypt/crypt, sample availability sepadan dengan sample bookings, JSON Postman sah,
dan ZIP lulus pemeriksaan integrity. PHP lint dan ujian API/MySQL secara langsung
belum dijalankan kerana runtime PHP/MySQL tidak tersedia di persekitaran ini.
