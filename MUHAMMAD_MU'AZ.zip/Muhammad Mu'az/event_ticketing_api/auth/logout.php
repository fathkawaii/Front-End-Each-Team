<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "status" => false,
        "message" => "Method not allowed"
    ]);

    exit;
}


// =====================================================
// GET AUTHORIZATION HEADER
// =====================================================

$headers = getallheaders();

$authorization = null;

if (isset($headers['Authorization'])) {
    $authorization = $headers['Authorization'];
}

if (
    !$authorization &&
    isset($headers['authorization'])
) {
    $authorization = $headers['authorization'];
}


// =====================================================
// CHECK TOKEN
// =====================================================

if (!$authorization) {

    http_response_code(401);

    echo json_encode([
        "status" => false,
        "message" => "Authentication token is required"
    ]);

    exit;
}


if (
    !preg_match(
        '/Bearer\s+(\S+)/i',
        $authorization,
        $matches
    )
) {

    http_response_code(401);

    echo json_encode([
        "status" => false,
        "message" => "Invalid authentication token format"
    ]);

    exit;
}


$token = $matches[1];

$tokenHash = hash(
    'sha256',
    $token
);


// =====================================================
// CHECK TOKEN EXISTS
// =====================================================

$stmt = $conn->prepare("
    SELECT token_id
    FROM auth_tokens
    WHERE token_hash = ?
    AND expires_at > NOW()
    LIMIT 1
");

$stmt->execute([
    $tokenHash
]);

$existingToken = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$existingToken) {

    http_response_code(401);

    echo json_encode([
        "status" => false,
        "message" => "Invalid or expired token"
    ]);

    exit;
}


// =====================================================
// DELETE TOKEN
// =====================================================

$stmt = $conn->prepare("
    DELETE FROM auth_tokens
    WHERE token_hash = ?
");

$stmt->execute([
    $tokenHash
]);


echo json_encode([
    "status" => true,
    "message" => "Logout successful"
]);

?>
