<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "status" => false,
        "message" => "Method not allowed"
    ]);

    exit;
}


// =====================================================
// READ JSON BODY
// =====================================================

$data = json_decode(
    file_get_contents("php://input"),
    true
);


if (!is_array($data)) {

    http_response_code(400);

    echo json_encode([
        "status" => false,
        "message" => "Invalid JSON data"
    ]);

    exit;
}


// =====================================================
// VALIDATE INPUT
// =====================================================

if (
    empty($data['email']) ||
    empty($data['password'])
) {

    http_response_code(400);

    echo json_encode([
        "status" => false,
        "message" => "Email and password are required"
    ]);

    exit;
}


$email = trim($data['email']);
$password = $data['password'];


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(400);

    echo json_encode([
        "status" => false,
        "message" => "Invalid email format"
    ]);

    exit;
}


// =====================================================
// FIND USER
// =====================================================

$stmt = $conn->prepare("
    SELECT
        user_id,
        name,
        email,
        password,
        phone,
        role,
        status
    FROM users
    WHERE email = ?
    LIMIT 1
");

$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);


// =====================================================
// CHECK EMAIL
// =====================================================

if (!$user) {

    http_response_code(401);

    echo json_encode([
        "status" => false,
        "message" => "Invalid email or password"
    ]);

    exit;
}


// =====================================================
// CHECK PASSWORD
// =====================================================

if (!password_verify($password, $user['password'])) {

    http_response_code(401);

    echo json_encode([
        "status" => false,
        "message" => "Invalid email or password"
    ]);

    exit;
}


// =====================================================
// CHECK ACCOUNT STATUS
// =====================================================

if ($user['status'] !== 'active') {

    http_response_code(403);

    echo json_encode([
        "status" => false,
        "message" => "Account is inactive"
    ]);

    exit;
}


// =====================================================
// DELETE EXPIRED TOKENS
// =====================================================

$deleteExpired = $conn->prepare("
    DELETE FROM auth_tokens
    WHERE expires_at < NOW()
");

$deleteExpired->execute();


// =====================================================
// GENERATE TOKEN
// =====================================================

$token = bin2hex(
    random_bytes(32)
);

$tokenHash = hash(
    'sha256',
    $token
);


// Token valid for 8 hours
$expiresAt = date(
    'Y-m-d H:i:s',
    strtotime('+8 hours')
);


// =====================================================
// SAVE TOKEN
// =====================================================

try {

    $stmt = $conn->prepare("
        INSERT INTO auth_tokens
        (
            user_id,
            token_hash,
            expires_at
        )
        VALUES
        (?, ?, ?)
    ");

    $stmt->execute([
        $user['user_id'],
        $tokenHash,
        $expiresAt
    ]);


    http_response_code(200);

    echo json_encode([
        "status" => true,
        "message" => "Login successful",
        "token" => $token,
        "token_type" => "Bearer",
        "expires_at" => $expiresAt,
        "user" => [
            "user_id" => $user['user_id'],
            "name" => $user['name'],
            "email" => $user['email'],
            "phone" => $user['phone'],
            "role" => $user['role'],
            "status" => $user['status']
        ]
    ]);

} catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "status" => false,
        "message" => "Login failed"
    ]);
}

?>
