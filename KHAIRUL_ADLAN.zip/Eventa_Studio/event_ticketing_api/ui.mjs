import {dateKey,dailySeries} from './domain.mjs';
export const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const paths={
  ticket:'<path d="M4 4h16v5a3 3 0 0 0 0 6v5H4v-5a3 3 0 0 0 0-6z"/><path d="M14 7v2m0 2v2m0 2v2"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18m-13 4h1m6 0h1m-8 3h1"/>',
  bookings:'<rect x="5" y="5" width="14" height="16" rx="2"/><path d="M9 5V3h6v2m-6 6h6m-6 4h6m-6 3h3"/>',
  venue:'<path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6M8 9h1m6 0h1m-8 3h1m6 0h1"/>',
  users:'<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m1-16a3 3 0 0 1 0 6m2 4a5 5 0 0 1 3 4v2"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  chart:'<path d="M4 3v17h17M8 15v-4m5 4V7m5 8v-6"/>',
  settings:'<path d="m9 3-.6 2.5-2.2 1.3L3.8 6l-2 3.5L3.6 11v2l-1.8 1.5 2 3.5 2.4-.8 2.2 1.3L9 21h4l.6-2.5 2.2-1.3 2.4.8 2-3.5-1.8-1.5v-2l1.8-1.5-2-3.5-2.4.8-2.2-1.3L13 3z"/><circle cx="11" cy="12" r="3"/>',
  help:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4m0 3h.01"/>',
  logout:'<path d="M9 5H5v14h4m4-7h8m-4-4 4 4-4 4"/>',
  home:'<path d="m3 10 9-7 9 7v10H3zM9 20v-7h6v7"/>',
  chevron:'<path d="m9 5 7 7-7 7"/>', down:'<path d="m7 10 5 5 5-5"/>',
  left:'<path d="m15 5-7 7 7 7"/>',right:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
  search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
  bell:'<path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 10h18c0-2-3-2-3-10M9 21h6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  money:'<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01m12 0h.01"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
  download:'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>',
  location:'<path d="M19 10c0 6-7 11-7 11S5 16 5 10a7 7 0 0 1 14 0"/><circle cx="12" cy="10" r="2.5"/>',
  more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  edit:'<path d="m16 3 5 5-12 12H4v-5zM13 6l5 5"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1"/>',
  moon:'<path d="M20 13A8 8 0 0 1 11 4 9 9 0 1 0 20 13"/>',
  cloud:'<path d="M6 18a5 5 0 1 1 1-10 6 6 0 0 1 12 2 4 4 0 0 1-1 8z"/>',
  refresh:'<path d="M21 10a9 9 0 0 0-16-5L3 8m0-5v5h5m-5 6a9 9 0 0 0 16 5l2-3m0 5v-5h-5"/>',
  shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="m8 12 3 3 5-6"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  link:'<path d="m10 14 4-4m-7 4-2 2a4 4 0 0 0 6 6l3-3m-4-14 3-3a4 4 0 1 1 6 6l-2 2"/>',
  spark:'<path d="m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3z"/>',
};
export const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]??paths.ticket}</svg>`;
export const num=value=>Number(value??0).toLocaleString('en-MY');
export const money=(value,decimals=0)=>`RM ${Number(value??0).toLocaleString('en-MY',{minimumFractionDigits:decimals,maximumFractionDigits:decimals})}`;
export const initials=name=>String(name??'?').split(' ').slice(0,2).map(s=>s[0]).join('').toUpperCase();
export const prettyDate=(date,options={day:'numeric',month:'short',year:'numeric'})=>new Date(String(date).slice(0,10)+'T12:00:00').toLocaleDateString('en-GB',options);
export const time=value=>{if(!value)return ''; const [h,m]=String(value).split(':'); return `${+h%12||12}:${m} ${+h>=12?'pm':'am'}`;};
export const status=value=>`<span class="status ${['upcoming','ongoing','completed','cancelled','confirmed','pending','available','unavailable','active','inactive'].includes(value)?value:''}">${esc(value)}</span>`;
export const button=(label,action,ico='plus',cls='',extra='')=>`<button type="button" class="button ${cls}" data-action="${action}" ${extra}>${ico?icon(ico):''}${label}</button>`;
export function progress(event) {
  const sold=Math.max(0,+event.total_tickets-+event.available_tickets);
  const pct=event.total_tickets?Math.min(100,Math.round(sold/+event.total_tickets*100)):0;
  return `<div class="ticket-progress"><small>${num(sold)} <span class="subdued">/ ${num(event.total_tickets)} booked</span></small><div class="bar" role="meter" aria-label="Tickets booked" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><span class="${pct>85?'high':''}" style="width:${pct}%"></span></div></div>`;
}
export function chart(bookings,count=7) {
  const days=dailySeries(bookings,count);
  const maximum=Math.max(100,...days.map(d=>d.value))*1.14;
  const width=620,height=170,left=48,top=8,bottom=30;
  const plotWidth=width-left-8,plotHeight=height-top-bottom,step=plotWidth/days.length;
  const barWidth=step*(count===7?.43:.6);
  const lines=Array.from({length:4},(_,i)=>{
    const y=top+i/3*plotHeight,amount=maximum*(1-i/3);
    return `<line x1="${left}" y1="${y}" x2="${width-8}" y2="${y}" stroke="var(--line)" stroke-dasharray="3 5"/><text x="${left-11}" y="${y+3}" text-anchor="end">${amount>=1000?(amount/1000).toFixed(1)+'k':Math.round(amount)}</text>`;
  }).join('');
  const peak=Math.max(...days.map(d=>d.value));
  const bars=days.map((d,i)=>{
    const h=d.value/maximum*plotHeight,x=left+step*i+(step-barWidth)/2,y=top+plotHeight-h;
    return `<rect x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${barWidth.toFixed(2)}" height="${h.toFixed(2)}" rx="${count===7?4:2}" fill="${d.value===peak&&peak>0?'var(--coral)':'var(--accent)'}"><title>${prettyDate(d.date)}: ${money(d.value,2)}</title></rect>`;
  }).join('');
  const labels=days.map((d,i)=>count===7||i%5===0||i===count-1?`<text x="${left+step*(i+.5)}" y="${height-6}" text-anchor="middle">${prettyDate(d.date,count===7?{weekday:'short'}:{day:'numeric',month:'short'})}</text>`:'').join('');
  const description=days.map(d=>`${prettyDate(d.date)}: ${money(d.value,2)}`).join('; ');
  return `<div class="chart-wrap"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Confirmed booking value over the last ${count} days"><desc>${description}</desc>${lines}${bars}${labels}</svg></div>`;
}
export function empty(title,description,action='') {return `<div class="empty-state">${icon('calendar')}<h3>${esc(title)}</h3><p>${esc(description)}</p>${action}</div>`;}
export const formError='<div id="form-error" class="form-error" role="alert"></div>';
export function field(label,name,value='',type='text',extra='') {
  return `<div class="field ${type==='textarea'?'full':''}"><label for="f-${name}">${label}</label>${type==='textarea'?`<textarea id="f-${name}" name="${name}" ${extra}>${esc(value)}</textarea>`:`<input id="f-${name}" name="${name}" type="${type}" value="${esc(value)}" ${extra}>`}</div>`;
}
export function selectField(label,name,options,value='',extra='') {
  return `<div class="field"><label for="f-${name}">${label}</label><select id="f-${name}" name="${name}" ${extra}>${options.map(o=>`<option value="${esc(o[0])}" ${String(o[0])===String(value)?'selected':''}>${esc(o[1])}</option>`).join('')}</select></div>`;
}
export function pagination(total,page,size=6) {
  const pages=Math.max(1,Math.ceil(total/size));
  const start=total?(page-1)*size+1:0,end=Math.min(page*size,total);
  const buttons=Array.from({length:pages},(_,i)=>i+1).filter(p=>pages<7||Math.abs(p-page)<2||p===1||p===pages);
  return `<div class="table-footer"><span>Showing ${start}–${end} of ${num(total)} results</span><nav class="pagination" aria-label="Pagination"><button type="button" aria-label="Previous page" data-page="${page-1}" ${page<=1?'disabled':''}>${icon('left')}</button>${buttons.map(p=>`<button type="button" data-page="${p}" class="${p===page?'active':''}" ${p===page?'aria-current="page"':''}>${p}</button>`).join('')}<button type="button" aria-label="Next page" data-page="${page+1}" ${page>=pages?'disabled':''}>${icon('chevron')}</button></nav></div>`;
}
